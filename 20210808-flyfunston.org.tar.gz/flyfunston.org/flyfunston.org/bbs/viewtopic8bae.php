<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en-us" xml:lang="en-us">

<!-- Mirrored from flyfunston.org/bbs/viewtopic.php?p=2638 by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 08 Aug 2021 20:15:03 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>

<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<meta http-equiv="content-style-type" content="text/css" />
<meta http-equiv="content-language" content="en-us" />
<meta http-equiv="imagetoolbar" content="no" />
<meta name="resource-type" content="document" />
<meta name="distribution" content="global" />
<meta name="keywords" content="" />
<meta name="description" content="" />

<title>Flyfunston &bull; View topic - Messing with Funston</title>



<!--
	phpBB style name: prosilver
	Based on style:   prosilver (this is the default phpBB3 style)
	Original author:  Tom Beddard ( http://www.subBlue.com/ )
	Modified by:
-->

<script type="text/javascript">
// <![CDATA[
	var jump_page = 'Enter the page number you wish to go to:';
	var on_page = '1';
	var per_page = '25';
	var base_url = 'viewtopic7a9d.html?f=5&amp;t=1133';
	var style_cookie = 'phpBBstyle';
	var style_cookie_settings = '; path=/; domain=flyfunston.org; secure';
	var onload_functions = new Array();
	var onunload_functions = new Array();

	

	/**
	* Find a member
	*/
	function find_username(url)
	{
		popup(url, 760, 570, '_usersearch');
		return false;
	}

	/**
	* New function for handling multiple calls to window.onload and window.unload by pentapenguin
	*/
	window.onload = function()
	{
		for (var i = 0; i < onload_functions.length; i++)
		{
			eval(onload_functions[i]);
		}
	};

	window.onunload = function()
	{
		for (var i = 0; i < onunload_functions.length; i++)
		{
			eval(onunload_functions[i]);
		}
	};

// ]]>
</script>
<script type="text/javascript" src="styles/prosilver/template/styleswitcher.js"></script>
<script type="text/javascript" src="styles/prosilver/template/forum_fn.js"></script>

<link href="styles/prosilver/theme/print.css" rel="stylesheet" type="text/css" media="print" title="printonly" />
<link href="style7a95.css?id=1&amp;lang=en_us" rel="stylesheet" type="text/css" media="screen, projection" />

<link href="styles/prosilver/theme/normal.css" rel="stylesheet" type="text/css" title="A" />
<link href="styles/prosilver/theme/medium.css" rel="alternate stylesheet" type="text/css" title="A+" />
<link href="styles/prosilver/theme/large.css" rel="alternate stylesheet" type="text/css" title="A++" />



</head>

<body id="phpbb" class="section-viewtopic ltr">

<div id="wrap">
	<a id="top" name="top" accesskey="t"></a>
	<div id="page-header">
		<div class="headerbar">
			<div class="inner"><span class="corners-top"><span></span></span>

			<div id="site-description">
				<a href="index.html" title="Board index" id="logo"><img src="styles/prosilver/imageset/site_logo.gif" width="149" height="52" alt="" title="" /></a>
				<h1>Flyfunston</h1>
				<p>Hang Gliding at Fort Funston</p>
				<p class="skiplink"><a href="#start_here">Skip to content</a></p>
			</div>

		
			<div id="search-box">
				<form action="http://flyfunston.org/bbs/search.php" method="get" id="search">
				<fieldset>
					<input name="keywords" id="keywords" type="text" maxlength="128" title="Search for keywords" class="inputbox search" value="Search…" onclick="if(this.value=='Search…')this.value='';" onblur="if(this.value=='')this.value='Search…';" />
					<input class="button2" value="Search" type="submit" /><br />
					<a href="search.html" title="View the advanced search options">Advanced search</a> 
				</fieldset>
				</form>
			</div>
		

			<span class="corners-bottom"><span></span></span></div>
		</div>

		<div class="navbar">
			<div class="inner"><span class="corners-top"><span></span></span>

			<ul class="linklist navlinks">
				<li class="icon-home"><a href="index.html" accesskey="h">Board index</a>  <strong>&#8249;</strong> <a href="viewforumfdc5.html?f=9">Discussion Groups</a> <strong>&#8249;</strong> <a href="viewforume774.html?f=5">General Discussion</a></li>

				<li class="rightside"><a href="#" onclick="fontsizeup(); return false;" onkeypress="return fontsizeup(event);" class="fontsize" title="Change font size">Change font size</a></li>

				<li class="rightside"><a href="viewtopic0c61.html?f=5&amp;t=1133&amp;view=print" title="Print view" accesskey="p" class="print">Print view</a></li>
			</ul>

			

			<ul class="linklist rightside">
				<li class="icon-faq"><a href="faq.html" title="Frequently Asked Questions">FAQ</a></li>
				
					<li class="icon-logout"><a href="ucp26c3.php?mode=login" title="Login" accesskey="x">Login</a></li>
				
			</ul>

			<span class="corners-bottom"><span></span></span></div>
		</div>

	</div>

	<a name="start_here"></a>
	<div id="page-body">
		
<h2><a href="viewtopic7a9d.html?f=5&amp;t=1133">Messing with Funston</a></h2>
<!-- NOTE: remove the style="display: none" when you want to have the forum description on the topic body --><div style="display: none !important;">Talk about Hang Gliding at Ft Funston and the Fellow Feathers Club.<br /></div>

<div class="topic-actions">

	<div class="buttons">
	
		<div class="reply-icon"><a href="posting8936.html?mode=reply&amp;f=5&amp;t=1133" title="Post a reply"><span></span>Post a reply</a></div>
	
	</div>

	
		<div class="search-box">
			<form method="get" id="topic-search" action="http://flyfunston.org/bbs/search.php">
			<fieldset>
				<input class="inputbox search tiny"  type="text" name="keywords" id="search_keywords" size="20" value="Search this topic…" onclick="if(this.value=='Search this topic…')this.value='';" onblur="if(this.value=='')this.value='Search this topic…';" />
				<input class="button2" type="submit" value="Search" />
				<input type="hidden" name="t" value="1133" />
<input type="hidden" name="sf" value="msgonly" />

			</fieldset>
			</form>
		</div>
	
		<div class="pagination">
			32 posts
			 &bull; <a href="#" onclick="jumpto(); return false;" title="Click to jump to page…">Page <strong>1</strong> of <strong>2</strong></a> &bull; <span><strong>1</strong><span class="page-sep">, </span><a href="viewtopicf323.html?f=5&amp;t=1133&amp;start=25">2</a></span>
		</div>
	

</div>
<div class="clear"></div>


	<div id="p2596" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postinga204.html?mode=quote&amp;f=5&amp;p=2596" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 class="first"><a href="#p2596">Messing with Funston</a></h3>
			<p class="author"><a href="viewtopic2639.html?p=2596#p2596"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberliste1b6.html?mode=viewprofile&amp;u=1877">thermal pirate</a></strong> &raquo; Sun Apr 24, 2011 9:58 pm </p>

			

			<div class="content">Shout out to all my Funston buds: Rick Cavallaro is trying to get the Fort shut down. Look what he wrote on hg.org <!-- m --><a class="postlink" href="http://www.hanggliding.org/viewtopic.php?p=233763#233763">http://www.hanggliding.org/viewtopic.ph ... 763#233763</a><!-- m --><br /><br /><blockquote><div><cite>spork wrote:</cite>I just spoke to Aline Forbes of the GGNRA.  We talked about whether or not the GGNRA takes the stance that they control the airspace.  Her first response is that she thought that &quot;airspace was free&quot;.  But she went on to say that to use that airspace one would have to launch and land at Fort Funston.  I pointed out to her that many aircraft fly through the airspace in front of that ridge without launching and landing at the Fort - and that federal law holds that the FAA has sole jurisdiction over airspace.  Her response was that &quot;if that's the case we would just close the Fort to hang gliding all together&quot;.  <br /><br />She sent me a copy of the exhibit that deals specifically with hang gliding and paragliding.  I'm just reviewing that now, but it contains some pretty bizarre stuff that I don't think we would necessarily want to be scrutinized too carefully.<br /><br />I guess that's up to the Fellow Feathers.</div></blockquote><br /><br />I'm pointing out that Spork is intentionally getting one government agency worried about another government agency. Thats a real dumsh*t move,  nice way to shut down a flying site Dork. Funston flyers unite! Fight the Dork!</div>

			
				<div class="notice">Last edited by <a href="memberliste1b6.html?mode=viewprofile&amp;u=1877">thermal pirate</a> on Tue Sep 25, 2012 10:15 am, edited 1 time in total.
					
				</div>
			

		</div>

		
			<dl class="postprofile" id="profile2596">
			<dt>
				<a href="memberliste1b6.html?mode=viewprofile&amp;u=1877">thermal pirate</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 10</dd><dd><strong>Joined:</strong> Mon Jan 03, 2011 3:12 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2607" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting25e3.html?mode=quote&amp;f=5&amp;p=2607" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2607">Re: Cavallaro messing with Funston</a></h3>
			<p class="author"><a href="viewtopicd339.php?p=2607#p2607"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist5346.html?mode=viewprofile&amp;u=1948">Jose</a></strong> &raquo; Mon Apr 25, 2011 2:38 pm </p>

			

			<div class="content">This is getting to a ridiculous state.  I am not going to weigh in one way or the other, I'm just putting this out there since so many Funston pilots are unaware of how serious this is now.<br /><br />I spoke with a bunch of HG pilots over the weekend and almost all are unaware of Rick's proposal and/or how far he has gone to push this issue, including meetings with the GGNRA.   I also spoke with Rick &amp; he is willing to drop the discussion with the GGNRA &amp; the eventual court case he is preparing for a judge to decide which will pretty much shut us down as the GGNRA has already stated.  Here is his proposal, I say we revisit it.  He is not asking for a fully integrated site, he is asking for a small landing area in the corner of the field, only pilots holding a H3 &amp; P3 would be allowed to land/take off there &amp; they cannot kite longer than it takes to land/take off.  This includes a handful of pilots (6 or so who have the balls to fly past the trees, 95% of the pg pilots don't dare go there).  If this can be worked out he will drop the court case he is preparing.<br /><br />Posted: Mon Apr 11, 2011 7:20 pm    Post subject: Be aware of paragliding in front of the Funston ridge	 #1   <br />I am a long time hang glider pilot, and a PG pilot for the last few years. I've recently requested that the club make allowance for the few Funston biwingual pilots to use a small corner of the LZ at Funston to land with PG. I've been very clear that we are not asking permission to fly the Funston ridge, or in any way interfere with hang gliding operations there. We are all hang glider pilots and are very well aware of the lift band, traffic patterns, etc. We simply want to be allowed to land on a small corner of the LZ so we can hang out with both our HG and PG friends. We would not be allowed to do touch-and-go's or hang out on the ridge. When we come north of the fence, we immediately land. When we take-off, we fly south. When we land, we must drop the wing and get out of the harness (in other words, nothing like touch-and-go's). <br /><br />We've tried very hard to reach a diplomatic agreement that would not inconvenience anyone. Unfortunately, the answer has been a resounding NO. <br /><br />As most are aware, the airspace is governed by the FAA - not the GGNRA, the Fellow Feathers, or anyone else. PG'ers have stayed clear of the Funston ridge all these years as a courtesy. I'm writing now to let you know of my intentions to no longer extend that courtesy. I will soon be flying the entire ridge - including the portion in front of Funston. I will be taking video, and I will be on radio to someone on the ground at Funston. I do NOT want to settle any issues in the air.</div>

			

		</div>

		
			<dl class="postprofile" id="profile2607">
			<dt>
				<a href="memberlist5346.html?mode=viewprofile&amp;u=1948">Jose</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 29</dd><dd><strong>Joined:</strong> Tue Mar 29, 2011 9:53 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2608" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting7f21.html?mode=quote&amp;f=5&amp;p=2608" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2608">Re: Cavallaro messing with Funston</a></h3>
			<p class="author"><a href="viewtopic0a1d.html?p=2608#p2608"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist9acc.html?mode=viewprofile&amp;u=126">Dan Brown</a></strong> &raquo; Mon Apr 25, 2011 5:12 pm </p>

			

			<div class="content">Paragliding at Funston is a recurring issue. When paraglider pilots wanted to open the front ridge to paragliding and use the Stables launch, we agreed to support the application with the understanding that paragliders would not fly north of the south end of the Bowl. I helped write the Stables permit. The demarcation is in the permit.<br /><br />In 2000 the issue was revisited. The Club held an advertised meeting to discuss the paragliding at Funston. It was one of the best attended meetings. We voted unanimously to oppose paragliding for safety reasons. The ridge may be long but the launch and landing areas are not. The GGNRA supported our decision.<br /><br />The FAA controls the air but not the ground. Funston is controlled by the GGNRA. It determines who lands and takes off from its property. We are prohibited by the GGNRA from flying during certain months over the bird sanctuary at the North end.<br /><br />If paragliders pilots violated the Stables permit and flew north of the Bowl, we could complain to Daly City that paraglider pilots are using its property to create a condition that the GGNRA considers unsafe and that liability would incur to Daly City if there were an accident.<br /><br />It is not in the best interests of BAPA and paragliding that Funston be shut down. Hang glider pilots would go to the Dumps overwhelming its capacity.<br /><br />Our opposition to paragliding at Funston has been undermined by USHPA when it voted to prohibit hang gliding only sites. Fortunately pilot outrage forced USHPA to rescind the measure but we are faced with the reality that both our Regional Directors, hang gliding pilots, voted for the prohibition.<br /><br />Reserving only a small portion of the LZ to paragliders is impractical. Landing is not a precise art. Claiming you are going to use a little bit of the LZ is like a lady claiming she is a little bit pregnant.<br /><br />Threats to file a lawsuit unless you get your way should be responded to firmly and unequivocally. “Go ahead and sue.”<br /><br />I understand there has been hostility to Rick because of his advocacy. When Rick flew hang gliders at Funston, he made substantial contributions to the site. He installed the WEB cameras and was responsible for their upkeep and maintenance. I hope discussion here does not degenerate into personal attacks and Rick’s views are respected.<br /><br />I went to the WEB site Steve referenced. As on our site, too many pilots are in the habit of not disclosing their true names. If you are going to post, put your name</div>

			

		</div>

		
			<dl class="postprofile" id="profile2608">
			<dt>
				<a href="memberlist9acc.html?mode=viewprofile&amp;u=126">Dan Brown</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 88</dd><dd><strong>Joined:</strong> Fri Apr 01, 2005 2:01 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2610" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting16e6.php?mode=quote&amp;f=5&amp;p=2610" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2610">Re: Cavallaro messing with Funston</a></h3>
			<p class="author"><a href="viewtopice563.html?p=2610#p2610"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a></strong> &raquo; Tue Apr 26, 2011 12:33 am </p>

			

			<div class="content">Unfortunately there has been a great deal of misinformation regarding my interests and actions.  I have been a very active Funston pilot and contributor to the site.  I have tried very hard to discuss a proposal that will have little or no impact on hang gliding at Funston.  Unfortunately, I've been put in a position in which pursuing my proposal through proper and legal channels is seen as a threat.<br /><br />The following is an email I sent to Urs Kellenberger earlier today.  I hope it helps express my position more clearly than has been represented:<br /><br />Urs,<br /><br />Thanks for taking the time to speak with me at length about the current situation.  I'm sorry if I had failed to accurately convey my initial proposal to you.  As I hope you know, I value Funston very much and would not like to see it taken away, NOR am I looking to have it opened to PG flying by myself or anyone else.<br /><br />What I am proposing is that a very small number of existing Funston HG pilots be given access to land their PG's in the south corner of the LZ so that we can hang with our hang gliding friends, carpool, etc.  Just Friday, Steve Morris flew Funston in his Millennium and I flew Mussel Rock in my bag.  I would have liked to carpool up with him as I used to, and perhaps take a spin in his Millennium (as I sometimes do now when he has the motor on it).<br /><br />My proposal mirrors the arrangement that was recently reached for tandem flying at the Fort.  It would initially be done on a trial basis so that it could be quickly ended if it proved to cause the problems some fear it might.  Also, like the tandem arrangement, it would only permit a small number of pilots to take advantage of it.  That group of pilots would be listed by name.  They would all be known Funston pilots (H3 or above).  They would obviously have to be current USHPA members, with signed waivers, Funston helmet stickers, AND be P3 or above (I'm H4/P4).<br /><br />Just as the Fellow Feathers self-police the site they value so much, this group of pilots would self police this arrangement.  Any pilot landing a PG not on the approved list would be subject to a fine by the rangers in addition to any measure USHPA might choose to take.  The pilots on this list will agree to make clear to other PG pilots that the site is not open to PG flight or landing with the exception of the listed Funston HG rated pilots.  The listed pilots would also agree to help the club identify any PG pilots that land at the Fort illegally.<br /><br />I hope you can see that I feel strongly enough about this arrangement that I would do whatever I could to protect it.<br /><br />As to flying the Funston ridge, I honestly don't know of any PG pilots that are interested in doing so.  I can tell you that many aren't aware it's considered to be off-limits.  It's simply a pain in the butt to get there, and it's honestly not terribly interesting.  There are dozens of places we practice launches and landings from the stables down to the trailer park.  That's more than enough room and variety.  My interest is NOT in flying the Funston ridge, but rather hanging out with my friends at Funston on occasion.<br /><br />In addition to the restrictions I've listed above, I would propose:<br />- No PG could under any circumstance fly as far north as the HG launch under this arrangement.  When we enter Funston property, it is to land.<br />- No touch and go's.  When we land, we must set the wing down and get out of our harness.<br />- No loitering at Funston.  When we launch, we must turn left and head South.<br /><br />Because of specific concerns I've heard from HG'ers, I would add the following:<br />- No launching or landing of PG's when the wind is less than 10 mph.<br />- No launching or landing when the wind is cross by more than 40 degrees.<br /><br />Frankly, these conditions would not be of interest as it would be difficult to enter or exit Funston without the potential of sinking out.<br /><br />I hope you can appreciate why I'm making this proposal, and that I'm looking to cause little or no impact to hang gliding at the Fort.  Because we are all hang gliding pilots, we understand traffic and landing patterns, and how to stay out of the way.  We also have a vested interest in protecting the flying site as you do.<br /><br />I'm very willing and interested in discussing this with the club officers, and would welcome the discussion of any further rules or restrictions that would help to alleviate the concerns of Funston pilots.<br /><br />It's clearly unfortunate that any misunderstanding of my intentions has led to this escalation. I hope we can pursue this through much more productive and cooperative means.  Please let me know if you'd be willing to participate in such a discussion.<br /><br />Best regards,<br /><br />Rick Cavallaro</div>

			

		</div>

		
			<dl class="postprofile" id="profile2610">
			<dt>
				<a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 93</dd><dd><strong>Joined:</strong> Wed Apr 20, 2011 11:40 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2611" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting6e6a.html?mode=quote&amp;f=5&amp;p=2611" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2611">Re: Cavallaro messing with Funston</a></h3>
			<p class="author"><a href="viewtopicce0b.html?p=2611#p2611"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist7aa3.html?mode=viewprofile&amp;u=129">crvalley</a></strong> &raquo; Tue Apr 26, 2011 1:30 am </p>

			

			<div class="content">Rick,<br /><br />Rather than sending emails to Urs, why not come to the next Club meeting and discuss all of this face to face with Club members?<br /><br />This is what people did long before bulletin boards...you remember those days, right?<br /><br />Best regards,<br /><br />Chris</div>

			<div id="sig2611" class="signature">“We abuse land because we see it as a commodity belonging to us. When we see land as a community to which we belong, we may begin to use it with love and respect.” ― Aldo Leopold</div>

		</div>

		
			<dl class="postprofile" id="profile2611">
			<dt>
				<a href="memberlist7aa3.html?mode=viewprofile&amp;u=129">crvalley</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 214</dd><dd><strong>Joined:</strong> Sun Apr 10, 2005 9:16 am</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2612" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postingbac4.php?mode=quote&amp;f=5&amp;p=2612" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2612">Re: Cavallaro messing with Funston</a></h3>
			<p class="author"><a href="viewtopic419b.html?p=2612#p2612"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a></strong> &raquo; Tue Apr 26, 2011 1:52 am </p>

			

			<div class="content"><blockquote><div><cite>crvalley wrote:</cite>Rick,<br /><br />Rather than sending emails to Urs, why not come to the next Club meeting and discuss all of this face to face with Club members?</div></blockquote><br /><br />I've been around for a long time.  I was aware of the potential for an emotional reaction to the idea.  I felt it best to first discuss the proposal with some of the old-timers I've known from the site.  I discussed it with Chief and Denise, Henry Bittner, Steve Rodriguez, and others (in addition to my biwingual friends).  Because I haven't been much of a regular at Funston lately, and because of the initial extremely negative reception of my proposal to install a web camera, I discussed with some of the other biwingual pilots what would be the most prudent approach.  We agreed that people like Dingo, Jose, Marco, Damien, and a few others would likely raise fewer eyebrows by bringing it up at a meeting.  And so they did.  I understand it was quite acrimonious despite their efforts.<br /><br /><blockquote class="uncited"><div>This is what people did long before bulletin boards...you remember those days, right?</div></blockquote><br /><br />I'm an old man.  I don't remember those days at all.<br /><br />In point of fact, I've oddly enough made a number of close and long-term friends world-wide through discussion boards.  One is visiting right now from Australia.  Some of you may know that I met JB through a debate he and I had on a hang gliding discussion board many years ago.   I'm currently working with another friend in Germany that I only know through internet forums, and I have another good friend from Australia that comes skiing with us most years - that I met on an R/C heli forum.  <br /><br />So yes, I'm all for speaking with folks face-to-face - but am still in awe of the power of the internet.<br /><br />Some have suggested I attend a club meeting while others have suggested I meet only with the club officers, and others still have suggested I let the more current Funston pilots lay the groundwork.   As a result of the discussion on Jack's site, the <span style="font-style: italic">ONLY </span>person I felt threatened by was you.  Perhaps my read on that is wrong.<br /><br />If people feel it would be of use to come to a meeting to discuss this - I'll be there.  I'm anything but shy.<br /><br />Rick Cavallaro<br /><br />ETA: I should add that your club president has suggested that I'm to be treated as armed and dangerous at all times, in the sky or on the ground.  Apparently my picture has been circulated so that people can immediately call the rangers to have me arrested or removed from the site.  That being said, it might be difficult to attend a meeting at Funston right now.<br /><br />In fairness, Tom's statements stem from an unfortunate outburst of mine toward Steve Rodriguez.  Steve considered the outburst a threat.  Steve did have me about as mad as I can remember being - but I don't think my statement actually qualifies as a threat.  I emailed Steve shortly after to apologize for my words.  Tom now claims that I'm the sort of danger that could lead to another &quot;Dan Murphy incident&quot;.  Harsher and less accurate words were never spoken, and I guess Tom doesn't remember that Dan was a friend of mine as well.</div>

			
				<div class="notice">Last edited by <a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a> on Tue Apr 26, 2011 2:01 am, edited 1 time in total.
					
				</div>
			

		</div>

		
			<dl class="postprofile" id="profile2612">
			<dt>
				<a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 93</dd><dd><strong>Joined:</strong> Wed Apr 20, 2011 11:40 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2613" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting2327.html?mode=quote&amp;f=5&amp;p=2613" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2613">Re: Cavallaro messing with Funston</a></h3>
			<p class="author"><a href="viewtopic815f.php?p=2613#p2613"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist7aa3.html?mode=viewprofile&amp;u=129">crvalley</a></strong> &raquo; Tue Apr 26, 2011 2:00 am </p>

			

			<div class="content"><blockquote><div><cite>spork wrote:</cite>If people feel it would be of use to come to a meeting to discuss this - I'll be there.  I'm anything but shy.<br /><br />Rick Cavallaro</div></blockquote><br /><br />Sounds good...Glad to hear you're not shy.  <br /><br />You can discuss your concerns at the next Club meeting.<br /><br />Chris</div>

			<div id="sig2613" class="signature">“We abuse land because we see it as a commodity belonging to us. When we see land as a community to which we belong, we may begin to use it with love and respect.” ― Aldo Leopold</div>

		</div>

		
			<dl class="postprofile" id="profile2613">
			<dt>
				<a href="memberlist7aa3.html?mode=viewprofile&amp;u=129">crvalley</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 214</dd><dd><strong>Joined:</strong> Sun Apr 10, 2005 9:16 am</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2614" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postingfaf8.html?mode=quote&amp;f=5&amp;p=2614" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2614">Re: Cavallaro messing with Funston</a></h3>
			<p class="author"><a href="viewtopic1697.php?p=2614#p2614"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a></strong> &raquo; Tue Apr 26, 2011 2:02 am </p>

			

			<div class="content"><blockquote><div><cite>crvalley wrote:</cite><blockquote><div><cite>spork wrote:</cite>If people feel it would be of use to come to a meeting to discuss this - I'll be there.  I'm anything but shy.<br /><br />Rick Cavallaro</div></blockquote><br /><br />Sounds good...Glad to hear you're not shy.  <br /><br />You can discuss your concerns at the next Club meeting.<br /><br />Chris</div></blockquote><br /><br />Please see my ETA.</div>

			

		</div>

		
			<dl class="postprofile" id="profile2614">
			<dt>
				<a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 93</dd><dd><strong>Joined:</strong> Wed Apr 20, 2011 11:40 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2615" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postingf25f.html?mode=quote&amp;f=5&amp;p=2615" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2615">Re: Cavallaro messing with Funston</a></h3>
			<p class="author"><a href="viewtopic8daa.php?p=2615#p2615"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist75f6.html?mode=viewprofile&amp;u=131">zippidy</a></strong> &raquo; Tue Apr 26, 2011 7:14 am </p>

			

			<div class="content"><blockquote><div><cite>spork wrote:</cite>Unfortunately there has been a great deal of misinformation regarding my interests and actions.  I have been a very active Funston pilot and contributor to the site.  I have tried very hard to discuss a proposal that will have little or no impact on hang gliding at Funston.  Unfortunately, I've been put in a position in which pursuing my proposal through proper and legal channels is seen as a threat.</div></blockquote><br /><br /><blockquote class="uncited"><div>As I hope you know, I value Funston very much and would not like to see it taken away...</div></blockquote><br /><br /><blockquote class="uncited"><div>It's clearly unfortunate that any misunderstanding of my intentions has led to this escalation.</div></blockquote><br /><br />Rick, based on your comments on hanggliding.org I understand that if you don't get your way, your intention is to go as far as filing a lawsuit against the GGNRA. I also believe you agree that filing such a lawsuit will have the distinct possible outcome of shutting down hang gliding at the fort altogether.<br /><br />Have I misunderstood your intentions?  I hope so. Please clarify.<br /><br />Brian</div>

			<div id="sig2615" class="signature">Brian Foster</div>

		</div>

		
			<dl class="postprofile" id="profile2615">
			<dt>
				<a href="memberlist75f6.html?mode=viewprofile&amp;u=131">zippidy</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 19</dd><dd><strong>Joined:</strong> Tue Apr 12, 2005 11:40 am</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2617" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postinge86e.php?mode=quote&amp;f=5&amp;p=2617" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2617">Re: Cavallaro messing with Funston</a></h3>
			<p class="author"><a href="viewtopic0748.html?p=2617#p2617"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a></strong> &raquo; Tue Apr 26, 2011 4:10 pm </p>

			

			<div class="content">My interest is in negotiating an arrangement with the club and potentially the GGNRA that would have little or no impact on hang gliding operations.  I have put a number of restrictions in my proposal to make sure that we don't inconvenience HG in any way and that we don't open the door to PG's flying at the Fort.  I have invited the inclusion of additional restrictions as necessary to satisfy the club that this arrangement is safe, doesn't inconvenience, HG, and doesn't lead to other problems.  It has never been my interest to open the Fort to PG flying by myself or anyone else.  The last thing I want is to lose this flying site.<br /><br />The one and only communication I've had with the rangers was to get clarification on their stance on airspace - this was a matter that Urs and Steve had directly opposing views on.  Both were aware that I intended to ask the rangers for clarification, and neither suggested that I not do so.<br /><br />As to &quot;getting my way&quot;, I think that's an unfortunate choice of words.  &quot;My way&quot; is to arrive at a fair and safe arrangement that inconveniences no one.  I have said, and I will say again, that I will accept <span style="font-weight: bold"><span style="font-style: italic">ANY </span></span>arrangement that would be considered fair by a typical disinterested 3rd party.  That arrangement does not necessarily have to involve anyone landing PG's at the fort.<br /><br />In no case will I take actions that are illegal or designed to put the site in jeopardy.  As to what proper and legal channels I would pursue if I don't feel I've been given fair consideration, I can't possibly say.<br /><br />Rick C.</div>

			

		</div>

		
			<dl class="postprofile" id="profile2617">
			<dt>
				<a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 93</dd><dd><strong>Joined:</strong> Wed Apr 20, 2011 11:40 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2618" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting7545.html?mode=quote&amp;f=5&amp;p=2618" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2618">Re: Cavallaro messing with Funston</a></h3>
			<p class="author"><a href="viewtopicaec8.html?p=2618#p2618"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist1d86.php?mode=viewprofile&amp;u=1867">cliffblack1</a></strong> &raquo; Tue Apr 26, 2011 4:31 pm </p>

			

			<div class="content">The way I understand airspace is that the land owner (GGNRA) controls the air space up to 700 AGL (above ground level). One more item:If you want to post on the message board, please identify yourself with your real name.. first and last. If you don't then the moderator &quot;should delete you&quot; from posting.  just sayin.. <br />Best Regards Tom Jensen</div>

			

		</div>

		
			<dl class="postprofile" id="profile2618">
			<dt>
				<a href="memberlist1d86.php?mode=viewprofile&amp;u=1867">cliffblack1</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 27</dd><dd><strong>Joined:</strong> Fri Dec 10, 2010 12:34 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2619" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting3f72.html?mode=quote&amp;f=5&amp;p=2619" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2619">Re: Cavallaro messing with Funston</a></h3>
			<p class="author"><a href="viewtopicadc6.php?p=2619#p2619"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist5346.html?mode=viewprofile&amp;u=1948">Jose</a></strong> &raquo; Tue Apr 26, 2011 4:57 pm </p>

			

			<div class="content">Funston is class G airspace, it's uncontrolled airspace:<br /><br /><a href="http://www.flickr.com/photos/33235702@N07/5659112289/" class="postlink"><img src="http://farm6.static.flickr.com/5146/5659112289_3c95207171_o.jpg" alt="Image" /></a><br /><a href="http://www.flickr.com/photos/33235702@N07/5659112289/" class="postlink">airspace</a> by <a href="http://www.flickr.com/people/33235702@N07/" class="postlink">jose9878</a>, on Flickr<br /><br />If you don't know who this is, you haven't been at the Fort lately.</div>

			
				<div class="notice">Last edited by <a href="memberlist5346.html?mode=viewprofile&amp;u=1948">Jose</a> on Tue Apr 26, 2011 5:21 pm, edited 1 time in total.
					
				</div>
			

		</div>

		
			<dl class="postprofile" id="profile2619">
			<dt>
				<a href="memberlist5346.html?mode=viewprofile&amp;u=1948">Jose</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 29</dd><dd><strong>Joined:</strong> Tue Mar 29, 2011 9:53 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2620" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting1ad0.html?mode=quote&amp;f=5&amp;p=2620" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2620">Re: Cavallaro messing with Funston</a></h3>
			<p class="author"><a href="viewtopic4cdb.html?p=2620#p2620"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a></strong> &raquo; Tue Apr 26, 2011 5:15 pm </p>

			

			<div class="content">Hey Tom - I don't know if you remember me.  You took me for a ride in your KitFox out of Frasier Lake many years ago.<br /><br /><blockquote><div><cite>cliffblack1 wrote:</cite>The way I understand airspace is that the land owner (GGNRA) controls the air space up to 700 AGL (above ground level).</div></blockquote><br /><br />Negative.  There is a complicated network of restrictions, but the landowner never controls the airspace.   It was established long ago that the FAA has sole jurisdiction of all airspace, and that the landowner has rights to that airspace (i.e. they can erect bldgs, antennas, etc.).  Interestingly, CA has certain laws regarding overflight of state parks (500' minimum for powered craft); but those laws are clearly counter to FAA and would never stand a test in court.  Additionally, NOAA recently defined essentially the entire CA coast a marine wildlife preserve.  They are trying to enforce 1000' and 2000' floors for powered craft, and they are doing battle with the FAA at the moment.  AOPA is in on that action because it affects tons of GA pilots - some very much.  That battle will be more interesting.  On the one hand NOAA is federal as well, but on the other hand, the law is clear regarding the FAA having sole jurisdiction of the airspace - right down to the ground in all cases.<br /><br />Certain national parks (for example) have managed to get the FAA to restrict airspace over their land, but others have famously tried for many years and failed.<br /><br /><blockquote class="uncited"><div>One more item:If you want to post on the message board, please identify yourself with your real name.. first and last.</div></blockquote><br /><br />Will do.  I did include my full name in one of my first posts, and I suppose I figured it was obvious who I am.  I never intended to be coy about my identity, but I notice that your rule doesn't seem to apply broadly on this board.<br /><br /><blockquote class="uncited"><div>If you don't then the moderator &quot;should delete you&quot; from posting.  just sayin.. </div></blockquote><br /><br />Quite frankly, I imagine it's only an oversight on the mods part that I haven't been deleted already.<br /><br />Rick Cavallaro</div>

			

		</div>

		
			<dl class="postprofile" id="profile2620">
			<dt>
				<a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 93</dd><dd><strong>Joined:</strong> Wed Apr 20, 2011 11:40 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2621" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting0ccd.php?mode=quote&amp;f=5&amp;p=2621" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2621">Re: Cavallaro messing with Funston</a></h3>
			<p class="author"><a href="viewtopicc6ea.html?p=2621#p2621"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a></strong> &raquo; Tue Apr 26, 2011 5:22 pm </p>

			

			<div class="content"><blockquote><div><cite>cliffblack1 wrote:</cite>One more item:If you want to post on the message board, please identify yourself with your real name.. first and last. If you don't then the moderator &quot;should delete you&quot; from posting.  just sayin..</div></blockquote><br /><br />Users who have posted in this thread:<br /><br />thermal pirate: no name given.  I don't know who he is.<br />Jose: first name given; I do know who he is.<br />Dan Brown: uses his full name as his on-line name<br />spork: full name given at the end of the first post<br />crvalley: full name given<br />zippidy: full name given<br />cliffblack1: full name given</div>

			

		</div>

		
			<dl class="postprofile" id="profile2621">
			<dt>
				<a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 93</dd><dd><strong>Joined:</strong> Wed Apr 20, 2011 11:40 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2622" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postingd75b.html?mode=quote&amp;f=5&amp;p=2622" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2622">Re: Cavallaro messing with Funston</a></h3>
			<p class="author"><a href="viewtopicaaad.php?p=2622#p2622"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a></strong> &raquo; Tue Apr 26, 2011 5:24 pm </p>

			

			<div class="content"><blockquote><div><cite>Jose wrote:</cite>Funston is class G airspace, it's uncontrolled airspace.</div></blockquote><br /><br />Actually, I believe it's SFO Class B above the high water mark.  I was not aware of this until Urs mentioned it to me a few days ago.</div>

			

		</div>

		
			<dl class="postprofile" id="profile2622">
			<dt>
				<a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 93</dd><dd><strong>Joined:</strong> Wed Apr 20, 2011 11:40 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2623" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postinge07b.html?mode=quote&amp;f=5&amp;p=2623" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2623">Re: Cavallaro messing with Funston</a></h3>
			<p class="author"><a href="viewtopiccb84.html?p=2623#p2623"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist5346.html?mode=viewprofile&amp;u=1948">Jose</a></strong> &raquo; Tue Apr 26, 2011 5:29 pm </p>

			

			<div class="content">Class B airspace extends 7 miles from the runway in a broken circle, the floor changes from ground level to 1500' from Rockaway Beach to Mussel Rock.  It's clearly marked with hang gliding from Pacifica to Lake Merced, therefore it doesn't really matter but to continue on with the airspace class, it's class G &amp; E airspace from Mussel Rock to Ocean Beach &amp; beyond.... making Funston class G airspace upto 700' ft &amp; class E from 700' - 2100'.  The ceiling is 1500' south of Mussel &amp; 2100' north of Mussel where it again turns into class B.  <br /><br />Draw a line from the runways to the coast &amp; compare this to Google maps:<br /><br /><a href="http://www.flickr.com/photos/33235702@N07/5659827202/" class="postlink"><img src="http://farm6.static.flickr.com/5103/5659827202_ff99180ca0_o.png" alt="Image" /></a><br /><a href="http://www.flickr.com/photos/33235702@N07/5659827202/" class="postlink">airspace2</a> by <a href="http://www.flickr.com/people/33235702@N07/" class="postlink">jose9878</a>, on Flickr</div>

			
				<div class="notice">Last edited by <a href="memberlist5346.html?mode=viewprofile&amp;u=1948">Jose</a> on Tue Apr 26, 2011 6:34 pm, edited 2 times in total.
					
				</div>
			

		</div>

		
			<dl class="postprofile" id="profile2623">
			<dt>
				<a href="memberlist5346.html?mode=viewprofile&amp;u=1948">Jose</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 29</dd><dd><strong>Joined:</strong> Tue Mar 29, 2011 9:53 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2624" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting2e40.php?mode=quote&amp;f=5&amp;p=2624" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2624">Re: Cavallaro messing with Funston</a></h3>
			<p class="author"><a href="viewtopicb4b8.html?p=2624#p2624"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a></strong> &raquo; Tue Apr 26, 2011 6:30 pm </p>

			

			<div class="content"><blockquote><div><cite>Jose wrote:</cite>Class B airspace extends 7 miles from the runway in a broken circle, the floor changes from ground level to 1500' from Rockaway Beach to Mussel Rock.  It's clearly marked with hang gliding from Pacifica to Lake Merced, therefore it doesn't really matter.  It's class G &amp; E airspace from the Mussel Rock to Ocean Beach &amp; beyond, making Funston class G airspace upto 700' ft &amp; class E from 700' - 2100'.  The ceiling is 1500' south of Mussel &amp; 2100' north of mussel.  </div></blockquote><br /><br />That all makes perfect sense - but there's one question... There's clearly a region that hugs the coast which gives us the cutout you describe.  On the chart there's no way to tell just exactly where the line lies.  Urs tells me it extends only up to the high tide mark.  I suspect he's right.  If so, that means Class B extends from the sand to 10,000' above the high tide mark.</div>

			

		</div>

		
			<dl class="postprofile" id="profile2624">
			<dt>
				<a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 93</dd><dd><strong>Joined:</strong> Wed Apr 20, 2011 11:40 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2625" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting77ef.html?mode=quote&amp;f=5&amp;p=2625" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2625">Re: Cavallaro messing with Funston</a></h3>
			<p class="author"><a href="viewtopic37f0.php?p=2625#p2625"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist5346.html?mode=viewprofile&amp;u=1948">Jose</a></strong> &raquo; Tue Apr 26, 2011 6:37 pm </p>

			

			<div class="content">It's clearly marked with hang gliding from Pacifica to Lake Merced, therefore it doesn't really matter.</div>

			

		</div>

		
			<dl class="postprofile" id="profile2625">
			<dt>
				<a href="memberlist5346.html?mode=viewprofile&amp;u=1948">Jose</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 29</dd><dd><strong>Joined:</strong> Tue Mar 29, 2011 9:53 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2626" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postingd233.html?mode=quote&amp;f=5&amp;p=2626" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2626">Re: Cavallaro messing with Funston</a></h3>
			<p class="author"><a href="viewtopic3d4f.html?p=2626#p2626"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a></strong> &raquo; Tue Apr 26, 2011 6:42 pm </p>

			

			<div class="content"><blockquote><div><cite>Jose wrote:</cite>It's clearly marked with hang gliding from Pacifica to Lake Merced, therefore it doesn't really matter.</div></blockquote><br /><br />For the sake of argument (and our site) I'm inclined to agree with you.  From the point of view of a pedant, I would disagree.  Seems like a good time to smile, keep quiet, and fly.  I'll be out there tomorrow.  Will I see you Jose?<br /><br />Rick Cavallaro</div>

			

		</div>

		
			<dl class="postprofile" id="profile2626">
			<dt>
				<a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 93</dd><dd><strong>Joined:</strong> Wed Apr 20, 2011 11:40 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2627" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting819c.html?mode=quote&amp;f=5&amp;p=2627" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2627">Re: Cavallaro messing with Funston</a></h3>
			<p class="author"><a href="viewtopic03c2.php?p=2627#p2627"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist5346.html?mode=viewprofile&amp;u=1948">Jose</a></strong> &raquo; Tue Apr 26, 2011 6:52 pm </p>

			

			<div class="content">Of course you will.  Watch out for the rainbow hangglider, they've cut me loose!  and I'm...a coming after you! <img src="images/smilies/icon_mrgreen.gif" alt=":mrgreen:" title="Mr. Green" /></div>

			

		</div>

		
			<dl class="postprofile" id="profile2627">
			<dt>
				<a href="memberlist5346.html?mode=viewprofile&amp;u=1948">Jose</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 29</dd><dd><strong>Joined:</strong> Tue Mar 29, 2011 9:53 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2629" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting1e2b.html?mode=quote&amp;f=5&amp;p=2629" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2629">Re: Cavallaro messing with Funston</a></h3>
			<p class="author"><a href="viewtopic6b2b.html?p=2629#p2629"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlistfe9c.html?mode=viewprofile&amp;u=3">Daniel Pifko</a></strong> &raquo; Tue Apr 26, 2011 7:57 pm </p>

			

			<div class="content"><blockquote><div><cite>cliffblack1 wrote:</cite>The way I understand airspace is that the land owner (GGNRA) controls the air space up to 700 AGL (above ground level). One more item:If you want to post on the message board, please identify yourself with your real name.. first and last. If you don't then the moderator &quot;should delete you&quot; from posting.  just sayin.. <br />Best Regards Tom Jensen</div></blockquote><br /><br />Hi Tom,<br /><br />For the record, this club forum has never required that someone use their real name to post on the board.  People have generally been polite and accommodating in identifying themselves.  That said, (at least when I was Tech Director) because we get an incredible number of spam registrations, only accounts that we can reasonably identify as human and truly interested in flying at FF have been enabled with the permission to post.  <br /><br />Daniel</div>

			

		</div>

		
			<dl class="postprofile" id="profile2629">
			<dt>
				<a href="memberlistfe9c.html?mode=viewprofile&amp;u=3"><img src="http://www.pifko.com/fly/images/avatar.jpg" width="60" height="80" alt="User avatar" /></a><br />
				<a href="memberlistfe9c.html?mode=viewprofile&amp;u=3">Daniel Pifko</a>
			</dt>

			<dd>Site Admin</dd>

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 249</dd><dd><strong>Joined:</strong> Tue Jan 13, 2004 5:23 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2634" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting9f64.php?mode=quote&amp;f=5&amp;p=2634" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2634">Re: Cavallaro messing with Funston</a></h3>
			<p class="author"><a href="viewtopic92a7.html?p=2634#p2634"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944">bobk</a></strong> &raquo; Tue Apr 26, 2011 9:05 pm </p>

			

			<div class="content"><blockquote><div><cite>spork wrote:</cite>My interest is in negotiating an arrangement with the club and potentially the GGNRA that would have little or no impact on hang gliding operations.  I have put a number of restrictions in my proposal to make sure that we don't inconvenience HG in any way and that we don't open the door to PG's flying at the Fort.  I have invited the inclusion of additional restrictions as necessary to satisfy the club that this arrangement is safe, doesn't inconvenience, HG, and doesn't lead to other problems.  It has never been my interest to open the Fort to PG flying by myself or anyone else.  The last thing I want is to lose this flying site.</div></blockquote><br />I believe you Rick, but once the camel's nose is under the tent ... well, there goes the tent.<br /><br />I'm already causing enough aggravation on another topic here, so I'll try to be brief.<br /><br />I fly both HG and PG (H4/P4), and I remember being disappointed that I couldn't fly my PG at Fort Funston during my first visit several years ago. But I've also seen the mess that the PG crowd has made at Torrey Pines. Hang gliding was slowly being edged out to the point where we had to start a separate club (the <span style="font-weight: bold"><a href="http://torreyhawks.org/" class="postlink">Torrey Hawks</a></span>) to regain our own voice and representation (thanks to those Funston pilots who've supported us with their membership).<br /><br />My point to you, Rick, is that while your intentions may be noble, they may end up destroying the relative peace you currently have. You may be willing to draw the line where you've stated, but others may carry it beyond that regardless of what you say or intend. If that happens, are you really willing to go down in history as &quot;that guy&quot; who ruined hang gliding at Fort Funston? I'm not asking that as a rhetorical question, but as a question that you should really consider carefully before you move forward. You're taking a very big risk for what seems like the small inconvenience of driving a few minutes between flying your PG and hanging out with your HG friends.<br /><br />That's all. I'm sorry for the interruption.<br /><br />Bob Kuczewski</div>

			<div id="sig2634" class="signature"><span style="font-size: 130%; line-height: 116%;"><span style="color: #000080"><span style="font-style: italic">Join a National Hang Gliding Organization:</span></span> <span style="font-weight: bold"><span style="color: #000080"><a href="http://ushawks.org/" class="postlink">US Hawks at ushawks.org</a></span></span></span></div>

		</div>

		
			<dl class="postprofile" id="profile2634">
			<dt>
				<a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944"><img src="download/file3928.html?avatar=1944_1390380842.jpeg" width="200" height="150" alt="User avatar" /></a><br />
				<a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944">bobk</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 138</dd><dd><strong>Joined:</strong> Tue Mar 22, 2011 1:53 pm</dd>
			<dd>
				<ul class="profile-icons">
					<li class="web-icon"><a href="http://ushawks.org/" title="WWW: http://ushawks.org"><span>Website</span></a></li>
				</ul>
			</dd>
		

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2636" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting6dbb.html?mode=quote&amp;f=5&amp;p=2636" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2636">Re: Cavallaro messing with Funston</a></h3>
			<p class="author"><a href="viewtopicac9f.html?p=2636#p2636"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a></strong> &raquo; Tue Apr 26, 2011 10:17 pm </p>

			

			<div class="content"><blockquote><div><cite>bobk wrote:</cite>I believe you Rick, but once the camel's nose is under the tent ... well, there goes the tent.</div></blockquote><br /><br />I have to respectfully disagree Bob.  To my knowledge paragliders don't care about flying the Fort.  Our reason for pursuing an arrangement is not to fly the Fort, but to be able to land off in one corner so we can hang out with our friends on both sides of the fence.    Also, I have to believe that having an arrangement with the PG community will give the club infinitely more leverage than the current arrangement that has nothing at all to say about an unrated PG pilot flying that airspace.  If that person is not a Funston pilot and not a member of USHGA, it's not possible to threaten that person with a ban or rating revocation as is being done in my case.    But frankly, if they wanted to be flying that airspace, they'd be doing so already.<br /><br />I honestly believe two things:<br />1) Ultimately it will end up being an integrated site one day.  I attribute this simply to the trend - not to any devious plans nor to my ability to see the future.<br />2) That day will come sooner if the club doesn't make any effort to appear to offer anything that can be seen as fair access in the smallest way.<br /><br />Please don't read that as a threat.  It is not one.  It is just my personal opinion.  And given the choice, I'd rather that day come later rather than sooner.<br /><br />Years ago I lobbied hard to get the club to conduct its business in a way that was beyond reproach and to post its minutes and bylaws on the site.  People fought that hard, claiming it would expose the club to all sorts of problems.  Finally it was done, and is done to this day.  I truly believe it has protected the club and the site more than it ever could have hurt it.<br /><br />Best regards,<br /><br />Rick Cavallaro</div>

			

		</div>

		
			<dl class="postprofile" id="profile2636">
			<dt>
				<a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 93</dd><dd><strong>Joined:</strong> Wed Apr 20, 2011 11:40 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2637" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting9392.php?mode=quote&amp;f=5&amp;p=2637" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2637">Re: Cavallaro messing with Funston</a></h3>
			<p class="author"><a href="viewtopicfb9a.html?p=2637#p2637"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944">bobk</a></strong> &raquo; Tue Apr 26, 2011 10:29 pm </p>

			

			<div class="content"><blockquote><div><cite>spork wrote:</cite><blockquote><div><cite>bobk wrote:</cite>I believe you Rick, but once the camel's nose is under the tent ... well, there goes the tent.</div></blockquote><br /><br />I have to respectfully disagree Bob.</div></blockquote><br />Then we both respectfully disagree. If you continue on, then I hope you're the one who's right.   <img src="images/smilies/icon_wink.html" alt=":wink:" title="Wink" /> <br /><br />By the way, since you mentioned conducting business beyond reproach, maybe you'd be the fellow to open a topic supporting open voting by the USHPA Board. I urged Daniel to do so on the &quot;Prohibiting Non-Mmebers From Discsussion Board&quot; topic, but I'm not very hopeful that he'll do it. You seem to be a &quot;mover and shaker&quot;, so maybe that would interest you.<br /><br />Regardless of any other comments I've made, Funston is a great flying site, and I thank all those who've preserved it for all these years.<br /><br />Sincerely,<br />Bob Kuczewski</div>

			<div id="sig2637" class="signature"><span style="font-size: 130%; line-height: 116%;"><span style="color: #000080"><span style="font-style: italic">Join a National Hang Gliding Organization:</span></span> <span style="font-weight: bold"><span style="color: #000080"><a href="http://ushawks.org/" class="postlink">US Hawks at ushawks.org</a></span></span></span></div>

		</div>

		
			<dl class="postprofile" id="profile2637">
			<dt>
				<a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944"><img src="download/file3928.html?avatar=1944_1390380842.jpeg" width="200" height="150" alt="User avatar" /></a><br />
				<a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944">bobk</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 138</dd><dd><strong>Joined:</strong> Tue Mar 22, 2011 1:53 pm</dd>
			<dd>
				<ul class="profile-icons">
					<li class="web-icon"><a href="http://ushawks.org/" title="WWW: http://ushawks.org"><span>Website</span></a></li>
				</ul>
			</dd>
		

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2638" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting7d94.html?mode=quote&amp;f=5&amp;p=2638" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2638">Re: Cavallaro messing with Funston</a></h3>
			<p class="author"><a href="viewtopic8bae.php?p=2638#p2638"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a></strong> &raquo; Tue Apr 26, 2011 10:43 pm </p>

			

			<div class="content"><blockquote><div><cite>bobk wrote:</cite>By the way, since you mentioned conducting business beyond reproach, maybe you'd be the fellow to open a topic supporting open voting by the USHPA Board.</div></blockquote><br /><br />I thank you for your invitation to tip-toe through another mine-field, but no thanks.  <img src="images/smilies/icon_mrgreen.gif" alt=":mrgreen:" title="Mr. Green" /><br /><br />ETA:<br />Rick Cavallaro</div>

			

		</div>

		
			<dl class="postprofile" id="profile2638">
			<dt>
				<a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 93</dd><dd><strong>Joined:</strong> Wed Apr 20, 2011 11:40 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<form id="viewtopic" method="post" action="http://flyfunston.org/bbs/viewtopic.php?f=5&amp;t=1133">

	<fieldset class="display-options" style="margin-top: 0; ">
		<a href="viewtopicf323.html?f=5&amp;t=1133&amp;start=25" class="right-box right">Next</a>
		<label>Display posts from previous: <select name="st" id="st"><option value="0" selected="selected">All posts</option><option value="1">1 day</option><option value="7">7 days</option><option value="14">2 weeks</option><option value="30">1 month</option><option value="90">3 months</option><option value="180">6 months</option><option value="365">1 year</option></select></label>
		<label>Sort by <select name="sk" id="sk"><option value="a">Author</option><option value="t" selected="selected">Post time</option><option value="s">Subject</option></select></label> <label><select name="sd" id="sd"><option value="a" selected="selected">Ascending</option><option value="d">Descending</option></select> <input type="submit" name="sort" value="Go" class="button2" /></label>
		
	</fieldset>

	</form>
	<hr />


<div class="topic-actions">
	<div class="buttons">
	
		<div class="reply-icon"><a href="posting8936.html?mode=reply&amp;f=5&amp;t=1133" title="Post a reply"><span></span>Post a reply</a></div>
	
	</div>

	
		<div class="pagination">
			32 posts
			 &bull; <a href="#" onclick="jumpto(); return false;" title="Click to jump to page…">Page <strong>1</strong> of <strong>2</strong></a> &bull; <span><strong>1</strong><span class="page-sep">, </span><a href="viewtopicf323.html?f=5&amp;t=1133&amp;start=25">2</a></span>
		</div>
	
</div>


	<p></p><p><a href="viewforume774.html?f=5" class="left-box left" accesskey="r">Return to General Discussion</a></p>

	<form method="post" id="jumpbox" action="http://flyfunston.org/bbs/viewforum.php" onsubmit="if(this.f.value == -1){return false;}">

	
		<fieldset class="jumpbox">
	
			<label for="f" accesskey="j">Jump to:</label>
			<select name="f" id="f" onchange="if(this.options[this.selectedIndex].value != -1){ document.forms['jumpbox'].submit() }">
			
				<option value="-1">Select a forum</option>
			<option value="-1">------------------</option>
				<option value="9">Discussion Groups</option>
			
				<option value="5" selected="selected">&nbsp; &nbsp;General Discussion</option>
			
				<option value="8">&nbsp; &nbsp;Announcements</option>
			
				<option value="7">&nbsp; &nbsp;For Sale/Wanted</option>
			
				<option value="6">&nbsp; &nbsp;Road Trips</option>
			
				<option value="2">&nbsp; &nbsp;Meeting Minutes and Treasurer Reports</option>
			
				<option value="11">&nbsp; &nbsp;Off Topic</option>
			
			</select>
			<input type="submit" value="Go" class="button2" />
		</fieldset>
	</form>


	<h3>Who is online</h3>
	<p>Users browsing this forum: <span style="color: #9E8DA7;" class="username-coloured">Google [Bot]</span> and 7 guests</p>
</div>

<div id="page-footer">

	<div class="navbar">
		<div class="inner"><span class="corners-top"><span></span></span>

		<ul class="linklist">
			<li class="icon-home"><a href="index.html">Board index</a></li>
				
			<li class="rightside"><a href="memberlista2f5.html?mode=leaders">The team</a> &bull; <a href="ucp033a.html?mode=delete_cookies">Delete all board cookies</a> &bull; All times are UTC - 8 hours [ <abbr title="Daylight Saving Time">DST</abbr> ]</li>
		</ul>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<div class="copyright">Powered by <a href="https://www.phpbb.com/">phpBB</a>&reg; Forum Software &copy; phpBB Group
		
	</div>
</div>

</div>

<div>
	<a id="bottom" name="bottom" accesskey="z"></a>
	<img src="cron5b0b.gif?cron_type=tidy_sessions" width="1" height="1" alt="cron" />
</div>

</body>

<!-- Mirrored from flyfunston.org/bbs/viewtopic.php?p=2638 by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 08 Aug 2021 20:15:03 GMT -->
</html>