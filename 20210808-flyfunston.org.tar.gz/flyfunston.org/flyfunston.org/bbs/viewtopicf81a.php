<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en-us" xml:lang="en-us">

<!-- Mirrored from flyfunston.org/bbs/viewtopic.php?p=3729 by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 08 Aug 2021 20:05:02 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>

<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<meta http-equiv="content-style-type" content="text/css" />
<meta http-equiv="content-language" content="en-us" />
<meta http-equiv="imagetoolbar" content="no" />
<meta name="resource-type" content="document" />
<meta name="distribution" content="global" />
<meta name="keywords" content="" />
<meta name="description" content="" />

<title>Flyfunston &bull; View topic - USHPA BOD meeting</title>



<!--
	phpBB style name: prosilver
	Based on style:   prosilver (this is the default phpBB3 style)
	Original author:  Tom Beddard ( http://www.subBlue.com/ )
	Modified by:
-->

<script type="text/javascript">
// <![CDATA[
	var jump_page = 'Enter the page number you wish to go to:';
	var on_page = '1';
	var per_page = '25';
	var base_url = 'viewtopic0a04.html?f=5&amp;t=1475';
	var style_cookie = 'phpBBstyle';
	var style_cookie_settings = '; path=/; domain=flyfunston.org; secure';
	var onload_functions = new Array();
	var onunload_functions = new Array();

	

	/**
	* Find a member
	*/
	function find_username(url)
	{
		popup(url, 760, 570, '_usersearch');
		return false;
	}

	/**
	* New function for handling multiple calls to window.onload and window.unload by pentapenguin
	*/
	window.onload = function()
	{
		for (var i = 0; i < onload_functions.length; i++)
		{
			eval(onload_functions[i]);
		}
	};

	window.onunload = function()
	{
		for (var i = 0; i < onunload_functions.length; i++)
		{
			eval(onunload_functions[i]);
		}
	};

// ]]>
</script>
<script type="text/javascript" src="styles/prosilver/template/styleswitcher.js"></script>
<script type="text/javascript" src="styles/prosilver/template/forum_fn.js"></script>

<link href="styles/prosilver/theme/print.css" rel="stylesheet" type="text/css" media="print" title="printonly" />
<link href="style7a95.css?id=1&amp;lang=en_us" rel="stylesheet" type="text/css" media="screen, projection" />

<link href="styles/prosilver/theme/normal.css" rel="stylesheet" type="text/css" title="A" />
<link href="styles/prosilver/theme/medium.css" rel="alternate stylesheet" type="text/css" title="A+" />
<link href="styles/prosilver/theme/large.css" rel="alternate stylesheet" type="text/css" title="A++" />



</head>

<body id="phpbb" class="section-viewtopic ltr">

<div id="wrap">
	<a id="top" name="top" accesskey="t"></a>
	<div id="page-header">
		<div class="headerbar">
			<div class="inner"><span class="corners-top"><span></span></span>

			<div id="site-description">
				<a href="index.html" title="Board index" id="logo"><img src="styles/prosilver/imageset/site_logo.gif" width="149" height="52" alt="" title="" /></a>
				<h1>Flyfunston</h1>
				<p>Hang Gliding at Fort Funston</p>
				<p class="skiplink"><a href="#start_here">Skip to content</a></p>
			</div>

		
			<div id="search-box">
				<form action="http://flyfunston.org/bbs/search.php" method="get" id="search">
				<fieldset>
					<input name="keywords" id="keywords" type="text" maxlength="128" title="Search for keywords" class="inputbox search" value="Search…" onclick="if(this.value=='Search…')this.value='';" onblur="if(this.value=='')this.value='Search…';" />
					<input class="button2" value="Search" type="submit" /><br />
					<a href="search.html" title="View the advanced search options">Advanced search</a> 
				</fieldset>
				</form>
			</div>
		

			<span class="corners-bottom"><span></span></span></div>
		</div>

		<div class="navbar">
			<div class="inner"><span class="corners-top"><span></span></span>

			<ul class="linklist navlinks">
				<li class="icon-home"><a href="index.html" accesskey="h">Board index</a>  <strong>&#8249;</strong> <a href="viewforumfdc5.html?f=9">Discussion Groups</a> <strong>&#8249;</strong> <a href="viewforume774.html?f=5">General Discussion</a></li>

				<li class="rightside"><a href="#" onclick="fontsizeup(); return false;" onkeypress="return fontsizeup(event);" class="fontsize" title="Change font size">Change font size</a></li>

				<li class="rightside"><a href="viewtopicdf06.html?f=5&amp;t=1475&amp;view=print" title="Print view" accesskey="p" class="print">Print view</a></li>
			</ul>

			

			<ul class="linklist rightside">
				<li class="icon-faq"><a href="faq.html" title="Frequently Asked Questions">FAQ</a></li>
				
					<li class="icon-logout"><a href="ucp26c3.php?mode=login" title="Login" accesskey="x">Login</a></li>
				
			</ul>

			<span class="corners-bottom"><span></span></span></div>
		</div>

	</div>

	<a name="start_here"></a>
	<div id="page-body">
		
<h2><a href="viewtopic0a04.html?f=5&amp;t=1475">USHPA BOD meeting</a></h2>
<!-- NOTE: remove the style="display: none" when you want to have the forum description on the topic body --><div style="display: none !important;">Talk about Hang Gliding at Ft Funston and the Fellow Feathers Club.<br /></div>

<div class="topic-actions">

	<div class="buttons">
	
		<div class="reply-icon"><a href="posting92c2.php?mode=reply&amp;f=5&amp;t=1475" title="Post a reply"><span></span>Post a reply</a></div>
	
	</div>

	
		<div class="search-box">
			<form method="get" id="topic-search" action="http://flyfunston.org/bbs/search.php">
			<fieldset>
				<input class="inputbox search tiny"  type="text" name="keywords" id="search_keywords" size="20" value="Search this topic…" onclick="if(this.value=='Search this topic…')this.value='';" onblur="if(this.value=='')this.value='Search this topic…';" />
				<input class="button2" type="submit" value="Search" />
				<input type="hidden" name="t" value="1475" />
<input type="hidden" name="sf" value="msgonly" />

			</fieldset>
			</form>
		</div>
	
		<div class="pagination">
			42 posts
			 &bull; <a href="#" onclick="jumpto(); return false;" title="Click to jump to page…">Page <strong>1</strong> of <strong>2</strong></a> &bull; <span><strong>1</strong><span class="page-sep">, </span><a href="viewtopic4927.php?f=5&amp;t=1475&amp;start=25">2</a></span>
		</div>
	

</div>
<div class="clear"></div>


	<div id="p3620" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting97d7.html?mode=quote&amp;f=5&amp;p=3620" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 class="first"><a href="#p3620">USHPA BOD meeting</a></h3>
			<p class="author"><a href="viewtopicab3c.html?p=3620#p3620"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberliste69f.html?mode=viewprofile&amp;u=15" style="color: #AA0000;" class="username-coloured">Steve Rodrigues</a></strong> &raquo; Mon Oct 14, 2013 2:23 pm </p>

			

			<div class="content">Re: USHPA BOD meeting in Seattle, October 10-12, 2013<br />The following summary touches on a few important topics from last weekend’s BOD meeting.<br /><br />&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;<br /><br />Thursday, October 10<br /><br />Disciplinary hearing  for two Fellow Feathers / Fort Funston pilots.<br />About 15 written testimony’s were presented in regard to rules violations at Fort Funston. For the sake of this summary, the members in question are referred to as “Pilot-X” and “Pilot -Y”. After some hours of presentation and discussion, the BOD passed the following motions:<br /><br />“The board, acting in good faith, finds that Pilot -X violated the rules of the USHPA in a material and serious manner and in doing so endangered spectators, other pilots, the Fort Funston Flying Site and the USHPA insurance policy and therefore expels Pilot -X from the Association permanently effective October 19th, 2013, and temporarily revokes all of Pilot -X pilot ratings effective immediately for 30 days.”<br /><br />“The board, acting in good faith, finds that Pilot -Y violated the rules of the USHPA in a material and serious manner and in doing so endangered spectators, the Fort Funston Flying Site and the USHPA insurance policy and therefore suspends Pilot -Y from the Association for one year effective October 19th, 2013, and temporarily revokes all of Pilot -Y pilot ratings effective immediately for 30 days.  After the suspension expires, Pilot -Y will be on probation for one additional year during which Pilot -Y must comply with all Fort Funston and Fellow Feathers regulations.”<br /><br />&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;<br /><br />Friday, October 11<br /><br />Chapter Support Committee<br />Committee discussed subject of hang glider only or paragliding only flying sites. Various committee members pointed out that there are wing-specific flying sites all across the U.S. The committee supports SOP 06-01.04 paragraph E. <br /><br />“Chapters may not, as a matter of policy, negligently or willfully discriminate against pilots of one glider type, either hang glider or paraglider, or discriminate between pilots of equal pilot rating.<br />Chapters must ensure that recreational flight privileges are made available to any and all qualified<br />USHPA members meeting Chapter site requirements in a fair and equitable manner without<br />discrimination.<br /><br />Note: This requirement does not indicate that a site cannot be hang gliding only or paragliding<br />only. Glider specific sites are permissible for safety, land owner, and possibly other conditions.<br /><br />In extraordinary circumstances, a Club may not be able to conform to the organizational requirements.<br />The Club can submit a request for exemption from an organizational requirement to the Chapter Support<br />Committee. Exemptions to requirements must be approved by the Chapter Support Committee and the<br />Board of Directors.&quot;<br /><br />&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;<br /><br />Saturday, October 12<br />General Session<br /><br />The topic of highest priority, IMHO, was preservation of our site insurance.<br />Our recent dues increase was a result of increased insurance costs that were in turn a result of claims against the policy. Members can expect rising insurance costs as claims continue, and the USHPA is considering various funding options. Accident claims may result in more dues increases at best, and cancellation of our entire policy at worst. Pilots, Instructors and Chapters must all pay maximum attention to safety issues if hang gliding and paragliding are to continue in the United States.<br /><br />Elections for held for Director’s at Large, yours truly will serve again in 2014.<br /><br />&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;<br /><br />Please feel free to contact me with any questions or concerns you may have about the USHPA or Region 2.<br />Regards,<br /><br />Steve Rodrigues<br />steve at skypuppy dot us</div>

			<div id="sig3620" class="signature">USHPA # 30605<br />H-5, Mentor and Observer</div>

		</div>

		
			<dl class="postprofile" id="profile3620">
			<dt>
				<a href="memberliste69f.html?mode=viewprofile&amp;u=15"><img src="download/file9b05.php?avatar=15_1575056796.jpg" width="200" height="149" alt="User avatar" /></a><br />
				<a href="memberliste69f.html?mode=viewprofile&amp;u=15" style="color: #AA0000;" class="username-coloured">Steve Rodrigues</a>
			</dt>

			<dd>Site Admin</dd>

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 723</dd><dd><strong>Joined:</strong> Mon May 24, 2004 10:57 pm</dd><dd><strong>Location:</strong> Brisbane, California</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3711" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postingd2d1.php?mode=quote&amp;f=5&amp;p=3711" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3711">Re: USHPA BOD meeting</a></h3>
			<p class="author"><a href="viewtopice454-2.html?p=3711#p3711"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944">bobk</a></strong> &raquo; Wed Jan 22, 2014 2:26 am </p>

			

			<div class="content"><blockquote><div><cite>Steve Rodrigues wrote:</cite>Re: USHPA BOD meeting in Seattle, October 10-12, 2013<br />The following summary touches on a few important topics from last weekend’s BOD meeting.<br /><br />Chapter Support Committee<br />Committee discussed subject of hang glider only or paragliding only flying sites. Various committee members pointed out that there are wing-specific flying sites all across the U.S. The committee supports SOP 06-01.04 paragraph E. <br /><br />“Chapters may not, as a matter of policy, negligently or willfully discriminate against pilots of one glider type, either hang glider or paraglider, or discriminate between pilots of equal pilot rating. Chapters must ensure that recreational flight privileges are made available to any and all qualified USHPA members meeting Chapter site requirements in a fair and equitable manner without discrimination.<br /><br />Note: This requirement does not indicate that a site cannot be hang gliding only or paragliding only. Glider specific sites are permissible for safety, land owner, and possibly other conditions.<br /><br />In extraordinary circumstances, a Club may not be able to conform to the organizational requirements. The Club can submit a request for exemption from an organizational requirement to the Chapter Support Committee. Exemptions to requirements must be approved by the Chapter Support Committee and the<br />Board of Directors.&quot;</div></blockquote><br /><br />Way back when the USHGA members approved bringing paragliding into their hang gliding association, did anyone tell them that they wouldn't be able to have hang gliding clubs anymore?<br /><br />I'm a biwingual pilot myself (H4/P4), and I am certainly not against paragliding, ... but what happened to our freedom of association? Can't pilots simply choose to have hang gliding clubs or paragliding clubs because they want to belong to hang gliding clubs or paragliding clubs?<br /><br />By the way, as ridiculous as this language is ... you should have seen it before they took out the gag order that allowed USHPA to revoke site insurance and Chapters status if any club members dared to publicly criticize USHPA or their policies!!<br /><br />USHPA is a monopoly that's out of control.</div>

			<div id="sig3711" class="signature"><span style="font-size: 130%; line-height: 116%;"><span style="color: #000080"><span style="font-style: italic">Join a National Hang Gliding Organization:</span></span> <span style="font-weight: bold"><span style="color: #000080"><a href="http://ushawks.org/" class="postlink">US Hawks at ushawks.org</a></span></span></span></div>

		</div>

		
			<dl class="postprofile" id="profile3711">
			<dt>
				<a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944"><img src="download/file3928.html?avatar=1944_1390380842.jpeg" width="200" height="150" alt="User avatar" /></a><br />
				<a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944">bobk</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 138</dd><dd><strong>Joined:</strong> Tue Mar 22, 2011 1:53 pm</dd>
			<dd>
				<ul class="profile-icons">
					<li class="web-icon"><a href="http://ushawks.org/" title="WWW: http://ushawks.org"><span>Website</span></a></li>
				</ul>
			</dd>
		

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3713" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postingc721.html?mode=quote&amp;f=5&amp;p=3713" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3713">Re: USHPA BOD meeting</a></h3>
			<p class="author"><a href="viewtopic521d.html?p=3713#p3713"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberliste69f.html?mode=viewprofile&amp;u=15" style="color: #AA0000;" class="username-coloured">Steve Rodrigues</a></strong> &raquo; Wed Jan 22, 2014 10:04 am </p>

			

			<div class="content">Bob,<br /><br />Your quote: &quot; Can't pilots simply choose to have hang gliding clubs or paragliding clubs because they want to belong to hang gliding clubs or paragliding clubs?&quot;<br /><br />Of course pilots can have and join whatever clubs they want! Exactly what language leads you to believe differently?</div>

			<div id="sig3713" class="signature">USHPA # 30605<br />H-5, Mentor and Observer</div>

		</div>

		
			<dl class="postprofile" id="profile3713">
			<dt>
				<a href="memberliste69f.html?mode=viewprofile&amp;u=15"><img src="download/file9b05.php?avatar=15_1575056796.jpg" width="200" height="149" alt="User avatar" /></a><br />
				<a href="memberliste69f.html?mode=viewprofile&amp;u=15" style="color: #AA0000;" class="username-coloured">Steve Rodrigues</a>
			</dt>

			<dd>Site Admin</dd>

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 723</dd><dd><strong>Joined:</strong> Mon May 24, 2004 10:57 pm</dd><dd><strong>Location:</strong> Brisbane, California</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3715" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting30e5.php?mode=quote&amp;f=5&amp;p=3715" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3715">Re: USHPA BOD meeting</a></h3>
			<p class="author"><a href="viewtopicbd3d.html?p=3715#p3715"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944">bobk</a></strong> &raquo; Wed Jan 22, 2014 11:36 am </p>

			

			<div class="content"><blockquote><div><cite>Steve Rodrigues wrote:</cite>Bob,<br /><br />Your quote: &quot; Can't pilots simply choose to have hang gliding clubs or paragliding clubs because they want to belong to hang gliding clubs or paragliding clubs?&quot;<br /><br />Of course pilots can have and join whatever clubs they want! Exactly what language leads you to believe differently?</div></blockquote><br />This language:<br /><blockquote class="uncited"><div>“Chapters may not, as a matter of policy, negligently or willfully discriminate against pilots of one glider type, either hang glider or paraglider, or discriminate between pilots of equal pilot rating. Chapters must ensure that recreational flight privileges are made available to any and all qualified USHPA members meeting Chapter site requirements in a fair and equitable manner without discrimination.&quot;</div></blockquote><br />According to that language, we &quot;may not as a matter of policy&quot; have hang gliding clubs which are for hang gliding pilots exclusive of paragliding pilots under USHPA's Chapter system. Surely you must know that this was targeted at clubs like the Fellow Feathers and the Torrey Hawks. They haven't enforced it yet because they're taking one step at a time.<br /><br />I believe this quote is appropriate: &quot;Freedom is rarely lost in a single stroke. The danger lies in losing it bit by bit.&quot;</div>

			<div id="sig3715" class="signature"><span style="font-size: 130%; line-height: 116%;"><span style="color: #000080"><span style="font-style: italic">Join a National Hang Gliding Organization:</span></span> <span style="font-weight: bold"><span style="color: #000080"><a href="http://ushawks.org/" class="postlink">US Hawks at ushawks.org</a></span></span></span></div>

		</div>

		
			<dl class="postprofile" id="profile3715">
			<dt>
				<a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944"><img src="download/file3928.html?avatar=1944_1390380842.jpeg" width="200" height="150" alt="User avatar" /></a><br />
				<a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944">bobk</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 138</dd><dd><strong>Joined:</strong> Tue Mar 22, 2011 1:53 pm</dd>
			<dd>
				<ul class="profile-icons">
					<li class="web-icon"><a href="http://ushawks.org/" title="WWW: http://ushawks.org"><span>Website</span></a></li>
				</ul>
			</dd>
		

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3717" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting90f5.html?mode=quote&amp;f=5&amp;p=3717" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3717">Re: USHPA BOD meeting</a></h3>
			<p class="author"><a href="viewtopic9555.php?p=3717#p3717"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberliste69f.html?mode=viewprofile&amp;u=15" style="color: #AA0000;" class="username-coloured">Steve Rodrigues</a></strong> &raquo; Wed Jan 22, 2014 12:25 pm </p>

			

			<div class="content">You are ignoring this important clause:<br /><br />&quot;Note: This requirement does not indicate that a site cannot be hang gliding only or paragliding only. Glider specific sites are permissible for safety, land owner, and possibly other conditions.&quot;<br /><br />Rich has stated many times that he and the USHPA support the Fellow Feathers and their current arrangement of HG only flying at Fort Funston. He has also stepped up personally to reason with certain PG pilots, asking them not to create further problems with the GGNRA.<br /><br />I understand that you have issues, but do not demonize those who are working in our favor.</div>

			<div id="sig3717" class="signature">USHPA # 30605<br />H-5, Mentor and Observer</div>

		</div>

		
			<dl class="postprofile" id="profile3717">
			<dt>
				<a href="memberliste69f.html?mode=viewprofile&amp;u=15"><img src="download/file9b05.php?avatar=15_1575056796.jpg" width="200" height="149" alt="User avatar" /></a><br />
				<a href="memberliste69f.html?mode=viewprofile&amp;u=15" style="color: #AA0000;" class="username-coloured">Steve Rodrigues</a>
			</dt>

			<dd>Site Admin</dd>

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 723</dd><dd><strong>Joined:</strong> Mon May 24, 2004 10:57 pm</dd><dd><strong>Location:</strong> Brisbane, California</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3719" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postingbb8c.html?mode=quote&amp;f=5&amp;p=3719" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3719">Re: USHPA BOD meeting</a></h3>
			<p class="author"><a href="viewtopicf30f.php?p=3719#p3719"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944">bobk</a></strong> &raquo; Wed Jan 22, 2014 8:49 pm </p>

			

			<div class="content">Hi Steve,<br /><br />You may be missing my point. Why does USHPA need <span style="font-style: italic"><span style="text-decoration: underline">any</span></span> language telling Chapters that they must accept members who fly both wing types? And why do we now need some form of &quot;excuse&quot; just to have a hang gliding only club? Did we need to list &quot;permissable&quot; reasons to have a hang gliding club back in the days of the original USHGA?<br /><br />That SOP change should never have been written and should be removed. It was part of a larger change that included a virtual &quot;gag order&quot; on USHPA criticism ... which was fortunately removed. They took 3 steps toward tighter control of chapters and only one step back. That's a net loss of autonomy in my book. That's why I added the quote:  &quot;Freedom is rarely lost in a single stroke. The danger lies in losing it bit by bit.&quot;<br /><br />Steve, if you call that SOP change &quot;working in your favor&quot; then I'll sell you the Golden Gate Bridge for a cheap 50 grand (in cash of course). Don't listen to what Rich Hass has &quot;stated many times&quot;. That means nothing. Instead, read what he puts into writing in the SOPs. That's what really counts!!<br /><br />Fellow Feathers, USHPA is gunning for you and your club. Just read what they wrote and ask yourself what could possibly have motivated that SOP change if not the desire to force all clubs to be biwingual ... eventually.</div>

			<div id="sig3719" class="signature"><span style="font-size: 130%; line-height: 116%;"><span style="color: #000080"><span style="font-style: italic">Join a National Hang Gliding Organization:</span></span> <span style="font-weight: bold"><span style="color: #000080"><a href="http://ushawks.org/" class="postlink">US Hawks at ushawks.org</a></span></span></span></div>

		</div>

		
			<dl class="postprofile" id="profile3719">
			<dt>
				<a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944"><img src="download/file3928.html?avatar=1944_1390380842.jpeg" width="200" height="150" alt="User avatar" /></a><br />
				<a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944">bobk</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 138</dd><dd><strong>Joined:</strong> Tue Mar 22, 2011 1:53 pm</dd>
			<dd>
				<ul class="profile-icons">
					<li class="web-icon"><a href="http://ushawks.org/" title="WWW: http://ushawks.org"><span>Website</span></a></li>
				</ul>
			</dd>
		

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3720" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting9000.html?mode=quote&amp;f=5&amp;p=3720" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3720">Re: USHPA BOD meeting</a></h3>
			<p class="author"><a href="viewtopic90ae.php?p=3720#p3720"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlistc6bf.html?mode=viewprofile&amp;u=13">charlie nelson</a></strong> &raquo; Wed Jan 22, 2014 10:53 pm </p>

			

			<div class="content">The Ushpa is protecting Funston as is .  There's no hidden conspiracy .</div>

			<div id="sig3720" class="signature">email me at 'chahlieandkathy at  yahoo dotto  com'</div>

		</div>

		
			<dl class="postprofile" id="profile3720">
			<dt>
				<a href="memberlistc6bf.html?mode=viewprofile&amp;u=13"><img src="http://images.yuku.com/image/gif/b4836b1510a1318049a0a9e68005ce3b7f128ab1_t.gif" width="80" height="80" alt="User avatar" /></a><br />
				<a href="memberlistc6bf.html?mode=viewprofile&amp;u=13">charlie nelson</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 116</dd><dd><strong>Joined:</strong> Tue May 18, 2004 5:18 pm</dd><dd><strong>Location:</strong> redwood city</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3721" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postingaaad.html?mode=quote&amp;f=5&amp;p=3721" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3721">Re: USHPA BOD meeting</a></h3>
			<p class="author"><a href="viewtopice582.html?p=3721#p3721"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944">bobk</a></strong> &raquo; Thu Jan 23, 2014 10:47 am </p>

			

			<div class="content">Let me ask again, why do you think this language was added to the USHPA SOP?<br /><br /><blockquote class="uncited"><div>“Chapters may not, as a matter of policy, negligently or willfully discriminate against pilots of one glider type, either hang glider or paraglider, or discriminate between pilots of equal pilot rating.&quot;</div></blockquote><br /><br />Those who are familiar with the USHPA Board will know that changes like these don't just &quot;happen&quot;. Some Director (or group of Directors) had to come up with this idea, write it down, submit it to a committee, get it passed by that committee, bring it to the entire USHPA Board, and get it passed by the entire USHPA Board.<br /><br />Why do you think they went to all that trouble? What were they trying to accomplish with this language? Did they do this to &quot;protect&quot; Funston ... or to make it biwingual?</div>

			<div id="sig3721" class="signature"><span style="font-size: 130%; line-height: 116%;"><span style="color: #000080"><span style="font-style: italic">Join a National Hang Gliding Organization:</span></span> <span style="font-weight: bold"><span style="color: #000080"><a href="http://ushawks.org/" class="postlink">US Hawks at ushawks.org</a></span></span></span></div>

		</div>

		
			<dl class="postprofile" id="profile3721">
			<dt>
				<a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944"><img src="download/file3928.html?avatar=1944_1390380842.jpeg" width="200" height="150" alt="User avatar" /></a><br />
				<a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944">bobk</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 138</dd><dd><strong>Joined:</strong> Tue Mar 22, 2011 1:53 pm</dd>
			<dd>
				<ul class="profile-icons">
					<li class="web-icon"><a href="http://ushawks.org/" title="WWW: http://ushawks.org"><span>Website</span></a></li>
				</ul>
			</dd>
		

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3722" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting197c.html?mode=quote&amp;f=5&amp;p=3722" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3722">Re: USHPA BOD meeting</a></h3>
			<p class="author"><a href="viewtopic27cd.html?p=3722#p3722"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberliste69f.html?mode=viewprofile&amp;u=15" style="color: #AA0000;" class="username-coloured">Steve Rodrigues</a></strong> &raquo; Thu Jan 23, 2014 12:38 pm </p>

			

			<div class="content">Bob,<br /><br />Certainly you have seen this boilerplate type of anti-discrimination wording everywhere else in the world, don't pretend that the USHPA made it up.<br /><br />They did however craft this wording, specifically to protect sites like Fort Funston: &quot;Note: This requirement does not indicate that a site cannot be hang gliding only or paragliding only. Glider specific sites are permissible for safety, land owner, and possibly other conditions.&quot;<br /><br />Care to explain why you don't acknowledge that this protects HG only sites?</div>

			<div id="sig3722" class="signature">USHPA # 30605<br />H-5, Mentor and Observer</div>

		</div>

		
			<dl class="postprofile" id="profile3722">
			<dt>
				<a href="memberliste69f.html?mode=viewprofile&amp;u=15"><img src="download/file9b05.php?avatar=15_1575056796.jpg" width="200" height="149" alt="User avatar" /></a><br />
				<a href="memberliste69f.html?mode=viewprofile&amp;u=15" style="color: #AA0000;" class="username-coloured">Steve Rodrigues</a>
			</dt>

			<dd>Site Admin</dd>

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 723</dd><dd><strong>Joined:</strong> Mon May 24, 2004 10:57 pm</dd><dd><strong>Location:</strong> Brisbane, California</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3725" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postingdea6.html?mode=quote&amp;f=5&amp;p=3725" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3725">Re: USHPA BOD meeting</a></h3>
			<p class="author"><a href="viewtopiccf98.html?p=3725#p3725"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944">bobk</a></strong> &raquo; Fri Jan 24, 2014 2:35 am </p>

			

			<div class="content"><blockquote><div><cite>Steve Rodrigues wrote:</cite>Certainly you have seen this boilerplate type of anti-discrimination wording everywhere else in the world, don't pretend that the USHPA made it up.</div></blockquote><br /><br />Hi Steve,<br /><br />Anti-Discrimination clauses cover things like race, gender, religion, sexual orientation, and all kinds of things that are considered beyond a person's control.<br /><br />You can't use an &quot;Anti-Discrimination&quot; clause to tell a ping pong club that they have to be a bowling club. That's a ridiculous statement, and I'm surprised you'd even make it on a public forum. Really, please think about what you're saying.<br /><br /><blockquote><div><cite>Steve Rodrigues wrote:</cite>They did however craft this wording, specifically to protect sites like Fort Funston: &quot;Note: This requirement does not indicate that a site cannot be hang gliding only or paragliding only. Glider specific sites are permissible for safety, land owner, and possibly other conditions.&quot;<br /><br />Care to explain why you don't acknowledge that this protects HG only sites?</div></blockquote><br /><br />Steve, the prior USHPA SOP (which was in place for many years) said NOTHING about requiring USHPA Chapters to be biwingual ... NOTHING. Any club and any site could make up whatever rules it wanted. So now USHPA comes along and states that clubs can't &quot;discriminate&quot; against wing type (which they were free to do before) and you think that's fine because they say that they &quot;may&quot; make allowances in certain cases? Now the burden is on your club to constantly prove that your glider-specific site is needed for &quot;safety, land owner, and possibly other conditions&quot;. As soon as you fail to prove that, your club is in violation of that SOP. That wasn't the case before this SOP was passed. Don't you get that? Has your USHPA loyalty blinded you to the English language?<br /><br />This reminds me of the recent change in Forest Service policy. In the past, our forest lands were open to all uses UNLESS they were posted otherwise. Then the Forest Service came up with a new policy that all forest land was off limits UNLESS specifically posted otherwise. Do you see the difference? That's exactly what USHPA has done. In the past, there was NO RESTRICTION on hang gliding only or paragliding only clubs. Now they've specifically forbidden them, but they &quot;may&quot; make an exception in certain cases ... at THEIR discretion. You're OK with that? Really?</div>

			<div id="sig3725" class="signature"><span style="font-size: 130%; line-height: 116%;"><span style="color: #000080"><span style="font-style: italic">Join a National Hang Gliding Organization:</span></span> <span style="font-weight: bold"><span style="color: #000080"><a href="http://ushawks.org/" class="postlink">US Hawks at ushawks.org</a></span></span></span></div>

		</div>

		
			<dl class="postprofile" id="profile3725">
			<dt>
				<a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944"><img src="download/file3928.html?avatar=1944_1390380842.jpeg" width="200" height="150" alt="User avatar" /></a><br />
				<a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944">bobk</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 138</dd><dd><strong>Joined:</strong> Tue Mar 22, 2011 1:53 pm</dd>
			<dd>
				<ul class="profile-icons">
					<li class="web-icon"><a href="http://ushawks.org/" title="WWW: http://ushawks.org"><span>Website</span></a></li>
				</ul>
			</dd>
		

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3727" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postingc843.html?mode=quote&amp;f=5&amp;p=3727" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3727">Re: USHPA BOD meeting</a></h3>
			<p class="author"><a href="viewtopic104b.php?p=3727#p3727"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a></strong> &raquo; Sat Jan 25, 2014 1:16 am </p>

			

			<div class="content"><blockquote class="uncited"><div>He has also stepped up personally to reason with certain PG pilots, asking them not to create further problems with the GGNRA.</div></blockquote><br /><br />That's interesting Steve.  Can you be more specific?  What sort of problems have certain PG pilots created with the GGNRA - and what has Rich asked them to do differently?</div>

			

		</div>

		
			<dl class="postprofile" id="profile3727">
			<dt>
				<a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 93</dd><dd><strong>Joined:</strong> Wed Apr 20, 2011 11:40 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3728" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postingc9f5-2.html?mode=quote&amp;f=5&amp;p=3728" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3728">Re: USHPA BOD meeting</a></h3>
			<p class="author"><a href="viewtopiccab6.html?p=3728#p3728"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberliste69f.html?mode=viewprofile&amp;u=15" style="color: #AA0000;" class="username-coloured">Steve Rodrigues</a></strong> &raquo; Sat Jan 25, 2014 8:00 am </p>

			

			<div class="content">Sorry but I will not post details of another persons private conversations on a public discussion board so really can't be more specific. All I can say is that Rich spoke with pilots who were taking action that was detrimental to the Fellow Feathers and he was able to reason with them and convince them to back off.<br /><br />Rich's actions were very helpful in diffusing some of our issues with the GGNRA, which BTW, had reached dangerous critical mass by the end of last year. There is a lot that goes on behind the scenes, not all of it is bad!</div>

			<div id="sig3728" class="signature">USHPA # 30605<br />H-5, Mentor and Observer</div>

		</div>

		
			<dl class="postprofile" id="profile3728">
			<dt>
				<a href="memberliste69f.html?mode=viewprofile&amp;u=15"><img src="download/file9b05.php?avatar=15_1575056796.jpg" width="200" height="149" alt="User avatar" /></a><br />
				<a href="memberliste69f.html?mode=viewprofile&amp;u=15" style="color: #AA0000;" class="username-coloured">Steve Rodrigues</a>
			</dt>

			<dd>Site Admin</dd>

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 723</dd><dd><strong>Joined:</strong> Mon May 24, 2004 10:57 pm</dd><dd><strong>Location:</strong> Brisbane, California</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3729" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting358a.html?mode=quote&amp;f=5&amp;p=3729" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3729">Re: USHPA BOD meeting</a></h3>
			<p class="author"><a href="viewtopicf81a.php?p=3729#p3729"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a></strong> &raquo; Sat Jan 25, 2014 9:29 am </p>

			

			<div class="content"><blockquote class="uncited"><div>Sorry but I will not post details of another persons private conversations on a public discussion board so really can't be more specific</div></blockquote><br /><br />The reason I ask is that I've been told more than once by Fellow Feather members that *I* have taken actions with the GGNRA - when the fact is that I *NEVER* have.  I have not had Rich tell me to &quot;back off&quot;.  And I have never done anything detrimental to the Fort.  If you're referring to someone else - fine.</div>

			

		</div>

		
			<dl class="postprofile" id="profile3729">
			<dt>
				<a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 93</dd><dd><strong>Joined:</strong> Wed Apr 20, 2011 11:40 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3730" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postingf79d.html?mode=quote&amp;f=5&amp;p=3730" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3730">Re: USHPA BOD meeting</a></h3>
			<p class="author"><a href="viewtopicd800.php?p=3730#p3730"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberliste69f.html?mode=viewprofile&amp;u=15" style="color: #AA0000;" class="username-coloured">Steve Rodrigues</a></strong> &raquo; Sat Jan 25, 2014 12:27 pm </p>

			

			<div class="content">You can relax, this time it wasn't you!  &gt;;-)</div>

			<div id="sig3730" class="signature">USHPA # 30605<br />H-5, Mentor and Observer</div>

		</div>

		
			<dl class="postprofile" id="profile3730">
			<dt>
				<a href="memberliste69f.html?mode=viewprofile&amp;u=15"><img src="download/file9b05.php?avatar=15_1575056796.jpg" width="200" height="149" alt="User avatar" /></a><br />
				<a href="memberliste69f.html?mode=viewprofile&amp;u=15" style="color: #AA0000;" class="username-coloured">Steve Rodrigues</a>
			</dt>

			<dd>Site Admin</dd>

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 723</dd><dd><strong>Joined:</strong> Mon May 24, 2004 10:57 pm</dd><dd><strong>Location:</strong> Brisbane, California</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3731" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting80c0.html?mode=quote&amp;f=5&amp;p=3731" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3731">Re: USHPA BOD meeting</a></h3>
			<p class="author"><a href="viewtopic978c.html?p=3731#p3731"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a></strong> &raquo; Sat Jan 25, 2014 1:00 pm </p>

			

			<div class="content"><blockquote><div><cite>Steve Rodrigues wrote:</cite>You can relax, this time it wasn't you!  &gt;;-)</div></blockquote><br /><br />More importantly - it *never* was me.  I have only ever been on the receiving end of abuse at Funston.</div>

			

		</div>

		
			<dl class="postprofile" id="profile3731">
			<dt>
				<a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 93</dd><dd><strong>Joined:</strong> Wed Apr 20, 2011 11:40 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3732" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting3f6b.html?mode=quote&amp;f=5&amp;p=3732" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3732">Re: USHPA BOD meeting</a></h3>
			<p class="author"><a href="viewtopicbf88.php?p=3732#p3732"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberliste69f.html?mode=viewprofile&amp;u=15" style="color: #AA0000;" class="username-coloured">Steve Rodrigues</a></strong> &raquo; Sat Jan 25, 2014 1:50 pm </p>

			

			<div class="content">Believe me, I know the feeling.</div>

			<div id="sig3732" class="signature">USHPA # 30605<br />H-5, Mentor and Observer</div>

		</div>

		
			<dl class="postprofile" id="profile3732">
			<dt>
				<a href="memberliste69f.html?mode=viewprofile&amp;u=15"><img src="download/file9b05.php?avatar=15_1575056796.jpg" width="200" height="149" alt="User avatar" /></a><br />
				<a href="memberliste69f.html?mode=viewprofile&amp;u=15" style="color: #AA0000;" class="username-coloured">Steve Rodrigues</a>
			</dt>

			<dd>Site Admin</dd>

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 723</dd><dd><strong>Joined:</strong> Mon May 24, 2004 10:57 pm</dd><dd><strong>Location:</strong> Brisbane, California</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3740" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postingcbce.html?mode=quote&amp;f=5&amp;p=3740" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3740">Re: USHPA BOD meeting</a></h3>
			<p class="author"><a href="viewtopicc90c.html?p=3740#p3740"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944">bobk</a></strong> &raquo; Tue Jan 28, 2014 12:11 am </p>

			

			<div class="content">Steve,<br /><br />I hope Rich Hass is paying you well for your PR work on his behalf.<br /><br />You still haven't answered the question. Throughout USHPA's history, there had been no requirement on chapters to be biwingual. That requirement was added recently. How does the addition of that langauge protect the Fellow Feathers in any way as you're claiming?<br /><br />I will add that even if the Fellow Feathers gets an official &quot;exemption&quot; from the Chapter Support Committee (as required by the new SOP) and even if that exemption is approved by the entire USHPA Board (as required by the new SOP), what's to stop the Chapter Support Committee or the Board from reversing their decision? In other words, this SOP that you're defending puts HG-only and PG-only clubs in the precarious position of being &quot;exceptions&quot; that depend on a special &quot;exemption&quot; that could be easily reversed or simply not renewed at some future date. This is another step toward turning Funston into Torrey. I don't know why you're not willing to see that.<br /><br />A key point here is that while the SOP recognizes that there can be reasons for *SITES* of one wing type or another, it still requires *CLUBS* to be biwingual. That means that all the PG pilots in your area can sign up to be voting Fellow Feathers members and literally take over your club. THEN they can change the site rules ... not as isolated PG pilots ... but as the newly elected BOARD OF THE FELLOW FEATHERS!! That's the possibility that these new rules have created, and they should be reversed before that can happen.<br /><br />Steve, will you introduce a motion that removes the biwingual club requirements from the SOPs?</div>

			<div id="sig3740" class="signature"><span style="font-size: 130%; line-height: 116%;"><span style="color: #000080"><span style="font-style: italic">Join a National Hang Gliding Organization:</span></span> <span style="font-weight: bold"><span style="color: #000080"><a href="http://ushawks.org/" class="postlink">US Hawks at ushawks.org</a></span></span></span></div>

		</div>

		
			<dl class="postprofile" id="profile3740">
			<dt>
				<a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944"><img src="download/file3928.html?avatar=1944_1390380842.jpeg" width="200" height="150" alt="User avatar" /></a><br />
				<a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944">bobk</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 138</dd><dd><strong>Joined:</strong> Tue Mar 22, 2011 1:53 pm</dd>
			<dd>
				<ul class="profile-icons">
					<li class="web-icon"><a href="http://ushawks.org/" title="WWW: http://ushawks.org"><span>Website</span></a></li>
				</ul>
			</dd>
		

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3741" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting0725.php?mode=quote&amp;f=5&amp;p=3741" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3741">Re: USHPA BOD meeting</a></h3>
			<p class="author"><a href="viewtopic0b87.html?p=3741#p3741"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberliste69f.html?mode=viewprofile&amp;u=15" style="color: #AA0000;" class="username-coloured">Steve Rodrigues</a></strong> &raquo; Tue Jan 28, 2014 5:43 am </p>

			

			<div class="content">Bob,<br /><br />The FF doesn't need to do a damn thing to remain HG only, the club is fine. You are making a problem out of nothing and even though I've pointed this out you just keep on arguing from your own position without regard to anything I've said.  I don't see the point in debating with you any more, I'm done here.</div>

			<div id="sig3741" class="signature">USHPA # 30605<br />H-5, Mentor and Observer</div>

		</div>

		
			<dl class="postprofile" id="profile3741">
			<dt>
				<a href="memberliste69f.html?mode=viewprofile&amp;u=15"><img src="download/file9b05.php?avatar=15_1575056796.jpg" width="200" height="149" alt="User avatar" /></a><br />
				<a href="memberliste69f.html?mode=viewprofile&amp;u=15" style="color: #AA0000;" class="username-coloured">Steve Rodrigues</a>
			</dt>

			<dd>Site Admin</dd>

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 723</dd><dd><strong>Joined:</strong> Mon May 24, 2004 10:57 pm</dd><dd><strong>Location:</strong> Brisbane, California</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3743" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting730a.html?mode=quote&amp;f=5&amp;p=3743" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3743">Re: USHPA BOD meeting</a></h3>
			<p class="author"><a href="viewtopic026c.html?p=3743#p3743"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944">bobk</a></strong> &raquo; Tue Jan 28, 2014 10:59 am </p>

			

			<div class="content">Hi Steve,<br /><br />Here's what you quoted from the USHPA SOPs:<br /><br /><blockquote class="uncited"><div>“Chapters may not, as a matter of policy, negligently or willfully discriminate against pilots of one glider type, either hang glider or paraglider, or discriminate between pilots of equal pilot rating. Chapters must ensure that recreational flight privileges are made available to any and all qualified USHPA members meeting Chapter site requirements in a fair and equitable manner without discrimination.<br /><br />Note: This requirement does not indicate that a site cannot be hang gliding only or paragliding only. Glider specific sites are permissible for safety, land owner, and possibly other conditions.<br /><br />In extraordinary circumstances, a Club may not be able to conform to the organizational requirements. The Club can submit a request for exemption from an organizational requirement to the Chapter Support Committee. Exemptions to requirements must be approved by the Chapter Support Committee and the Board of Directors.&quot;</div></blockquote><br /><br />Here's what I would suggest as a replacement for that whole section:<br /><br /><blockquote class="uncited"><div>Chapters are self-governed and shall be able to make their own rules regarding membership and site use.</div></blockquote><br /><br />Which one do you think protects the Fellow Feathers better?<br /><br /><blockquote><div><cite>Steve Rodrigues wrote:</cite>The FF doesn't need to do a damn thing to remain HG only, the club is fine. You are making a problem out of nothing ...</div></blockquote><br /><br />Steve, the problem is not out of nothing. It's out of an SOP that was created for a purpose. If it was &quot;out of nothing&quot; then USHPA wouldn't have introduced those SOP changes. They did it for a reason. It's surprising that you refuse to simply ask USHPA to reverse those changes. Why won't you do that? Oh, that's right, you're not talking to me any more.  <img src="images/smilies/icon_lol.gif" alt=":lol:" title="Laughing" /></div>

			<div id="sig3743" class="signature"><span style="font-size: 130%; line-height: 116%;"><span style="color: #000080"><span style="font-style: italic">Join a National Hang Gliding Organization:</span></span> <span style="font-weight: bold"><span style="color: #000080"><a href="http://ushawks.org/" class="postlink">US Hawks at ushawks.org</a></span></span></span></div>

		</div>

		
			<dl class="postprofile" id="profile3743">
			<dt>
				<a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944"><img src="download/file3928.html?avatar=1944_1390380842.jpeg" width="200" height="150" alt="User avatar" /></a><br />
				<a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944">bobk</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 138</dd><dd><strong>Joined:</strong> Tue Mar 22, 2011 1:53 pm</dd>
			<dd>
				<ul class="profile-icons">
					<li class="web-icon"><a href="http://ushawks.org/" title="WWW: http://ushawks.org"><span>Website</span></a></li>
				</ul>
			</dd>
		

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3744" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postinge9af.html?mode=quote&amp;f=5&amp;p=3744" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3744">Re: USHPA BOD meeting</a></h3>
			<p class="author"><a href="viewtopic86cb.php?p=3744#p3744"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a></strong> &raquo; Tue Jan 28, 2014 12:12 pm </p>

			

			<div class="content"><blockquote><div><cite>bobk wrote:</cite>Here's what I would suggest as a replacement for that whole section:<br /><br /><blockquote class="uncited"><div>Chapters are self-governed and shall be able to make their own rules regarding membership and site use.</div></blockquote></div></blockquote><br /><br />I can't imagine they'd go for anything that broad.  If you're an USHPA site you're under USHPA insurance.  They're not going to say &quot;do whatever you like&quot; and still insure you.<br /><br />Besides, the only thing HG only about Funston is launching and landing.  Are you going to lobby USHPA to overrule the FAA</div>

			

		</div>

		
			<dl class="postprofile" id="profile3744">
			<dt>
				<a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 93</dd><dd><strong>Joined:</strong> Wed Apr 20, 2011 11:40 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3746" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting405e.html?mode=quote&amp;f=5&amp;p=3746" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3746">Re: USHPA BOD meeting</a></h3>
			<p class="author"><a href="viewtopic33f1.php?p=3746#p3746"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944">bobk</a></strong> &raquo; Wed Jan 29, 2014 11:54 am </p>

			

			<div class="content"><blockquote><div><cite>spork wrote:</cite>I can't imagine they'd go for anything that broad.  If you're an USHPA site you're under USHPA insurance.  They're not going to say &quot;do whatever you like&quot; and still insure you.<br /><br />Besides, the only thing HG only about Funston is launching and landing.  Are you going to lobby USHPA to overrule the FAA</div></blockquote><br />Hmmm...<br /><br />It appears that <span style="font-weight: bold">spork</span> (well known for trying to increase PG access to Funston) seems to like this new SOP. Does anyone need any more proof than that?<br /><br />I'm going to go out on a limb here. I predict that if the Fellow Feathers doesn't push back on this new USHPA SOP, USHPA will end up denying their Chapter status / site insurance within 5 years if they don't allow PGs to launch and land at Funston.</div>

			<div id="sig3746" class="signature"><span style="font-size: 130%; line-height: 116%;"><span style="color: #000080"><span style="font-style: italic">Join a National Hang Gliding Organization:</span></span> <span style="font-weight: bold"><span style="color: #000080"><a href="http://ushawks.org/" class="postlink">US Hawks at ushawks.org</a></span></span></span></div>

		</div>

		
			<dl class="postprofile" id="profile3746">
			<dt>
				<a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944"><img src="download/file3928.html?avatar=1944_1390380842.jpeg" width="200" height="150" alt="User avatar" /></a><br />
				<a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944">bobk</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 138</dd><dd><strong>Joined:</strong> Tue Mar 22, 2011 1:53 pm</dd>
			<dd>
				<ul class="profile-icons">
					<li class="web-icon"><a href="http://ushawks.org/" title="WWW: http://ushawks.org"><span>Website</span></a></li>
				</ul>
			</dd>
		

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3747" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postingadb3.html?mode=quote&amp;f=5&amp;p=3747" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3747">Re: USHPA BOD meeting</a></h3>
			<p class="author"><a href="viewtopic4817.php?p=3747#p3747"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a></strong> &raquo; Wed Jan 29, 2014 12:12 pm </p>

			

			<div class="content"><blockquote><div><cite>bobk wrote:</cite>It appears that <span style="font-weight: bold">spork</span> (well known for trying to increase PG access to Funston) seems to like this new SOP. Does anyone need any more proof than that?</div></blockquote><br /><br />I don't give a shit about the new SOP.  I made a proposal to have very limited access for biwingual pilots to launch and land at the Fort.  It was shouted down.  As far as I'm concerned that was the end of it.  No SOP the USHPA has - or can have - will govern airspace.  I will fly where I like - as will you and everyone else.  <br /><br />At least get your facts straight Bob.</div>

			

		</div>

		
			<dl class="postprofile" id="profile3747">
			<dt>
				<a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 93</dd><dd><strong>Joined:</strong> Wed Apr 20, 2011 11:40 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3749" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting63c9.html?mode=quote&amp;f=5&amp;p=3749" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3749">Re: USHPA BOD meeting</a></h3>
			<p class="author"><a href="viewtopicf699.html?p=3749#p3749"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944">bobk</a></strong> &raquo; Wed Jan 29, 2014 12:32 pm </p>

			

			<div class="content"><blockquote><div><cite>spork wrote:</cite>I don't give a shit about the new SOP. ... At least get your facts straight Bob.</div></blockquote><br /><br />This discussion is about the USHPA Board Meeting and the new Chapter Support Committee SOP as it relates to Funston. That new SOP basically states that CLUBS must treat HG and PG equally. That would logically include the ability for PG pilots to be members of the Fellow Feathers and to vote on all club issues.<br /><br />The question I've raised is whether USHPA should have added that SOP or not?<br /><br />If you say you don't care, then I'm sorry, but I won't believe you.</div>

			<div id="sig3749" class="signature"><span style="font-size: 130%; line-height: 116%;"><span style="color: #000080"><span style="font-style: italic">Join a National Hang Gliding Organization:</span></span> <span style="font-weight: bold"><span style="color: #000080"><a href="http://ushawks.org/" class="postlink">US Hawks at ushawks.org</a></span></span></span></div>

		</div>

		
			<dl class="postprofile" id="profile3749">
			<dt>
				<a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944"><img src="download/file3928.html?avatar=1944_1390380842.jpeg" width="200" height="150" alt="User avatar" /></a><br />
				<a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944">bobk</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 138</dd><dd><strong>Joined:</strong> Tue Mar 22, 2011 1:53 pm</dd>
			<dd>
				<ul class="profile-icons">
					<li class="web-icon"><a href="http://ushawks.org/" title="WWW: http://ushawks.org"><span>Website</span></a></li>
				</ul>
			</dd>
		

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3750" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting321b.html?mode=quote&amp;f=5&amp;p=3750" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3750">Re: USHPA BOD meeting</a></h3>
			<p class="author"><a href="viewtopic61a9.html?p=3750#p3750"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a></strong> &raquo; Wed Jan 29, 2014 12:50 pm </p>

			

			<div class="content"><blockquote><div><cite>bobk wrote:</cite>If you say you don't care, then I'm sorry, but I won't believe you.</div></blockquote><br /><br />Fortunately I don't give a shit what you believe.  And it's not the only thing you got wrong.  You seem to think that I have continued to push for PG access to launch and land at the Fort.  Check the record.  It simply isn't true.  But don't let facts get in the way of a good rant.</div>

			

		</div>

		
			<dl class="postprofile" id="profile3750">
			<dt>
				<a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 93</dd><dd><strong>Joined:</strong> Wed Apr 20, 2011 11:40 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3751" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting0d3b.html?mode=quote&amp;f=5&amp;p=3751" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3751">Re: USHPA BOD meeting</a></h3>
			<p class="author"><a href="viewtopic176d.html?p=3751#p3751"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944">bobk</a></strong> &raquo; Wed Jan 29, 2014 12:58 pm </p>

			

			<div class="content">Let me repeat:<br /><br />The question I've raised is whether USHPA should have added that SOP or not?<br /><br />I say they should NOT have added it, and I assert that it was added to hurt hang gliding clubs like Fellow Feathers and Torrey Hawks.<br /><br />I also assert that this is showing where USHPA is headed, and I predict that USHPA will continue to make changes like this so they can eventually force the Fellow Feathers to allow PG launching and landing at Funston.<br /><br />If you disagree with any of these assertions, please be specific. Thanks.</div>

			<div id="sig3751" class="signature"><span style="font-size: 130%; line-height: 116%;"><span style="color: #000080"><span style="font-style: italic">Join a National Hang Gliding Organization:</span></span> <span style="font-weight: bold"><span style="color: #000080"><a href="http://ushawks.org/" class="postlink">US Hawks at ushawks.org</a></span></span></span></div>

		</div>

		
			<dl class="postprofile" id="profile3751">
			<dt>
				<a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944"><img src="download/file3928.html?avatar=1944_1390380842.jpeg" width="200" height="150" alt="User avatar" /></a><br />
				<a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944">bobk</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 138</dd><dd><strong>Joined:</strong> Tue Mar 22, 2011 1:53 pm</dd>
			<dd>
				<ul class="profile-icons">
					<li class="web-icon"><a href="http://ushawks.org/" title="WWW: http://ushawks.org"><span>Website</span></a></li>
				</ul>
			</dd>
		

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<form id="viewtopic" method="post" action="http://flyfunston.org/bbs/viewtopic.php?f=5&amp;t=1475">

	<fieldset class="display-options" style="margin-top: 0; ">
		<a href="viewtopic4927.php?f=5&amp;t=1475&amp;start=25" class="right-box right">Next</a>
		<label>Display posts from previous: <select name="st" id="st"><option value="0" selected="selected">All posts</option><option value="1">1 day</option><option value="7">7 days</option><option value="14">2 weeks</option><option value="30">1 month</option><option value="90">3 months</option><option value="180">6 months</option><option value="365">1 year</option></select></label>
		<label>Sort by <select name="sk" id="sk"><option value="a">Author</option><option value="t" selected="selected">Post time</option><option value="s">Subject</option></select></label> <label><select name="sd" id="sd"><option value="a" selected="selected">Ascending</option><option value="d">Descending</option></select> <input type="submit" name="sort" value="Go" class="button2" /></label>
		
	</fieldset>

	</form>
	<hr />


<div class="topic-actions">
	<div class="buttons">
	
		<div class="reply-icon"><a href="posting92c2.php?mode=reply&amp;f=5&amp;t=1475" title="Post a reply"><span></span>Post a reply</a></div>
	
	</div>

	
		<div class="pagination">
			42 posts
			 &bull; <a href="#" onclick="jumpto(); return false;" title="Click to jump to page…">Page <strong>1</strong> of <strong>2</strong></a> &bull; <span><strong>1</strong><span class="page-sep">, </span><a href="viewtopic4927.php?f=5&amp;t=1475&amp;start=25">2</a></span>
		</div>
	
</div>


	<p></p><p><a href="viewforume774.html?f=5" class="left-box left" accesskey="r">Return to General Discussion</a></p>

	<form method="post" id="jumpbox" action="http://flyfunston.org/bbs/viewforum.php" onsubmit="if(this.f.value == -1){return false;}">

	
		<fieldset class="jumpbox">
	
			<label for="f" accesskey="j">Jump to:</label>
			<select name="f" id="f" onchange="if(this.options[this.selectedIndex].value != -1){ document.forms['jumpbox'].submit() }">
			
				<option value="-1">Select a forum</option>
			<option value="-1">------------------</option>
				<option value="9">Discussion Groups</option>
			
				<option value="5" selected="selected">&nbsp; &nbsp;General Discussion</option>
			
				<option value="8">&nbsp; &nbsp;Announcements</option>
			
				<option value="7">&nbsp; &nbsp;For Sale/Wanted</option>
			
				<option value="6">&nbsp; &nbsp;Road Trips</option>
			
				<option value="2">&nbsp; &nbsp;Meeting Minutes and Treasurer Reports</option>
			
				<option value="11">&nbsp; &nbsp;Off Topic</option>
			
			</select>
			<input type="submit" value="Go" class="button2" />
		</fieldset>
	</form>


	<h3>Who is online</h3>
	<p>Users browsing this forum: No registered users and 7 guests</p>
</div>

<div id="page-footer">

	<div class="navbar">
		<div class="inner"><span class="corners-top"><span></span></span>

		<ul class="linklist">
			<li class="icon-home"><a href="index.html">Board index</a></li>
				
			<li class="rightside"><a href="memberlista2f5.html?mode=leaders">The team</a> &bull; <a href="ucp033a.html?mode=delete_cookies">Delete all board cookies</a> &bull; All times are UTC - 8 hours [ <abbr title="Daylight Saving Time">DST</abbr> ]</li>
		</ul>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<div class="copyright">Powered by <a href="https://www.phpbb.com/">phpBB</a>&reg; Forum Software &copy; phpBB Group
		
	</div>
</div>

</div>

<div>
	<a id="bottom" name="bottom" accesskey="z"></a>
	
</div>

</body>

<!-- Mirrored from flyfunston.org/bbs/viewtopic.php?p=3729 by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 08 Aug 2021 20:05:02 GMT -->
</html>