<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en-us" xml:lang="en-us">

<!-- Mirrored from flyfunston.org/bbs/viewtopic.php?f=2&t=1791&view=print by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 08 Aug 2021 18:03:57 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>

<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<meta http-equiv="content-style-type" content="text/css" />
<meta http-equiv="content-language" content="en-us" />
<meta http-equiv="imagetoolbar" content="no" />
<meta name="resource-type" content="document" />
<meta name="distribution" content="global" />
<meta name="robots" content="noindex" />

<title>Flyfunston &bull; View topic - January 4th 2017 Fellow Feather’s Meeting Minutes</title>

<link href="styles/prosilver/theme/print.css" rel="stylesheet" type="text/css" />
</head>

<body id="phpbb">
<div id="wrap">
	<a id="top" name="top" accesskey="t"></a>

	<div id="page-header">
		<h1>Flyfunston</h1>
		<p>Hang Gliding at Fort Funston<br /><a href="index-2.html">http://flyfunston.org/bbs/</a></p>

		<h2>January 4th 2017 Fellow Feather’s Meeting Minutes</h2>
		<p><a href="viewtopic63c4.php?f=2&amp;t=1791">http://flyfunston.org/bbs/viewtopic.php?f=2&amp;t=1791</a></p>
	</div>

	<div id="page-body">
		<div class="page-number">Page <strong>1</strong> of <strong>1</strong></div>
		
			<div class="post">
				<h3>January 4th 2017 Fellow Feather’s Meeting Minutes</h3>
				<div class="date"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" />Posted: <strong>Wed Jan 04, 2017 10:31 pm</strong></div>
				<div class="author">by <strong>crvalley</strong></div>
				<div class="content">January 4th 2017 Fellow Feather’s Meeting Minutes<br /><br />In Attendance:  Rob Johnson, Lisa Lesser, Chris Valley, Joey Villaflor, Chuck Krantz, Mitch Shipley, Wayne Michelsen, John Simpson, Walter Whiteside, Ian Riedel<br /><br />Guests / New Members:   Ian Riedel - getting back into the sport after 10 years off - former Sonoma Winger - used to fly Goat and Hull.<br /><br />Great Flights:  Some had some fun in strong SW winds at the Fort, flying to Westlake or not making it to Westlake…Gerry Pesavento and Wayne Michelsen flew Tam on January 2nd tagging Tomales Bay &amp; Bolinas - got up to 3200’ - super smooth air for about 1.5 hours.  Wayne, JT, and CRV had some fun at Windy Hill on New Year’s Day - cloud base was around 3k.  Marina also delivered some great conditions over the holidays.<br /><br />President’s Report (Joey Villaflor):  Working on some graphics for a new Funston t-shirt - working on an introduction video to help new and visiting pilots.  In the meantime, pilots should read Kent Harker’s Funston Primer which is available on the Club’s website.<br /><br />Vice President’s Report (Wayne Michelsen):  Nothing to report.<br /><br />Secretary’s Report (Chris Valley):  December meeting minutes posted.<br /><br />Treasurer’s Report (Lisa Lesser):  Nothing to report. <br /><br />Clubhouse Officer’s Report (Rob Johnson):  Reminder - Clubhouse members will not receive stickers until they have paid their Clubhouse dues this year and beyond.  Would like to redo the racks in the Clubhouse and repaint.<br /><br />Safety Officer’s / Launch Maintenance Report (John Simpson):  Need to keep up with launch maintenance.  1/2 day launch maintenance work party is being considered.  See old business item.<br /><br />Tech Officer’s Report (Chuck Kranz):  Used our last backup computer.  Ropes Building cam needs to be reset.  Will upgrade to Club’s bulletin board.<br /><br />Administrator Reports:<br /><br />	~ Tandem (Urs Kellenberger):  Not present.<br />	~ Training Bowl (Mark Lilledahl):  Not present.<br /><br />GGNRA Liaison Report (Steve Rodrigues):  Not present.<br /><br />Old Business:  Followup to prior discussion of Funston-specific requirements for new pilots flying the Fort and what we can all do to improve safety.  Pilots need strong windy cliff launch skills and Funston-specific landing skills.  <br /><br />New Business:  The Club will add to the list of mentors and make the Site Guide a one-click find on our web site.  The Club meetings have been changed to the first Thursday of each month throughout the rest of the year.<br /><br />Meeting adjourned at 8:48 PM.</div>
			</div>
			<hr />
		
	</div>

	<div id="page-footer">
		<div class="page-number">All times are UTC - 8 hours [ <abbr title="Daylight Saving Time">DST</abbr> ]<br />Page <strong>1</strong> of <strong>1</strong></div>
		<div class="copyright">Powered by phpBB&reg; Forum Software &copy; phpBB Group<br />https://www.phpbb.com/</div>
	</div>
</div>

</body>

<!-- Mirrored from flyfunston.org/bbs/viewtopic.php?f=2&t=1791&view=print by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 08 Aug 2021 18:03:57 GMT -->
</html>