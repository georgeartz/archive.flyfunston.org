<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en-us" xml:lang="en-us">

<!-- Mirrored from flyfunston.org/bbs/viewtopic.php?p=3762 by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 08 Aug 2021 20:05:08 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>

<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<meta http-equiv="content-style-type" content="text/css" />
<meta http-equiv="content-language" content="en-us" />
<meta http-equiv="imagetoolbar" content="no" />
<meta name="resource-type" content="document" />
<meta name="distribution" content="global" />
<meta name="keywords" content="" />
<meta name="description" content="" />

<title>Flyfunston &bull; View topic - USHPA BOD meeting</title>



<!--
	phpBB style name: prosilver
	Based on style:   prosilver (this is the default phpBB3 style)
	Original author:  Tom Beddard ( http://www.subBlue.com/ )
	Modified by:
-->

<script type="text/javascript">
// <![CDATA[
	var jump_page = 'Enter the page number you wish to go to:';
	var on_page = '2';
	var per_page = '25';
	var base_url = 'viewtopic0a04.html?f=5&amp;t=1475';
	var style_cookie = 'phpBBstyle';
	var style_cookie_settings = '; path=/; domain=flyfunston.org; secure';
	var onload_functions = new Array();
	var onunload_functions = new Array();

	

	/**
	* Find a member
	*/
	function find_username(url)
	{
		popup(url, 760, 570, '_usersearch');
		return false;
	}

	/**
	* New function for handling multiple calls to window.onload and window.unload by pentapenguin
	*/
	window.onload = function()
	{
		for (var i = 0; i < onload_functions.length; i++)
		{
			eval(onload_functions[i]);
		}
	};

	window.onunload = function()
	{
		for (var i = 0; i < onunload_functions.length; i++)
		{
			eval(onunload_functions[i]);
		}
	};

// ]]>
</script>
<script type="text/javascript" src="styles/prosilver/template/styleswitcher.js"></script>
<script type="text/javascript" src="styles/prosilver/template/forum_fn.js"></script>

<link href="styles/prosilver/theme/print.css" rel="stylesheet" type="text/css" media="print" title="printonly" />
<link href="style7a95.css?id=1&amp;lang=en_us" rel="stylesheet" type="text/css" media="screen, projection" />

<link href="styles/prosilver/theme/normal.css" rel="stylesheet" type="text/css" title="A" />
<link href="styles/prosilver/theme/medium.css" rel="alternate stylesheet" type="text/css" title="A+" />
<link href="styles/prosilver/theme/large.css" rel="alternate stylesheet" type="text/css" title="A++" />



</head>

<body id="phpbb" class="section-viewtopic ltr">

<div id="wrap">
	<a id="top" name="top" accesskey="t"></a>
	<div id="page-header">
		<div class="headerbar">
			<div class="inner"><span class="corners-top"><span></span></span>

			<div id="site-description">
				<a href="index.html" title="Board index" id="logo"><img src="styles/prosilver/imageset/site_logo.gif" width="149" height="52" alt="" title="" /></a>
				<h1>Flyfunston</h1>
				<p>Hang Gliding at Fort Funston</p>
				<p class="skiplink"><a href="#start_here">Skip to content</a></p>
			</div>

		
			<div id="search-box">
				<form action="http://flyfunston.org/bbs/search.php" method="get" id="search">
				<fieldset>
					<input name="keywords" id="keywords" type="text" maxlength="128" title="Search for keywords" class="inputbox search" value="Search…" onclick="if(this.value=='Search…')this.value='';" onblur="if(this.value=='')this.value='Search…';" />
					<input class="button2" value="Search" type="submit" /><br />
					<a href="search.html" title="View the advanced search options">Advanced search</a> 
				</fieldset>
				</form>
			</div>
		

			<span class="corners-bottom"><span></span></span></div>
		</div>

		<div class="navbar">
			<div class="inner"><span class="corners-top"><span></span></span>

			<ul class="linklist navlinks">
				<li class="icon-home"><a href="index.html" accesskey="h">Board index</a>  <strong>&#8249;</strong> <a href="viewforumfdc5.html?f=9">Discussion Groups</a> <strong>&#8249;</strong> <a href="viewforume774.html?f=5">General Discussion</a></li>

				<li class="rightside"><a href="#" onclick="fontsizeup(); return false;" onkeypress="return fontsizeup(event);" class="fontsize" title="Change font size">Change font size</a></li>

				<li class="rightside"><a href="viewtopic4aea.html?f=5&amp;t=1475&amp;start=25&amp;view=print" title="Print view" accesskey="p" class="print">Print view</a></li>
			</ul>

			

			<ul class="linklist rightside">
				<li class="icon-faq"><a href="faq.html" title="Frequently Asked Questions">FAQ</a></li>
				
					<li class="icon-logout"><a href="ucp26c3.php?mode=login" title="Login" accesskey="x">Login</a></li>
				
			</ul>

			<span class="corners-bottom"><span></span></span></div>
		</div>

	</div>

	<a name="start_here"></a>
	<div id="page-body">
		
<h2><a href="viewtopic4927.php?f=5&amp;t=1475&amp;start=25">USHPA BOD meeting</a></h2>
<!-- NOTE: remove the style="display: none" when you want to have the forum description on the topic body --><div style="display: none !important;">Talk about Hang Gliding at Ft Funston and the Fellow Feathers Club.<br /></div>

<div class="topic-actions">

	<div class="buttons">
	
		<div class="reply-icon"><a href="posting92c2.php?mode=reply&amp;f=5&amp;t=1475" title="Post a reply"><span></span>Post a reply</a></div>
	
	</div>

	
		<div class="search-box">
			<form method="get" id="topic-search" action="http://flyfunston.org/bbs/search.php">
			<fieldset>
				<input class="inputbox search tiny"  type="text" name="keywords" id="search_keywords" size="20" value="Search this topic…" onclick="if(this.value=='Search this topic…')this.value='';" onblur="if(this.value=='')this.value='Search this topic…';" />
				<input class="button2" type="submit" value="Search" />
				<input type="hidden" name="t" value="1475" />
<input type="hidden" name="sf" value="msgonly" />

			</fieldset>
			</form>
		</div>
	
		<div class="pagination">
			42 posts
			 &bull; <a href="#" onclick="jumpto(); return false;" title="Click to jump to page…">Page <strong>2</strong> of <strong>2</strong></a> &bull; <span><a href="viewtopic0a04.html?f=5&amp;t=1475">1</a><span class="page-sep">, </span><strong>2</strong></span>
		</div>
	

</div>
<div class="clear"></div>


	<div id="p3752" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting16b9.html?mode=quote&amp;f=5&amp;p=3752" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 class="first"><a href="#p3752">Re: USHPA BOD meeting</a></h3>
			<p class="author"><a href="viewtopicfcd9.html?p=3752#p3752"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a></strong> &raquo; Wed Jan 29, 2014 4:12 pm </p>

			

			<div class="content"><blockquote><div><cite>bobk wrote:</cite>Let me repeat:</div></blockquote><br /><br />Repeat it all you want.  I don't think anyone cares about your rants.<br /><br /><blockquote class="uncited"><div>If you disagree with any of these assertions, please be specific. Thanks.</div></blockquote><br /><br />I've told you which assertions I disagree with - because they were *wrong*.  As far as these assertions go - who gives a shit.</div>

			

		</div>

		
			<dl class="postprofile" id="profile3752">
			<dt>
				<a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 93</dd><dd><strong>Joined:</strong> Wed Apr 20, 2011 11:40 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3754" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting669a.php?mode=quote&amp;f=5&amp;p=3754" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3754">Re: USHPA BOD meeting</a></h3>
			<p class="author"><a href="viewtopic7ebe.html?p=3754#p3754"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944">bobk</a></strong> &raquo; Thu Jan 30, 2014 11:07 am </p>

			

			<div class="content">Funston Pilots,<br /><br />It doesn't matter what I say or what Steve says or what Rick says. What matters is what the USHPA SOPs say.<br /><br />I've included the earliest version I found in my own records (July 2008), and the latest version I've seen (October 2013). Read them for yourself and decide <span style="text-decoration: underline">for yourself</span> if USHPA is protecting the rights of hang gliding clubs ... or undermining them. Pay particular attention to the requirements that clubs (not sites) cannot discriminate against pilots of either wing and the requirement that elections for club officers must be open to all members. Those two requirements - taken together - are the back door that USHPA has opened to allow the takeover of your club. As it stands right now, both the Fellow Feathers and the Torrey Hawks are sitting ducks waiting for USHPA to pull the trigger on us. Neither Steve nor Rick will admit that ... nor work to fix it.<br /><br />Bob Kuczewski<br />858-204-7499 ... please call me any time.<br /><br /><blockquote><div><cite>USHPA Chapter SOP from July 2008 wrote:</cite><br />United States Hang Gliding Association, Inc.<br />Standard Operating Procedures -6-1<br />CHAPTER REQUIREMENTS<br /><br />INTRODUCTION<br /><br />The USHGA Board of Directors has created a provision for USHGA Chapters. The object of this affiliation is to encourage a close relationship between the national organization and the various hang gliding and/or paragliding clubs and regional organizations. This close relationship helps to maximize the distribution of safety information and news and to promote the growth of the activity.<br /><br />Chapters are member-controlled organizations approved by the USHGA. Chapters must maintain at least five members and a certain percentage of their members as (current) USHGA members. The percentage of (current) USHGA members is the same as the percentage required to amend the organization’s bylaws, but not less than 70%. Chapters remain autonomous organizations, financially independent from the USHGA, and are self-governing.<br /><br />To minimize administration, USHGA dues for members of Chapters will ordinarily be paid on an individual basis directly to USHGA, although the Chapter may collect and submit dues for new members to help ensure that the required minimum membership percentage is met. Renewal dues will be solicited by USHGA directly from the members.<br /><br />Chapters must submit membership rosters to USHGA once each year at renewal time. The membership rosters are checked to determine that the minimum USHGA membership percentage requirement is met. If the percentage of (current) USHGA members falls below the requirement, the Chapter will be advised and will be allowed one month to increase the number of (current) USHGA members to correct the situation. Chapters must also submit a list of current Chapter officers including their contact names, officer positions, mailing addresses, phone numbers, fax numbers and email addresses. Failure to submit these lists at the Chapter renewal time will result in the temporary inactivation of a Chapter's official USHGA status until the lists are provided. A list of Chapters will be published in HANG GLIDING AND PARAGLIDING magazine from time to time.<br /><br />Tangible benefits of USHGA Chapter status are as follows:<br /><br />1. The Chapter is given two subscriptions to HANG GLIDING AND PARAGLIDING magazine for its library and to use for promotional purposes.<br /><br />2. Chapters will receive preferential news coverage in HANG GLIDING AND PARAGLIDING magazine and be specially noted in USHGA lists of hang gliding and/or paragliding organizations.<br /><br />3. Chapters may purchase designated items, which USHGA sells, at a special discount, in minimal quantities.<br /><br />4. Chapters ONLY may purchase Third Party Liability Bodily Injury and Property Damage Insurance. USHGA’s Third Party Liability coverage is available only to active USHGA Chapters and is for the purpose of covering the landowner(s) of the chapter’s controlled sites. The fee structure and amount are proposed by the Executive Director after securing the policy, reviewed and recommended by the Insurance Committee, and approved by the Board. Current rates are available from the office. Fees shall accompany the Chapter Site Insurance application/renewal forms.<br /><br />Intangible chapter benefits are numerous, and being subjective, depend on the person considering them, however, most significant is the effectiveness resulting from the unity of a large Chapter membership. The effectiveness of the USHGA as a membership association grows as the number of members and chapters increases.<br /><br />6.01 CHAPTER STATUS REQUIREMENTS<br /><br />USHGA chapter status requires written application by an officer of the organization. The officer should indicate intent to maintain the Chapter qualification requirements. Chapter applications are available at the USHGA office. Required paperwork includes the following items:<br /><br />1. A membership roster including the names and addresses of all members of the organization. (Indicate which members are USHGA members and provide their membership numbers and expiration dates.)<br /><br />2. A copy of the organization's bylaws.<br /><br />3. A copy of the organization's membership application form. (It is recommended that it have space for the applicant's USHGA number and expiration date.)<br /><br />4. The application should also include the names and addresses of two magazine subscription recipients. (The local library or the accommodating landowners are two possibilities.)<br /><br />6.02 SITE INSURANCE REQUIREMENTS<br /><br />A. All new site insurance requests require oral or written Regional Director approval. Approval of Chapter applications will be by letter after qualifications have been confirmed.<br /><br />B. The following points are the conditions of responsibility a Chapter accepts when requesting site landowner coverage. They represent the minimum standards established by USHGA and the insurance company to help administer safe, controlled flying sites that are to be covered by site landowner insurance obtained by USHGA.<br /><br />1. The Chapter will monitor or administer the site to assure that only USHGA member pilots fly the site or that other participating pilots have proof of independent insurance which has been determined by the USHGA to be of equal or greater coverage as that provided by USHGA to both the site and the pilot.<br /><br />2. The Chapter will establish minimum pilot rating requirements for safe use of the site.<br /><br />3. Pilots will be required to wear protective headgear while flying the site.<br /><br />4. Only USHGA members should act as launch assistants for those participants who are covered by landowner site insurance obtained from USHGA.<br /><br />5. Pilots using insured sites need to avoid safety violations and observe all safety precautions relevant to the site.<br /><br />6. USHGA requires a copy of the Chapter’s site rules or procedures.<br /><br />7. If a USHGA approved chapter implements its own waiver form, the USHGA must be named as a released party and the waiver must be reviewed by the USHGA office before it is implemented<br /><br />8. Chapters must provide USHGA with a comprehensive listing of additional insureds/landowners, showing their complete names and addresses and interests in the named property, including proof of ownership if requested by the Executive Director. There is no restriction on the number of additional insureds/landowners who may be listed on a site's certificate.<br /><br />9. USHGA requests a copy of any landowner agreements that may exist detailing the nature and extent of the use of the site.<br /><br />10. The Chapter must ensure that recreational flight privileges are made available at any insured site to any and all qualified USHGA members meeting Chapter site requirements in a fair and equitable manner without discrimination.<br /><br />11. Chapters may be able to share site insurance fees at common sites depending on the nature of the landowner agreements pertaining to the sites. It is recommended that the chapters alternate the fees from year to year.<br /><br />12. Any adverse incident caused by a non-member of USHGA could result in the local Chapter, its members or its site owners, being held responsible.<br /><br />13. The insurance policy has a pilot deductible. Should a claim be filed against the landowner or Chapter, the responsible pilot will be accountable for 100% of the deductible. If covered claims exceed the pilot deductible amount, the amount that exceeds the deductible is to be paid by the insurance company.<br /><br />14. It is the sole discretion of USHGA Board of Directors or its appointed agents to immediately suspend or cancel any and all insurance benefits.<br /><br />THIS DOCUMENT IS ISSUED FOR INFORMATIONAL PURPOSES ONLY AND CONFERS NO RIGHTS UPON USHGA CHAPTERS, MEMBERS OR SITE LANDOWNERS. THIS DOCUMENT DOES NOT AMEND, EXTEND OR ALTER THE COVERAGE AFFORDED BY THE INSURANCE POLICY. IN ORDER TO DETERMINE THE ACTUAL TERMS OF THE POLICY, THE EXTENT OF THE COVERAGE PROVIDED OR ANY APPLICABLE EXCLUSIONS, PLEASE REFER TO THE POLICY.<br /></div></blockquote><br /><br /><blockquote><div><cite>USHPA Chapter SOP from October 2013 wrote:</cite><br />The United States Hang Gliding and Paragliding Association, Inc.<br />Chapters<br />Standard Operating Procedure 06-01<br />Last Amended March, 2013<br /><br />06-01.01 Introduction<br /><br />Chapters are member controlled organizations affiliated with the USHPA in order to encourage a close relationship between the USHPA and hang gliding and paragliding clubs or organizations (“Clubs”) throughout the country. This close relationship helps to maximize the distribution of safety information and news, and to promote the growth of the sport.<br /><br />Chapters are autonomous organizations which are financially independent from the USHPA and are self-governing. To achieve Chapter status, Clubs must conform to guidelines set by the USHPA Board of Directors. In return, USHPA provides benefits to the Chapters.<br /><br />06-01.02 Chapter Benefits<br /><br />USHPA Chapters can take advantage of many benefits provided by USHPA. These include:<br /><br />A. Participation in the USHPA Third Party Liability Bodily Injury and Property Damage Insurance program. (Only USHPA Chapters can participate in the Third Party Liability Bodily Injury and Property Damage Insurance program. USHPA’s Third Party Liability coverage is for the purpose of covering the landowner(s) of the Chapter’s controlled sites. The fee structure and amount are proposed by the Executive Director after securing the policy, reviewed and recommended by the Insurance Committee, and approved by the Board. Current rates are available from the office. Fees shall accompany the Chapter Site Insurance application/renewal forms.)<br /><br />B. Participation in the Accredited Competitions and Events (“ACE”) program, including event insurance and corporate sponsorship (when available). (Only Chapters can receive corporate sponsorship through USHPA.)<br /><br />C. Access to USHPA’s publication resources, including:<br /><br />1. Chapter listing on USHPA web site.<br /><br />2. Periodic listing and preferential news coverage in Hang Gliding &amp; Paragliding magazine.<br /><br />3. Two subscriptions to Hang Gliding &amp; Paragliding magazine. (USHPA recommends these subscriptions be used for promotional purposes and be donated to libraries and/or land owners.)<br /><br />D. Access to the USHPA Site Guide.<br /><br />E. Access to materials for public relations projects.<br /><br />F. Additional leverage in lobbying efforts.<br /><br />G. Mailing labels and discounts on USHPA merchandise for Chapter projects and events.<br /><br />H. High traffic flying sites added to FAA Sectionals.<br /><br />Intangible Chapter benefits are numerous and depend on the person considering them. However, most significant is the effectiveness resulting from the unity of a large Chapter membership. The effectiveness of the USHPA as a membership association grows as the number of members and Chapters increases.<br /><br />06-01.03 Administrative Requirements<br /><br />The officers of hang gliding and paragliding Clubs can apply to USHPA to request Chapter status. Once a Club achieves Chapter status, it must renew each year. Chapter applications are available on the USHPA web site or from the USHPA office. Renewal applications are distributed each year by the office. When the USHPA office receives an application to form a new Chapter, the office must notify the Regional Director(s) in the Club’s region.<br /><br />A. When initially applying for or renewing Chapter status, the Club must submit the following documents:<br /><br />1. A list of current officers including names, addresses, telephone numbers, and email addresses. 60% of these officers, and all officers who are active pilots must be current USHPA members or renewals / chapter status will not be approved.<br /><br />a. Chapters also need a safety coordinator; this coordinator does not have to be a club officer.<br /><br />2. A membership roster including the names and addresses of all members of the Club. The roster must indicate whether the Club member is a USHPA member, and if so, include the member’s USHPA membership number and expiration date.<br /><br />3. A USHPA compliance certificate signed by the chapter safety coordinator.<br /><br />a. When signing this certificate the safety coordinator is acknowledging that the chapter has a current USHPA risk assessment and mitigation plan on file.<br /><br />b. New chapters and/or chapters opening up new flying sites will be given time to complete the risk assessment and mitigation plan: Up to but not exceeding 12 months or until the chapter renewal deadline.<br /><br />4. A copy of the Club's bylaws.<br /><br />5. A copy of the Club's membership application form.<br /><br />6. The names and addresses of two magazine subscription recipients.<br /><br />B. When the Chapter is requesting site insurance, the following documents must also be submitted annually:<br /><br />1. Copies of all additional waivers used at Club sites.<br /><br />2. Copies of the Club’s rules or procedures for all insured sites.<br /><br />3. A comprehensive list of additional insured parties/landowners, showing their complete names and addresses and interests in the named property, including proof of ownership if requested by the Executive Director. There is no restriction on the number of additional insured parties/landowners who may be listed on a site's certificate.<br /><br />4. A copy of any landowner agreements that may exist detailing the nature and extent of the use of the site must be submitted to USHPA.<br /><br />Once all of the Administrative requirements are met, the USHPA office can give Chapter status to a club as an administrative function.<br /><br />06-01.04 Organizational Requirements<br /><br />In order to obtain and retain Chapter status, Clubs are required to conform to certain organizational standards. These are:<br /><br />A. Chapters must have at least five Club members.<br /><br />B. At least 70% of the Club’s members must also be USHPA members, or the same percentage of Club members required to amend the Club’s bylaws must be USHPA members, whichever is greater.<br /><br />C. Chapters are required to hold annual elections for Club officers. Nominations for officer positions must be open to any Club member.<br /><br />D. Chapters are required to provide copies of Club bylaws, membership rosters and meeting minutes to all members of the Club.<br /><br />E. Chapters may not, as a matter of policy, negligently or willfully discriminate against pilots of one glider type, either hang glider or paraglider, or discriminate between pilots of equal pilot rating. Chapters must ensure that recreational flight privileges are made available to any and all qualified USHPA members meeting Chapter site requirements in a fair and equitable manner without discrimination.<br /><br />Note: This requirement does not indicate that a site cannot be hang gliding only or paragliding only. Glider specific sites are permissible for safety, land owner, and possibly other conditions.<br /><br />In extraordinary circumstances, a Club may not be able to conform to the organizational requirements. The Club can submit a request for exemption from an organizational requirement to the Chapter Support Committee. Exemptions to requirements must be approved by the Chapter Support Committee and the Board of Directors.<br /><br />06-01.05 Site Insurance Requirements<br /><br />A. All new site insurance requests require written approval of a Regional Director. Approval of Chapter applications will be by letter after qualifications have been confirmed.<br /><br />B. The following items are the conditions of responsibility a Chapter accepts when requesting site landowner coverage. They represent the minimum standards established by USHPA and the insurance company to help administer safe, controlled flying sites that are to be covered by site landowner insurance obtained by USHPA.<br /><br />1. The Chapter must establish minimum pilot rating requirements for safe use of the site.<br /><br />2. Chapters must enforce USHPA membership at insured sites. Unless a pilot has a chapter approved helmet sticker, the pilot must show a current USHPA membership card prior to setting up or laying out the glider.<br /><br />3. Chapters are encouraged to request permission from landowners to act with the landowner’s authority for site management. This permits chapters to have pilots charged with trespass for not being USHPA members or otherwise violating site rules.<br /><br />4. The Chapter must monitor or administer the site to assure that only USHPA member pilots fly the site or that other participating pilots have proof of independent insurance which has been determined by the USHPA to be of equal or greater coverage as that provided by USHPA to both the site and the pilot. Landowners may require non-USHPA members to sign the USHPA waiver or the landowner’s waiver in addition to satisfying the insurance requirement.<br /><br />5. Pilots must be required to wear protective headgear while flying the site.<br /><br />6. Only USHPA members must be permitted to act as launch assistants for those participants who are covered by landowner site insurance obtained from USHPA.<br /><br />7. Pilots using insured sites must avoid safety violations and observe all safety precautions relevant to the site.<br /><br />8. Chapters are required to take action against members and visiting pilots who do not consistently exercise and demonstrate those skills and level of judgment that are required for a USHPA rating.<br /><br />9. If a USHPA approved Chapter implements its own form of waiver, the USHPA must be named as a released party and the waiver must be reviewed by the USHPA office before it is implemented<br /><br />10. The insurance policy has a deductible and a claim limit. Chapters should refer to the insurance policy for specific information regarding coverage and limitations of the policy. The policy, in all cases, shall be the controlling document regarding such coverage. Should a claim be filed against a member, landowner, Chapter or USHPA, the member responsible for the damages is responsible for paying the insurance deductible and claims in excess of available coverage.<br /><br />11. The insurance policy is subject to renewal or cancellation. USHPA reserves the right to amend, modify or suspend site insurance at any time in its sole discretion.<br /><br />06-01.06 Suspension of Chapter Status<br /><br />A. Chapters are required to renew their Chapter status annually. Clubs failing to renew in a timely manner or failing to satisfy the conditions for renewal shall lose their Chapter status.<br /><br />B. If the USHPA determines a Chapter is not in compliance with the Administrative, Organizational, or Site Insurance Requirements above, the office will notify the Regional Directors in the region where the Chapter conducts business. The Chapter will be given 30 days to come into compliance, at which time the USHPA office can suspend the Chapter status as an administrative function.<br /><br />06-01.07 Revocation of Chapter Status<br /><br />The Board of Directors may revoke Chapter status for any club which does not conform to the Administrative, Organizational, or Site Insurance requirements. Once revoked, the Club can only regain Chapter status by vote of the Board of Directors.<br /><br />06-01.08 Disclaimer Statement<br /><br />THIS DOCUMENT IS ISSUED FOR INFORMATIONAL PURPOSES ONLY AND CONFERS NO RIGHTS UPON USHPA CHAPTERS, MEMBERS OR SITE LANDOWNERS. THIS DOCUMENT DOES NOT AMEND, EXTEND OR ALTER THE COVERAGE AFFORDED BY THE INSURANCE POLICY. IN ORDER TO DETERMINE THE ACTUAL TERMS OF THE POLICY, THE EXTENT OF THE COVERAGE PROVIDED OR ANY APPLICABLE EXCLUSIONS, PLEASE REFER TO THE POLICY.<br /></div></blockquote></div>

			<div id="sig3754" class="signature"><span style="font-size: 130%; line-height: 116%;"><span style="color: #000080"><span style="font-style: italic">Join a National Hang Gliding Organization:</span></span> <span style="font-weight: bold"><span style="color: #000080"><a href="http://ushawks.org/" class="postlink">US Hawks at ushawks.org</a></span></span></span></div>

		</div>

		
			<dl class="postprofile" id="profile3754">
			<dt>
				<a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944"><img src="download/file3928.html?avatar=1944_1390380842.jpeg" width="200" height="150" alt="User avatar" /></a><br />
				<a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944">bobk</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 138</dd><dd><strong>Joined:</strong> Tue Mar 22, 2011 1:53 pm</dd>
			<dd>
				<ul class="profile-icons">
					<li class="web-icon"><a href="http://ushawks.org/" title="WWW: http://ushawks.org"><span>Website</span></a></li>
				</ul>
			</dd>
		

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3755" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postingb8ec.html?mode=quote&amp;f=5&amp;p=3755" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3755">Re: USHPA BOD meeting</a></h3>
			<p class="author"><a href="viewtopic8ba5.html?p=3755#p3755"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a></strong> &raquo; Thu Jan 30, 2014 12:33 pm </p>

			

			<div class="content"><blockquote><div><cite>bobk wrote:</cite>Neither Steve nor Rick will admit that ...</div></blockquote><br /><br />What a moron!</div>

			

		</div>

		
			<dl class="postprofile" id="profile3755">
			<dt>
				<a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 93</dd><dd><strong>Joined:</strong> Wed Apr 20, 2011 11:40 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3756" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting60fc-2.html?mode=quote&amp;f=5&amp;p=3756" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3756">Re: USHPA BOD meeting</a></h3>
			<p class="author"><a href="viewtopic97f8.php?p=3756#p3756"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944">bobk</a></strong> &raquo; Thu Jan 30, 2014 1:13 pm </p>

			

			<div class="content"><blockquote><div><cite>spork wrote:</cite>who gives a shit.<br />What a moron!</div></blockquote><br /><span style="font-weight: bold"><span style="font-size: 130%; line-height: 116%;">Spork</span></span>, your use of name calling and profanity is a poor substitute for rational discussion and facts.<br /><br /><span style="font-weight: bold"><span style="font-size: 130%; line-height: 116%;">Fellow Feathers</span></span>, USHPA is carefully crafting their SOPs to eliminate hang gliding clubs. The proof is right there if you'll read it.<br /><br /><span style="font-weight: bold"><span style="font-size: 130%; line-height: 116%;">Steve Rodrigues</span></span>, I am asking you (and all other Regional Directors reading this) to remove the &quot;Organizational Requirements&quot; language that requires clubs to be biwingual. Will you do it?</div>

			<div id="sig3756" class="signature"><span style="font-size: 130%; line-height: 116%;"><span style="color: #000080"><span style="font-style: italic">Join a National Hang Gliding Organization:</span></span> <span style="font-weight: bold"><span style="color: #000080"><a href="http://ushawks.org/" class="postlink">US Hawks at ushawks.org</a></span></span></span></div>

		</div>

		
			<dl class="postprofile" id="profile3756">
			<dt>
				<a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944"><img src="download/file3928.html?avatar=1944_1390380842.jpeg" width="200" height="150" alt="User avatar" /></a><br />
				<a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944">bobk</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 138</dd><dd><strong>Joined:</strong> Tue Mar 22, 2011 1:53 pm</dd>
			<dd>
				<ul class="profile-icons">
					<li class="web-icon"><a href="http://ushawks.org/" title="WWW: http://ushawks.org"><span>Website</span></a></li>
				</ul>
			</dd>
		

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3757" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting6baf.php?mode=quote&amp;f=5&amp;p=3757" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3757">Re: USHPA BOD meeting</a></h3>
			<p class="author"><a href="viewtopicd903.html?p=3757#p3757"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a></strong> &raquo; Thu Jan 30, 2014 1:37 pm </p>

			

			<div class="content"><blockquote><div><cite>bobk wrote:</cite>your use of name calling and profanity is a poor substitute for rational discussion and facts.</div></blockquote><br /><br />It's the only appropriate response to your complete nonsense.  In what world have I refused to admit something about your stupid point!?</div>

			

		</div>

		
			<dl class="postprofile" id="profile3757">
			<dt>
				<a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 93</dd><dd><strong>Joined:</strong> Wed Apr 20, 2011 11:40 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3759" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting1cdc.php?mode=quote&amp;f=5&amp;p=3759" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3759">Re: USHPA BOD meeting</a></h3>
			<p class="author"><a href="viewtopicb6f3.html?p=3759#p3759"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944">bobk</a></strong> &raquo; Thu Jan 30, 2014 10:37 pm </p>

			

			<div class="content">Rick (Spork) and I had a long phone conversation this evening ... over an hour long.<br /><br />We agreed on some things and disagreed on some things, but it was generally civil and enjoyable. Thanks Rick. Please call any time.<br /><br />In the course of our conversation, Rick pointed out that I had no basis to assert that he liked the new SOP. Here's my quote:<br /><br /><blockquote class="uncited"><div>It appears that spork (well known for trying to increase PG access to Funston) seems to like this new SOP. Does anyone need any more proof than that?</div></blockquote><br /><br />Now I used some &quot;mush words&quot; in there like &quot;appears&quot; and &quot;seems&quot;, but Rick pointed out that I was still attempting to characterize his position without him actually stating it. In fact, Rick assured me that he hadn't even read the SOP, and certainly had not developed an opinion on it.<br /><br />OK. I'll take him on his word in the matter, and I therefore formally apologize to Rick for making assertions about his position which he had not explicitly stated. Rick, please accept my apology, and again, please call any time.<br /><br />Finally, I want to encourage more pilots to just call each other if they read something they don't like. My own phone number is 858-204-7499, and I welcome calls from all hang glider pilots who are sincere about improving our sport. Please post your own number and a convenient time to call if you'd rather that I drop the dime.<br /><br />Sincerely,<br />Bob Kuczewski<br /><br />P.S. Steve, I'm still calling for you to introduce a motion to the USHPA Board that they remove the organizational requirements which prohibit hang gliding only or paragliding only clubs. Thanks in advance.</div>

			<div id="sig3759" class="signature"><span style="font-size: 130%; line-height: 116%;"><span style="color: #000080"><span style="font-style: italic">Join a National Hang Gliding Organization:</span></span> <span style="font-weight: bold"><span style="color: #000080"><a href="http://ushawks.org/" class="postlink">US Hawks at ushawks.org</a></span></span></span></div>

		</div>

		
			<dl class="postprofile" id="profile3759">
			<dt>
				<a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944"><img src="download/file3928.html?avatar=1944_1390380842.jpeg" width="200" height="150" alt="User avatar" /></a><br />
				<a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944">bobk</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 138</dd><dd><strong>Joined:</strong> Tue Mar 22, 2011 1:53 pm</dd>
			<dd>
				<ul class="profile-icons">
					<li class="web-icon"><a href="http://ushawks.org/" title="WWW: http://ushawks.org"><span>Website</span></a></li>
				</ul>
			</dd>
		

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3760" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postingcbae.html?mode=quote&amp;f=5&amp;p=3760" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3760">Re: USHPA BOD meeting</a></h3>
			<p class="author"><a href="viewtopic0ac8.html?p=3760#p3760"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a></strong> &raquo; Thu Jan 30, 2014 11:28 pm </p>

			

			<div class="content">Thank you for that clarification Bob.  As I described to you on the phone there are plenty of things I feel strongly about - some related to this topic.  But I haven't paid enough attention to the SOP in question to think through the possible ramifications - good or bad.  I honestly don't have an opinion on it.    Despite what people like to claim - I have also never complained to the GGNRA, FAA, etc.  I have of course talked to some of them over the years to make sure I understand rules, regs, positions, etc.<br /><br />I do not currently have any plans to make further proposals to the Fellow Feathers regarding launching or landing of PG's at Funston.  I made a proposal, it was shouted down loudly, and I left it at that.  I do intend to continue to fly in any airspace I have a legal right to - as I'm sure all Funston pilots do.<br /><br />If anyone wants to know my position on something please feel free to ask.  I'm not shy about it.<br /><br />DISCLAIMER:  Things change.  If I have reason to make a complaint I imagine I will.  I have made offers in the past that were not unlimited time offers.  Not all of those offers still stand.</div>

			

		</div>

		
			<dl class="postprofile" id="profile3760">
			<dt>
				<a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 93</dd><dd><strong>Joined:</strong> Wed Apr 20, 2011 11:40 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3761" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postingec3b.html?mode=quote&amp;f=5&amp;p=3761" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3761">Re: USHPA BOD meeting</a></h3>
			<p class="author"><a href="viewtopicb496.html?p=3761#p3761"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944">bobk</a></strong> &raquo; Fri Jan 31, 2014 12:16 am </p>

			

			<div class="content"><blockquote><div><cite>spork wrote:</cite>Thank you for that clarification Bob.</div></blockquote><br /><br />You're welcome. Thanks for explaining the source of the disagreement and helping us to resolve it.<br /><br />Now back to the topic (USHPA BOD meeting), I would like to gather a consensus and your objective opinion is welcome.<br /><br />The USHPA Chapter SOP quoted above contains these two lines:<br /><br /><blockquote class="uncited"><div>C. Chapters are required to hold annual elections for Club officers. Nominations for officer positions must be open to any Club member.<br />E. Chapters may not, as a matter of policy, negligently or willfully discriminate against pilots of one glider type, either hang glider or paraglider ...</div></blockquote><br /><br />Would you say (from an objective viewpoint) that those two lines make hang gliding clubs (like Fellow Feathers and Torrey Hawks) vulnerable to being &quot;taken over&quot; if a large number of PG pilots decided to join, nominate their own PG officers, and demand the right to vote them in?<br /><br />Again, I'm asking for your objective opinion regardless of whether you would support such an action or not. Thanks in advance.</div>

			<div id="sig3761" class="signature"><span style="font-size: 130%; line-height: 116%;"><span style="color: #000080"><span style="font-style: italic">Join a National Hang Gliding Organization:</span></span> <span style="font-weight: bold"><span style="color: #000080"><a href="http://ushawks.org/" class="postlink">US Hawks at ushawks.org</a></span></span></span></div>

		</div>

		
			<dl class="postprofile" id="profile3761">
			<dt>
				<a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944"><img src="download/file3928.html?avatar=1944_1390380842.jpeg" width="200" height="150" alt="User avatar" /></a><br />
				<a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944">bobk</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 138</dd><dd><strong>Joined:</strong> Tue Mar 22, 2011 1:53 pm</dd>
			<dd>
				<ul class="profile-icons">
					<li class="web-icon"><a href="http://ushawks.org/" title="WWW: http://ushawks.org"><span>Website</span></a></li>
				</ul>
			</dd>
		

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3762" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting9b23.html?mode=quote&amp;f=5&amp;p=3762" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3762">Re: USHPA BOD meeting</a></h3>
			<p class="author"><a href="viewtopic8e41.php?p=3762#p3762"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a></strong> &raquo; Fri Jan 31, 2014 12:50 am </p>

			

			<div class="content"><blockquote><div><cite>bobk wrote:</cite>Would you say (from an objective viewpoint) that those two lines make hang gliding clubs (like Fellow Feathers and Torrey Hawks) vulnerable to being &quot;taken over&quot; if a large number of PG pilots decided to join, nominate their own PG officers, and demand the right to vote them in?</div></blockquote><br /><br />Based only one what I see in this thread, I would guess that the wording in those two lines is simply poor.  As Steve noted these lines are followed by a clause indicated that you can have HG-only or PG-only sites.  It's unfortunate that the wording in the two lines you posted refers to clubs while the wording in Steve's clause refers to sites.  It's also unfortunate that the wording in your two lines does not leave open for a provision to be modified by Steve's claus - but I think it's simply poor wording.  It wouldn't be the first time.<br /><br />As to being &quot;taken over - that's some pretty loaded language.  Did you feel the front of the bus was &quot;taken over&quot; by black folks when they insisted on asserting their rights?<br /><br />There's something kind of surprising to me about the fact that you want to take action because you feel under-represented at Torrey - and the action you want to take is to make sure that PG's are <span style="font-weight: bold"><span style="font-style: italic">completely</span></span> unrepresented at the Fort.  It would be at least a little less surprising if you didn't insist you had nothing against PG.</div>

			

		</div>

		
			<dl class="postprofile" id="profile3762">
			<dt>
				<a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 93</dd><dd><strong>Joined:</strong> Wed Apr 20, 2011 11:40 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3764" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting5416.html?mode=quote&amp;f=5&amp;p=3764" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3764">Re: USHPA BOD meeting</a></h3>
			<p class="author"><a href="viewtopicd725.html?p=3764#p3764"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944">bobk</a></strong> &raquo; Fri Jan 31, 2014 1:19 pm </p>

			

			<div class="content">Thanks for the comments Rick.<br /><br />We've had a little conflict in this topic due to my interpretation of your words. Fair enough, and I apologized. But isn't that what you're doing by making guesses that the SOPs mean something different from what they actually say? Without additional input from the SOP's actual author (good luck finding that out in USHPA's cocoon of secrecy), there's no basis to make an assertion of what they mean other than to take them literally. That's why I asked you to be objective in your review of the actual SOP wording.<br /><br />I assert that these SOPs were carefully written to mean exactly what they say (you may have noticed that no one from USHPA is jumping in here to say otherwise). I also assert that they were written specifically to target clubs like Fellow Feathers and Torrey Hawks. That's why I'm bringing the issue up with your club. I'd like the Fellow Feathers to join with the Torrey Hawks in asking USHPA to remove those SOPs so we don't have to hold our breath each year to see if our Chapter renewal paperwork will go through (or count on some buddy of ours &quot;looking out for us&quot; at USHPA ... in spite of the SOPs).<br /><br /><span style="font-size: 130%; line-height: 116%;"><span style="font-weight: bold">Fellow Feathers, Steve, Urs, Rick, and others, will you support repealing those sections of the USHPA Chapter SOP so that hang gliding clubs can be permitted as they were ... back when USHPA was USHGA?</span></span><br /><br />Thanks.<br /><br /><span style="color: #808080"><span style="font-size: 85%; line-height: 116%;">Friendly note to Rick: The &quot;back of the bus&quot; analogy is flawed. That's like saying that a horseback riding club must accept dirt bike riders in their club because they share the same trails. The laws against racial (and other) discriminations were never meant to be applied that way. Comparisons between Funston and Torrey are similarly flawed since we only have one legal launch/landing site at Torrey. The Funston ridge has separate launching and landing areas for HG and PG which facilitates separation by wing type and oversight by different clubs. That's why we need something like the Soaring Council or Advisory Board at Torrey where the different sports (through their different club representatives) can work together. You don't have that need at Funston. Furthermore, you already have two clubs which are recognized as representing the two sports. In San Diego, we only had one club which refused to give hang gliding any representation at Torrey Pines. The Torrey Hawks were formed to give hang gliding its own representation since the SDHGPA had become a mostly paragliding club.</span></span></div>

			<div id="sig3764" class="signature"><span style="font-size: 130%; line-height: 116%;"><span style="color: #000080"><span style="font-style: italic">Join a National Hang Gliding Organization:</span></span> <span style="font-weight: bold"><span style="color: #000080"><a href="http://ushawks.org/" class="postlink">US Hawks at ushawks.org</a></span></span></span></div>

		</div>

		
			<dl class="postprofile" id="profile3764">
			<dt>
				<a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944"><img src="download/file3928.html?avatar=1944_1390380842.jpeg" width="200" height="150" alt="User avatar" /></a><br />
				<a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944">bobk</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 138</dd><dd><strong>Joined:</strong> Tue Mar 22, 2011 1:53 pm</dd>
			<dd>
				<ul class="profile-icons">
					<li class="web-icon"><a href="http://ushawks.org/" title="WWW: http://ushawks.org"><span>Website</span></a></li>
				</ul>
			</dd>
		

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3765" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting91fa.html?mode=quote&amp;f=5&amp;p=3765" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3765">Re: USHPA BOD meeting</a></h3>
			<p class="author"><a href="viewtopicc669.php?p=3765#p3765"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a></strong> &raquo; Fri Jan 31, 2014 2:30 pm </p>

			

			<div class="content"><blockquote><div><cite>bobk wrote:</cite>isn't that what you're doing by making guesses that the SOPs mean something different from what they actually say?</div></blockquote><br /><br />I'm certainly not putting words in your mouth.  I may be putting words into the mouths of those that drafted the SOP - in part because we don't have them here to offer the clarification themselves.  I certainly wouldn't say my interpretation is the right one.  It's just my best guess.<br /><br /><blockquote class="uncited"><div>Without additional input from the SOP's actual author (good luck finding that out in USHPA's cocoon of secrecy), there's no basis to make an assertion of what they mean other than to take them literally.</div></blockquote><br /><br />In general I think it's wise to consider the most literal interpretation - particularly when that's the interpretation they may choose to use against you.  I don't know what their agenda is, if any, so I'm just trying to guess what they mean - and I certainly may be getting it wrong.<br /><br /><blockquote class="uncited"><div>I assert that these SOPs were carefully written to mean exactly what they say</div></blockquote><br /><br />Perhaps.  Can you get them to weigh in?<br /><br /><blockquote class="uncited"><div>I also assert that they were written specifically to target clubs like Fellow Feathers and Torrey Hawks.</div></blockquote><br /><br />The dealings and politics at that level is far beyond my pay-grade.  Perhaps you're right.<br /><br /><blockquote class="uncited"><div><span style="font-size: 130%; line-height: 116%;"><span style="font-weight: bold">Fellow Feathers, Steve, Urs, Rick, and others, will you support repealing those sections of the USHPA Chapter SOP so that hang gliding clubs can be permitted as they were ... back when USHPA was USHGA?</span></span></div></blockquote><br /><br />Not me.  <br /><br /><blockquote class="uncited"><div>Friendly note to Rick: The &quot;back of the bus&quot; analogy is flawed. That's like saying that a horseback riding club must accept dirt bike riders in their club because they share the same trails.</div></blockquote><br /><br />We fundamentally disagree on this point.  If it were brought to the state I'm pretty sure they'd disagree with your POV as well.  Is that a gamble you want to take?<br /><br /><blockquote class="uncited"><div>The Funston ridge has separate launching and landing areas for HG and PG which facilitates separation by wing type and oversight by different clubs.</div></blockquote><br /><br />Comparing the stables launch to Ft Funston is absolutely ridiculous.   I hope I don't have to explain that in detail.<br /><br /><blockquote class="uncited"><div>Furthermore, you already have two clubs which are recognized as representing the two sports.</div></blockquote><br /><br />At the moment there is only one club that has an arrangement for operations at Ft. Funston.  Is that something you are prepared to change.<br /><br /><blockquote class="uncited"><div>In San Diego, we only had one club which refused to give hang gliding any representation at Torrey Pines.</div></blockquote><br /><br />HG's clearly have better representation at Torrey than PG does at Funston.</div>

			

		</div>

		
			<dl class="postprofile" id="profile3765">
			<dt>
				<a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 93</dd><dd><strong>Joined:</strong> Wed Apr 20, 2011 11:40 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3766" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting1720.html?mode=quote&amp;f=5&amp;p=3766" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3766">Re: USHPA BOD meeting</a></h3>
			<p class="author"><a href="viewtopic1749.php?p=3766#p3766"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944">bobk</a></strong> &raquo; Fri Jan 31, 2014 10:36 pm </p>

			

			<div class="content">Hi Rick,<br /><br />Regarding the interpretation of the SOP, I think we've both stated our cases well enough for anyone reading this topic to make up their own mind. So I'm happy to let it stand as is. Thanks for entertaining the discussion.<br /><br />But I would like some clarification on the Torrey / Funston comparison.<br /><br />I thought PG pilots had a launch near the highest part of the ridge above the bowl (dump area). I distinctly remember seeing PG pilots launching from there when I was flying there in 2012. Is that launch no longer available?<br /><br />This is a key issue because I believe it's currently illegal to launch at Torrey from <span style="text-decoration: underline">any</span> part of the <span style="text-decoration: underline">entire</span> ridge other than the Gliderport itself. That gives the Torrey concessionaire a monopoly on flying the entire &quot;La Jolla&quot; ridge, and that's partly why we need a multi-disciplinary group like the Soaring Council to ensure fairness. If there are multiple legal launch areas along your <span style="text-decoration: underline">entire</span> ridge (beyond what may be considered &quot;Funston&quot;) then I think that does come into play in finding a fair solution. Please let me know the current status of those other launches.<br /><br />Finally, I'm sad to see that you do not support repealing those SOP changes. Those SOP changes are an attempt to force all Chapters to be biwingual and to remove their long-standing right to be HG only or PG only. On the other hand, there is a growing national hang gliding association that does allow its Chapters to be either HG-only or biwingual. It's called the <span style="font-weight: bold"><a href="http://ushawks.org/" class="postlink">US Hawks</a></span>, and we've just added another Chapter to our roster (Welcome Rio Grande Soaring Association!!). While I wish USHPA would repeal this particular SOP change, I do appreciate how their heavy-handedness helps grow the US Hawks!!<br /><br /><span style="font-size: 130%; line-height: 116%;"><span style="font-weight: bold">Fellow Feathers, Steve, Urs, and others, will you support repealing those sections of the USHPA Chapter SOP so that hang gliding clubs can be permitted as they were ... back when USHPA was USHGA?</span></span></div>

			<div id="sig3766" class="signature"><span style="font-size: 130%; line-height: 116%;"><span style="color: #000080"><span style="font-style: italic">Join a National Hang Gliding Organization:</span></span> <span style="font-weight: bold"><span style="color: #000080"><a href="http://ushawks.org/" class="postlink">US Hawks at ushawks.org</a></span></span></span></div>

		</div>

		
			<dl class="postprofile" id="profile3766">
			<dt>
				<a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944"><img src="download/file3928.html?avatar=1944_1390380842.jpeg" width="200" height="150" alt="User avatar" /></a><br />
				<a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944">bobk</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 138</dd><dd><strong>Joined:</strong> Tue Mar 22, 2011 1:53 pm</dd>
			<dd>
				<ul class="profile-icons">
					<li class="web-icon"><a href="http://ushawks.org/" title="WWW: http://ushawks.org"><span>Website</span></a></li>
				</ul>
			</dd>
		

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3767" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postingb95d.html?mode=quote&amp;f=5&amp;p=3767" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3767">Re: USHPA BOD meeting</a></h3>
			<p class="author"><a href="viewtopicefaf.php?p=3767#p3767"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a></strong> &raquo; Fri Jan 31, 2014 11:02 pm </p>

			

			<div class="content"><blockquote><div><cite>bobk wrote:</cite>I thought PG pilots had a launch near the highest part of the ridge above the bowl (dump area). I distinctly remember seeing PG pilots launching from there when I was flying there in 2012. Is that launch no longer available?</div></blockquote><br /><br />There are launches down at Mussel Rock.  It is not a regulated site.  HG and PG can and do launch there.<br /><br /><blockquote class="uncited"><div>If there are multiple legal launch areas along your <span style="text-decoration: underline">entire</span> ridge (beyond what may be considered &quot;Funston&quot;) then I think that does come into play in finding a fair solution.</div></blockquote><br /><br />The Fellow Feathers have no interest in finding a fair solution.  They've made that very clear.  Their position has been - HG's fly anywhere; PG's fly anywhere but here.  But frankly, I don't know why we're talking about it.  There was a proposal a long time ago.  It was shouted down.  It's over.  We all can and do fly in any uncontrolled airspace.  PG's do not launch and land at Funston.<br /><br /><blockquote class="uncited"><div>Finally, I'm sad to see that you do not support repealing those SOP changes.</div></blockquote><br /><br />And I'm sad to see that you're so strongly committed to campaign against equal access for PG's.  That's why they make menus.</div>

			

		</div>

		
			<dl class="postprofile" id="profile3767">
			<dt>
				<a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 93</dd><dd><strong>Joined:</strong> Wed Apr 20, 2011 11:40 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3768" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting8676.html?mode=quote&amp;f=5&amp;p=3768" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3768">Re: USHPA BOD meeting</a></h3>
			<p class="author"><a href="viewtopicbec3.html?p=3768#p3768"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944">bobk</a></strong> &raquo; Sat Feb 01, 2014 12:30 am </p>

			

			<div class="content">Well Rick,<br /><br />We're not in complete agreement, but we have a better understanding of each other's positions than we had before.<br />Thanks for the phone call. Please call any time.<br /><br />Bob Kuczewski</div>

			<div id="sig3768" class="signature"><span style="font-size: 130%; line-height: 116%;"><span style="color: #000080"><span style="font-style: italic">Join a National Hang Gliding Organization:</span></span> <span style="font-weight: bold"><span style="color: #000080"><a href="http://ushawks.org/" class="postlink">US Hawks at ushawks.org</a></span></span></span></div>

		</div>

		
			<dl class="postprofile" id="profile3768">
			<dt>
				<a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944"><img src="download/file3928.html?avatar=1944_1390380842.jpeg" width="200" height="150" alt="User avatar" /></a><br />
				<a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944">bobk</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 138</dd><dd><strong>Joined:</strong> Tue Mar 22, 2011 1:53 pm</dd>
			<dd>
				<ul class="profile-icons">
					<li class="web-icon"><a href="http://ushawks.org/" title="WWW: http://ushawks.org"><span>Website</span></a></li>
				</ul>
			</dd>
		

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3786" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting788c.html?mode=quote&amp;f=5&amp;p=3786" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3786">Upcoming 2014 Spring USHPA BOD meeting</a></h3>
			<p class="author"><a href="viewtopice08a.html?p=3786#p3786"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944">bobk</a></strong> &raquo; Sat Feb 22, 2014 1:16 am </p>

			

			<div class="content">I've gotten a recent message from USHPA telling me about their upcoming proposed SOP changes. Very good. However, when you go to download the actual proposed SOP changes, the language at the time of download implies that the information cannot be posted or shared for discussion. Not so good.<br /><br />Anyway, if you take the time to go to USHPA's site and download the draft SOP changes, you'll see that they're still trying to force all clubs to be biwingual. I'll be writing my own draft of that SOP in the near future, but in the mean time, I've sent this message to all of our Region 3 Directors with a copy to USHPA President Rich Hass and a few others:<br /><br /><blockquote class="uncited"><div>Region 3 Directors (and others),<br /><br />I have read the recent SOP Changes posted on USHPA's web site and included below. I would like to offer my comments on the proposed SOP 06-01 changes which deal with USHPA Chapters.<br /><br />First off, I would like to remind all Directors that for much of USHGA's history, ALL of its Chapters were hang gliding chapters because paragliding did not exist. When paragliding was accepted into the association, I don't believe the members were told that their hang gliding clubs would eventually have to become hang gliding AND paragliding clubs. In fact, I'll bet they were told that everything would remain as it had been ... no cause for alarm.<br /><br />But slowly, USHPA has begun to FORCE paragliding onto hang gliding clubs (and force hang gliding onto paragliding clubs). This is NOT an appropriate role for USHPA. I believe that if the hang gliding pilots who voted to accept paragliding knew that this would happen, there would have been a different outcome. This has been a slow motion version of the &quot;bait and switch&quot;.<br /><br />Furthermore this SOP is an affront to our basic freedom of association. If hang gliding pilots want to have a plain old hang gliding club, they should have that right. If paragliding pilots want to have a plain old paragliding club, they should have that right as well. And pilots who want to form biwingual clubs should be free to do so. Pilots can then choose which clubs they want to support with their membership dollars based on what those clubs support. USHPA has no business telling pilots what kinds of clubs they can and cannot form.<br /><br />Finally, since this particular SOP appears to be up for redrafting, I'd like to offer my own suggested version in the near future. I haven't written it yet, but it will basically say that Chapters are free to form any kind of clubs that the law allows. It will say that USHPA may encourage biwingual clubs (since USHPA is a biwingual association), but that USHPA will NOT discriminate based on the kinds of clubs that USHPA members choose to form. It will say that USHPA will support ALL of its chapters equally and not play &quot;favorites&quot; ... as USHPA has in the past.<br /><br />Until then,<br />Bob Kuczewski<br />H4/P4, Former Region 3 Director, Club Secretary - Torrey Hawks</div></blockquote><br /><br />You can read more at: <a href="http://ushawks.org/forum/viewtopic.php?f=2&amp;t=1513" class="postlink">http://ushawks.org/forum/viewtopic.php?f=2&amp;t=1513</a></div>

			<div id="sig3786" class="signature"><span style="font-size: 130%; line-height: 116%;"><span style="color: #000080"><span style="font-style: italic">Join a National Hang Gliding Organization:</span></span> <span style="font-weight: bold"><span style="color: #000080"><a href="http://ushawks.org/" class="postlink">US Hawks at ushawks.org</a></span></span></span></div>

		</div>

		
			<dl class="postprofile" id="profile3786">
			<dt>
				<a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944"><img src="download/file3928.html?avatar=1944_1390380842.jpeg" width="200" height="150" alt="User avatar" /></a><br />
				<a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944">bobk</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 138</dd><dd><strong>Joined:</strong> Tue Mar 22, 2011 1:53 pm</dd>
			<dd>
				<ul class="profile-icons">
					<li class="web-icon"><a href="http://ushawks.org/" title="WWW: http://ushawks.org"><span>Website</span></a></li>
				</ul>
			</dd>
		

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3787" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting54af.html?mode=quote&amp;f=5&amp;p=3787" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3787">Re: Upcoming 2014 Spring USHPA BOD meeting</a></h3>
			<p class="author"><a href="viewtopic8e8a.html?p=3787#p3787"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944">bobk</a></strong> &raquo; Mon Feb 24, 2014 12:19 am </p>

			

			<div class="content"><blockquote><div><cite>bobk wrote:</cite>I'll be writing my own draft of that SOP in the near future ...</div></blockquote><br /><br />I just finished sending my own proposed rewrite of SOP 06-01 to our Region 3 Directors and USHPA President Rich Hass. My version is quite a bit shorter than USHPA's version and it gives more freedoms to Chapters. The original USHPA version stated that Chapters were &quot;autonomous organizations&quot;, but then it went on to contradict itself by specifying all sorts of internal organizational requirements that Chapters had to meet. The USHPA version also made it much more difficult for Chapters to regain Chapter status after losing it. My version does not penalize Chapters.<br /><br />You can read the currently proposed USHPA version here:<br /><br /><!-- m --><a class="postlink" href="http://www.ushpa.aero/board_meeting.asp">http://www.ushpa.aero/board_meeting.asp</a><!-- m --><br /><br />Here's what I've proposed as a compromise that vests more autonomy with local clubs. Please compare it to the current USHPA SOP and what is being proposed for the upcoming Board Meeting.<br /><br /><blockquote><div><cite>Proposed SOP wrote:</cite>The United States Hang Gliding and Paragliding Association, Inc.<br />Chapters<br />Standard Operating Procedure 06-01<br />[DRAFT with Bob Kuczewski's suggestions]<br /><br />06-01.01 Introduction<br /><br />Chapters are member-controlled clubs affiliated with USHPA to encourage a close relationship between USHPA and local hang gliding and paragliding communities throughout the country.<br /><br />Chapters are autonomous organizations that are financially independent from USHPA and are self-governing. USHPA does not interfere with the internal operations of any USHPA Chapters. Multiple USHPA Chapters may be formed in a given area to satisfy the needs of hang gliding pilots or paragliding pilots or biwingual pilots or for any other reason deemed appropriate by the members who form such clubs. USHPA's policy is to support all USHPA Chapters in a fair and equitable manner.<br /><br />06-01.02 Chapter Benefits<br /><br />USHPA chapters can take advantage of many benefits provided by USHPA, to the extent such benefits are available. Chapter benefits include:<br /><br />     A. Participation in the USHPA site insurance program. See SOP 06-02.<br />     B. Participation in the Accredited Competitions and Events (“ACE”) program. See SOP 06-03.<br />     C. Access to USHPA’s publication resources, including:<br />              ... 1. Chapter listing on USHPA web site.<br />              ... 2. Chapter event listings on the USHPA website.<br />              ... 3. Periodic listing and news coverage for chapter events in Hang Gliding &amp; Paragliding magazine.<br />              ... 4. Two subscriptions to Hang Gliding &amp; Paragliding magazine for promotional purposes as donations to libraries, public officials and landowners.<br />     D. Chapter flying sites are listed in the USHPA Site Guide.<br />     E. Access to materials for public relations projects.<br />     F. Additional leverage in lobbying efforts.<br />     G. Access to USHPA member mailing labels for members in their region.<br />     H. Chapters are eligible for discounts on USHPA merchandise for special projects and events.<br />     I.   USHPA assistance in getting high traffic flying sites added to FAA Sectionals.<br />     J.   Increased credibility when dealing with landowners and public officials<br /><br />06-01.03 Administrative Requirements<br /><br />Hang gliding and paragliding clubs can apply for Chapter status by completing and submitting a chapter application to USHPA together with the required one-time documentation fee for new chapters. Chapters are required to complete and return a chapter renewal application annually.<br /><br />Requirements for chapter status:<br /><br />    A. Chapters must have at least five members.<br />    B. At least 50% of the chapter members must be USHPA members. Chapters are required to provide USHPA with a membership roster annually. The roster must include names and USHPA membership numbers for USHPA members.<br />    C. Not less than 50% of chapter officers must be USHPA members.<br />    D. Chapters are required to appoint or elect a Safety Coordinator responsible for encouraging safety and helping develop and implement site risk assessments and safety protocols. The safety coordinator must be a USHPA member but is not required to be a club officer or board member.<br />    E. Chapters are required to provide USHPA with current chapter bylaws.<br /><br />06-01.04 Suspension of Chapter Status<br /><br />     A. Chapters are required to renew their Chapter status annually. Clubs failing to renew in a timely manner or failing to satisfy the conditions for renewal shall have their chapter status suspended.<br />     B. If USHPA determines a chapter is not in compliance with the requirements for Chapter status (A-E above), USHPA may temporarily suspend chapter status by notifying the chapter's officers.<br /><br />06-01.05 Revocation of Chapter Status<br /><br />USHPA does not permanently revoke Chapter Status. However, any suspension under this SOP will continue in force until such time as all requirements are met. Chapters may request to have their Chapter status permanently removed by formal request of the Chapter's President.<br /><br />06-01.06 Disclaimer Statement<br /><br />THIS DOCUMENT IS ISSUED FOR INFORMATIONAL PURPOSES ONLY AND CONFERS NO RIGHTS UPON USHPA CHAPTERS, MEMBERS OR SITE LANDOWNERS. THIS DOCUMENT DOES NOT AMEND, EXTEND OR ALTER THE COVERAGE AFFORDED BY THE INSURANCE POLICY. IN ORDER TO DETERMINE THE ACTUAL TERMS OF THE POLICY, THE EXTENT OF THE COVERAGE PROVIDED OR ANY APPLICABLE EXCLUSIONS, PLEASE REFER TO THE POLICY.</div></blockquote><br /><br /><span style="color: #FF0000"><span style="font-size: 130%; line-height: 116%;"><span style="font-weight: bold">I am calling on Steve, Urs, and all other Directors to support this version or something very similar.</span></span></span><br /><br />Thanks,<br />Bob Kuczewski<br />Former USHPA Director - Region 3</div>

			<div id="sig3787" class="signature"><span style="font-size: 130%; line-height: 116%;"><span style="color: #000080"><span style="font-style: italic">Join a National Hang Gliding Organization:</span></span> <span style="font-weight: bold"><span style="color: #000080"><a href="http://ushawks.org/" class="postlink">US Hawks at ushawks.org</a></span></span></span></div>

		</div>

		
			<dl class="postprofile" id="profile3787">
			<dt>
				<a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944"><img src="download/file3928.html?avatar=1944_1390380842.jpeg" width="200" height="150" alt="User avatar" /></a><br />
				<a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944">bobk</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 138</dd><dd><strong>Joined:</strong> Tue Mar 22, 2011 1:53 pm</dd>
			<dd>
				<ul class="profile-icons">
					<li class="web-icon"><a href="http://ushawks.org/" title="WWW: http://ushawks.org"><span>Website</span></a></li>
				</ul>
			</dd>
		

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3794" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting07d1.html?mode=quote&amp;f=5&amp;p=3794" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3794">Re: USHPA BOD meeting</a></h3>
			<p class="author"><a href="viewtopicd441.php?p=3794#p3794"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944">bobk</a></strong> &raquo; Mon Feb 24, 2014 8:06 pm </p>

			

			<div class="content"><span style="font-weight: bold"><span style="color: #FF0000"><span style="font-size: 150%; line-height: 116%;">Steve? Urs? Other Directors?</span></span></span><br /><br /><span style="font-weight: bold">There's a copy of a proposed SOP (right above this post) that basically says that USHPA should NOT be telling Chapters how they should be organized with regard to hang gliding and paragliding. Will you support it or not?</span></div>

			<div id="sig3794" class="signature"><span style="font-size: 130%; line-height: 116%;"><span style="color: #000080"><span style="font-style: italic">Join a National Hang Gliding Organization:</span></span> <span style="font-weight: bold"><span style="color: #000080"><a href="http://ushawks.org/" class="postlink">US Hawks at ushawks.org</a></span></span></span></div>

		</div>

		
			<dl class="postprofile" id="profile3794">
			<dt>
				<a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944"><img src="download/file3928.html?avatar=1944_1390380842.jpeg" width="200" height="150" alt="User avatar" /></a><br />
				<a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944">bobk</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 138</dd><dd><strong>Joined:</strong> Tue Mar 22, 2011 1:53 pm</dd>
			<dd>
				<ul class="profile-icons">
					<li class="web-icon"><a href="http://ushawks.org/" title="WWW: http://ushawks.org"><span>Website</span></a></li>
				</ul>
			</dd>
		

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<form id="viewtopic" method="post" action="http://flyfunston.org/bbs/viewtopic.php?f=5&amp;t=1475&amp;start=25">

	<fieldset class="display-options" style="margin-top: 0; ">
		<a href="viewtopic7ed8.html?f=5&amp;t=1475&amp;start=0" class="left-box left">Previous</a>
		<label>Display posts from previous: <select name="st" id="st"><option value="0" selected="selected">All posts</option><option value="1">1 day</option><option value="7">7 days</option><option value="14">2 weeks</option><option value="30">1 month</option><option value="90">3 months</option><option value="180">6 months</option><option value="365">1 year</option></select></label>
		<label>Sort by <select name="sk" id="sk"><option value="a">Author</option><option value="t" selected="selected">Post time</option><option value="s">Subject</option></select></label> <label><select name="sd" id="sd"><option value="a" selected="selected">Ascending</option><option value="d">Descending</option></select> <input type="submit" name="sort" value="Go" class="button2" /></label>
		
	</fieldset>

	</form>
	<hr />


<div class="topic-actions">
	<div class="buttons">
	
		<div class="reply-icon"><a href="posting92c2.php?mode=reply&amp;f=5&amp;t=1475" title="Post a reply"><span></span>Post a reply</a></div>
	
	</div>

	
		<div class="pagination">
			42 posts
			 &bull; <a href="#" onclick="jumpto(); return false;" title="Click to jump to page…">Page <strong>2</strong> of <strong>2</strong></a> &bull; <span><a href="viewtopic0a04.html?f=5&amp;t=1475">1</a><span class="page-sep">, </span><strong>2</strong></span>
		</div>
	
</div>


	<p></p><p><a href="viewforume774.html?f=5" class="left-box left" accesskey="r">Return to General Discussion</a></p>

	<form method="post" id="jumpbox" action="http://flyfunston.org/bbs/viewforum.php" onsubmit="if(this.f.value == -1){return false;}">

	
		<fieldset class="jumpbox">
	
			<label for="f" accesskey="j">Jump to:</label>
			<select name="f" id="f" onchange="if(this.options[this.selectedIndex].value != -1){ document.forms['jumpbox'].submit() }">
			
				<option value="-1">Select a forum</option>
			<option value="-1">------------------</option>
				<option value="9">Discussion Groups</option>
			
				<option value="5" selected="selected">&nbsp; &nbsp;General Discussion</option>
			
				<option value="8">&nbsp; &nbsp;Announcements</option>
			
				<option value="7">&nbsp; &nbsp;For Sale/Wanted</option>
			
				<option value="6">&nbsp; &nbsp;Road Trips</option>
			
				<option value="2">&nbsp; &nbsp;Meeting Minutes and Treasurer Reports</option>
			
				<option value="11">&nbsp; &nbsp;Off Topic</option>
			
			</select>
			<input type="submit" value="Go" class="button2" />
		</fieldset>
	</form>


	<h3>Who is online</h3>
	<p>Users browsing this forum: No registered users and 7 guests</p>
</div>

<div id="page-footer">

	<div class="navbar">
		<div class="inner"><span class="corners-top"><span></span></span>

		<ul class="linklist">
			<li class="icon-home"><a href="index.html">Board index</a></li>
				
			<li class="rightside"><a href="memberlista2f5.html?mode=leaders">The team</a> &bull; <a href="ucp033a.html?mode=delete_cookies">Delete all board cookies</a> &bull; All times are UTC - 8 hours [ <abbr title="Daylight Saving Time">DST</abbr> ]</li>
		</ul>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<div class="copyright">Powered by <a href="https://www.phpbb.com/">phpBB</a>&reg; Forum Software &copy; phpBB Group
		
	</div>
</div>

</div>

<div>
	<a id="bottom" name="bottom" accesskey="z"></a>
	
</div>

</body>

<!-- Mirrored from flyfunston.org/bbs/viewtopic.php?p=3762 by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 08 Aug 2021 20:05:08 GMT -->
</html>