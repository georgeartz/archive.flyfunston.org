<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en-us" xml:lang="en-us">

<!-- Mirrored from flyfunston.org/bbs/viewtopic.php?p=2151 by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 08 Aug 2021 20:05:49 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>

<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<meta http-equiv="content-style-type" content="text/css" />
<meta http-equiv="content-language" content="en-us" />
<meta http-equiv="imagetoolbar" content="no" />
<meta name="resource-type" content="document" />
<meta name="distribution" content="global" />
<meta name="keywords" content="" />
<meta name="description" content="" />

<title>Flyfunston &bull; View topic - Clubhouse waiting list</title>



<!--
	phpBB style name: prosilver
	Based on style:   prosilver (this is the default phpBB3 style)
	Original author:  Tom Beddard ( http://www.subBlue.com/ )
	Modified by:
-->

<script type="text/javascript">
// <![CDATA[
	var jump_page = 'Enter the page number you wish to go to:';
	var on_page = '1';
	var per_page = '25';
	var base_url = 'viewtopic48d0.html?f=5&amp;t=713';
	var style_cookie = 'phpBBstyle';
	var style_cookie_settings = '; path=/; domain=flyfunston.org; secure';
	var onload_functions = new Array();
	var onunload_functions = new Array();

	

	/**
	* Find a member
	*/
	function find_username(url)
	{
		popup(url, 760, 570, '_usersearch');
		return false;
	}

	/**
	* New function for handling multiple calls to window.onload and window.unload by pentapenguin
	*/
	window.onload = function()
	{
		for (var i = 0; i < onload_functions.length; i++)
		{
			eval(onload_functions[i]);
		}
	};

	window.onunload = function()
	{
		for (var i = 0; i < onunload_functions.length; i++)
		{
			eval(onunload_functions[i]);
		}
	};

// ]]>
</script>
<script type="text/javascript" src="styles/prosilver/template/styleswitcher.js"></script>
<script type="text/javascript" src="styles/prosilver/template/forum_fn.js"></script>

<link href="styles/prosilver/theme/print.css" rel="stylesheet" type="text/css" media="print" title="printonly" />
<link href="style7a95.css?id=1&amp;lang=en_us" rel="stylesheet" type="text/css" media="screen, projection" />

<link href="styles/prosilver/theme/normal.css" rel="stylesheet" type="text/css" title="A" />
<link href="styles/prosilver/theme/medium.css" rel="alternate stylesheet" type="text/css" title="A+" />
<link href="styles/prosilver/theme/large.css" rel="alternate stylesheet" type="text/css" title="A++" />



</head>

<body id="phpbb" class="section-viewtopic ltr">

<div id="wrap">
	<a id="top" name="top" accesskey="t"></a>
	<div id="page-header">
		<div class="headerbar">
			<div class="inner"><span class="corners-top"><span></span></span>

			<div id="site-description">
				<a href="index.html" title="Board index" id="logo"><img src="styles/prosilver/imageset/site_logo.gif" width="149" height="52" alt="" title="" /></a>
				<h1>Flyfunston</h1>
				<p>Hang Gliding at Fort Funston</p>
				<p class="skiplink"><a href="#start_here">Skip to content</a></p>
			</div>

		
			<div id="search-box">
				<form action="http://flyfunston.org/bbs/search.php" method="get" id="search">
				<fieldset>
					<input name="keywords" id="keywords" type="text" maxlength="128" title="Search for keywords" class="inputbox search" value="Search…" onclick="if(this.value=='Search…')this.value='';" onblur="if(this.value=='')this.value='Search…';" />
					<input class="button2" value="Search" type="submit" /><br />
					<a href="search.html" title="View the advanced search options">Advanced search</a> 
				</fieldset>
				</form>
			</div>
		

			<span class="corners-bottom"><span></span></span></div>
		</div>

		<div class="navbar">
			<div class="inner"><span class="corners-top"><span></span></span>

			<ul class="linklist navlinks">
				<li class="icon-home"><a href="index.html" accesskey="h">Board index</a>  <strong>&#8249;</strong> <a href="viewforumfdc5.html?f=9">Discussion Groups</a> <strong>&#8249;</strong> <a href="viewforume774.html?f=5">General Discussion</a></li>

				<li class="rightside"><a href="#" onclick="fontsizeup(); return false;" onkeypress="return fontsizeup(event);" class="fontsize" title="Change font size">Change font size</a></li>

				<li class="rightside"><a href="viewtopica700.html?f=5&amp;t=713&amp;view=print" title="Print view" accesskey="p" class="print">Print view</a></li>
			</ul>

			

			<ul class="linklist rightside">
				<li class="icon-faq"><a href="faq.html" title="Frequently Asked Questions">FAQ</a></li>
				
					<li class="icon-logout"><a href="ucp26c3.php?mode=login" title="Login" accesskey="x">Login</a></li>
				
			</ul>

			<span class="corners-bottom"><span></span></span></div>
		</div>

	</div>

	<a name="start_here"></a>
	<div id="page-body">
		
<h2><a href="viewtopic48d0.html?f=5&amp;t=713">Clubhouse waiting list</a></h2>
<!-- NOTE: remove the style="display: none" when you want to have the forum description on the topic body --><div style="display: none !important;">Talk about Hang Gliding at Ft Funston and the Fellow Feathers Club.<br /></div>

<div class="topic-actions">

	<div class="buttons">
	
		<div class="reply-icon"><a href="postingc803.html?mode=reply&amp;f=5&amp;t=713" title="Post a reply"><span></span>Post a reply</a></div>
	
	</div>

	
		<div class="search-box">
			<form method="get" id="topic-search" action="http://flyfunston.org/bbs/search.php">
			<fieldset>
				<input class="inputbox search tiny"  type="text" name="keywords" id="search_keywords" size="20" value="Search this topic…" onclick="if(this.value=='Search this topic…')this.value='';" onblur="if(this.value=='')this.value='Search this topic…';" />
				<input class="button2" type="submit" value="Search" />
				<input type="hidden" name="t" value="713" />
<input type="hidden" name="sf" value="msgonly" />

			</fieldset>
			</form>
		</div>
	
		<div class="pagination">
			31 posts
			 &bull; <a href="#" onclick="jumpto(); return false;" title="Click to jump to page…">Page <strong>1</strong> of <strong>2</strong></a> &bull; <span><strong>1</strong><span class="page-sep">, </span><a href="viewtopicae9a.html?f=5&amp;t=713&amp;start=25">2</a></span>
		</div>
	

</div>
<div class="clear"></div>


	<div id="p1388" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting46f1.html?mode=quote&amp;f=5&amp;p=1388" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 class="first"><a href="#p1388">Clubhouse waiting list</a></h3>
			<p class="author"><a href="viewtopice129.html?p=1388#p1388"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlistc6bf.html?mode=viewprofile&amp;u=13">charlie nelson</a></strong> &raquo; Tue Jan 27, 2009 11:19 pm </p>

			

			<div class="content">In the interest of transparency, we are posting the clubhouse waiting list here on the discussion board.<br /><br />Active member pilots  who presently fly more than  20 hours  per year at the Fort may request a space.<br /><br />Spaces are allocated on a first come first served basis from the date the pilot was put on the waiting list. USHPA numbers are used for confidentiality.<br /><br />For further info please contact 2009 Clubhouse Manager Charlie Nelson via the email button below.<br /><br /># 81375 Date 05-13-2008 <br /># 83463 Date 05-31-2008</div>

			
				<div class="notice">Last edited by <a href="memberlistc6bf.html?mode=viewprofile&amp;u=13">charlie nelson</a> on Mon Apr 27, 2009 9:14 pm, edited 2 times in total.
					
				</div>
			

		</div>

		
			<dl class="postprofile" id="profile1388">
			<dt>
				<a href="memberlistc6bf.html?mode=viewprofile&amp;u=13"><img src="http://images.yuku.com/image/gif/b4836b1510a1318049a0a9e68005ce3b7f128ab1_t.gif" width="80" height="80" alt="User avatar" /></a><br />
				<a href="memberlistc6bf.html?mode=viewprofile&amp;u=13">charlie nelson</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 116</dd><dd><strong>Joined:</strong> Tue May 18, 2004 5:18 pm</dd><dd><strong>Location:</strong> redwood city</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p1389" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postinge38d.html?mode=quote&amp;f=5&amp;p=1389" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p1389"></a></h3>
			<p class="author"><a href="viewtopic5874.html?p=1389#p1389"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist2501.html?mode=viewprofile&amp;u=41">diev</a></strong> &raquo; Thu Jan 29, 2009 6:03 pm </p>

			

			<div class="content">&gt;2009 Clubhouse Manager Charlie Nelson at the email below ..... 
<br />
<br />???
<br />d</div>

			<div id="sig1389" class="signature">Diev Hart<br />KG6UST<br /><!-- m --><a class="postlink" href="http://www.dievhart.com/hangglide.html">http://www.dievhart.com/hangglide.html</a><!-- m --></div>

		</div>

		
			<dl class="postprofile" id="profile1389">
			<dt>
				<a href="memberlist2501.html?mode=viewprofile&amp;u=41">diev</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 253</dd><dd><strong>Joined:</strong> Tue Sep 28, 2004 1:40 pm</dd><dd><strong>Location:</strong> Santa Cruz, CA</dd>
			<dd>
				<ul class="profile-icons">
					<li class="web-icon"><a href="http://www.dievhart.com/hangglide.html" title="WWW: http://www.dievhart.com/hangglide.html"><span>Website</span></a></li><li class="yahoo-icon"><a href="http://edit.yahoo.com/config/send_webmesg?.target=dievhart&amp;.src=pg" onclick="popup(this.href, 780, 550); return false;" title="YIM"><span>YIM</span></a></li>
				</ul>
			</dd>
		

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p1391" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting185a.html?mode=quote&amp;f=5&amp;p=1391" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p1391"></a></h3>
			<p class="author"><a href="viewtopica448.html?p=1391#p1391"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlistc6bf.html?mode=viewprofile&amp;u=13">charlie nelson</a></strong> &raquo; Fri Jan 30, 2009 12:47 am </p>

			

			<div class="content">'2009 Clubhouse Manager Charlie Nelson at the email below ..... '
<br />means,
<br /> the row of  icons  along the  bottom of  each  message.
<br /> I hope your PC shows them, Diev.
<br />
<br />profile,  pm  , email
<br />
<br />Charlie
<br />ps  Diev showed us how, by flying til  dusk last Saturday . The  ranger seemed in a hurry to get everyone out  and quite a few dog  walkers were lingering after dark too.  It was a great day at the Fort .</div>

			<div id="sig1391" class="signature">email me at 'chahlieandkathy at  yahoo dotto  com'</div>

		</div>

		
			<dl class="postprofile" id="profile1391">
			<dt>
				<a href="memberlistc6bf.html?mode=viewprofile&amp;u=13"><img src="http://images.yuku.com/image/gif/b4836b1510a1318049a0a9e68005ce3b7f128ab1_t.gif" width="80" height="80" alt="User avatar" /></a><br />
				<a href="memberlistc6bf.html?mode=viewprofile&amp;u=13">charlie nelson</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 116</dd><dd><strong>Joined:</strong> Tue May 18, 2004 5:18 pm</dd><dd><strong>Location:</strong> redwood city</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p1392" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting3f67.php?mode=quote&amp;f=5&amp;p=1392" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p1392"></a></h3>
			<p class="author"><a href="viewtopicd486.html?p=1392#p1392"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist2501.html?mode=viewprofile&amp;u=41">diev</a></strong> &raquo; Fri Jan 30, 2009 1:01 am </p>

			

			<div class="content">hellooooo....I'm awake now.....it was a long day ok...
<br />d</div>

			<div id="sig1392" class="signature">Diev Hart<br />KG6UST<br /><!-- m --><a class="postlink" href="http://www.dievhart.com/hangglide.html">http://www.dievhart.com/hangglide.html</a><!-- m --></div>

		</div>

		
			<dl class="postprofile" id="profile1392">
			<dt>
				<a href="memberlist2501.html?mode=viewprofile&amp;u=41">diev</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 253</dd><dd><strong>Joined:</strong> Tue Sep 28, 2004 1:40 pm</dd><dd><strong>Location:</strong> Santa Cruz, CA</dd>
			<dd>
				<ul class="profile-icons">
					<li class="web-icon"><a href="http://www.dievhart.com/hangglide.html" title="WWW: http://www.dievhart.com/hangglide.html"><span>Website</span></a></li><li class="yahoo-icon"><a href="http://edit.yahoo.com/config/send_webmesg?.target=dievhart&amp;.src=pg" onclick="popup(this.href, 780, 550); return false;" title="YIM"><span>YIM</span></a></li>
				</ul>
			</dd>
		

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p1495" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postingf5c7.html?mode=quote&amp;f=5&amp;p=1495" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p1495">sleepy pilots</a></h3>
			<p class="author"><a href="viewtopic1df0.php?p=1495#p1495"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlistc6bf.html?mode=viewprofile&amp;u=13">charlie nelson</a></strong> &raquo; Wed Apr 15, 2009 11:25 pm </p>

			

			<div class="content">The  following pilots  haven't  paid for their space or their   locker in the  clubhouse for 2009.
<br />(and don't have a sticker  either).  the  flying season is here (once these  50 mph  / offshore winds  knock off)
<br /> <img src="images/smilies/icon_rolleyes.gif" alt=":roll:" title="Rolling Eyes" />  <img src="images/smilies/icon_rolleyes.gif" alt=":roll:" title="Rolling Eyes" />  <img src="images/smilies/icon_rolleyes.gif" alt=":roll:" title="Rolling Eyes" />  <img src="images/smilies/icon_rolleyes.gif" alt=":roll:" title="Rolling Eyes" /> 
<br />
<br /> If you see your USHGA number below you are at risk of  losing your  clubhouse space to  someone on the  waiting  list.   
<br />
<br />15917	   
<br />18254	   
<br />24735	   
<br />37030	   
<br />41152	   
<br />43647	   
<br />49075	   
<br />57168	   
<br />66522	   
<br />73823	   
<br />   
<br />75522	   
<br />76486	   
<br />79504	   
<br />84084</div>

			
				<div class="notice">Last edited by <a href="memberlistc6bf.html?mode=viewprofile&amp;u=13">charlie nelson</a> on Sun May 17, 2009 3:28 pm, edited 2 times in total.
					
				</div>
			

		</div>

		
			<dl class="postprofile" id="profile1495">
			<dt>
				<a href="memberlistc6bf.html?mode=viewprofile&amp;u=13"><img src="http://images.yuku.com/image/gif/b4836b1510a1318049a0a9e68005ce3b7f128ab1_t.gif" width="80" height="80" alt="User avatar" /></a><br />
				<a href="memberlistc6bf.html?mode=viewprofile&amp;u=13">charlie nelson</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 116</dd><dd><strong>Joined:</strong> Tue May 18, 2004 5:18 pm</dd><dd><strong>Location:</strong> redwood city</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p1507" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting4a5e.html?mode=quote&amp;f=5&amp;p=1507" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p1507"></a></h3>
			<p class="author"><a href="viewtopic39a7.html?p=1507#p1507"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlistc6bf.html?mode=viewprofile&amp;u=13">charlie nelson</a></strong> &raquo; Sun Apr 26, 2009 12:07 pm </p>

			

			<div class="content">in the interest of transparency, we are posting the clubhouse waiting list here on the discussion board.
<br />
<br />Active member pilots who presently fly more than 20 hours per year at the Fort may request a space.
<br />
<br />Spaces are allocated on a first come first served basis from the date the pilot was put on the waiting list. USHPA numbers are used for confidentiality.
<br />
<br />For further info please contact 2009 Clubhouse Manager Charlie Nelson via the email button below.
<br />
<br /># 81375 Date 05-13-2008
<br /># 83463 Date 05-31-2008
<br />
<br /># 85824 Date 04-24-2009</div>

			<div id="sig1507" class="signature">email me at 'chahlieandkathy at  yahoo dotto  com'</div>

		</div>

		
			<dl class="postprofile" id="profile1507">
			<dt>
				<a href="memberlistc6bf.html?mode=viewprofile&amp;u=13"><img src="http://images.yuku.com/image/gif/b4836b1510a1318049a0a9e68005ce3b7f128ab1_t.gif" width="80" height="80" alt="User avatar" /></a><br />
				<a href="memberlistc6bf.html?mode=viewprofile&amp;u=13">charlie nelson</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 116</dd><dd><strong>Joined:</strong> Tue May 18, 2004 5:18 pm</dd><dd><strong>Location:</strong> redwood city</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p1604" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting02a1.html?mode=quote&amp;f=5&amp;p=1604" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p1604">Waiting list update</a></h3>
			<p class="author"><a href="viewtopic6041.html?p=1604#p1604"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberliste69f.html?mode=viewprofile&amp;u=15" style="color: #AA0000;" class="username-coloured">Steve Rodrigues</a></strong> &raquo; Sat Jun 20, 2009 10:52 am </p>

			

			<div class="content">in the interest of transparency, we are posting the clubhouse waiting list here on the discussion board.
<br />
<br />Active member pilots who presently fly more than 20 hours per year at the Fort may request a space.
<br />
<br />Spaces are allocated on a first come first served basis from the date the pilot was put on the waiting list. USHPA numbers are used for confidentiality.
<br />
<br />For further info please contact 2009 Clubhouse Manager Charlie Nelson via the email button in one of his post's.
<br />
<br /># 81375 Date 05-13-2008
<br /># 38593 Date 03-01-2009</div>

			

		</div>

		
			<dl class="postprofile" id="profile1604">
			<dt>
				<a href="memberliste69f.html?mode=viewprofile&amp;u=15"><img src="download/file9b05.php?avatar=15_1575056796.jpg" width="200" height="149" alt="User avatar" /></a><br />
				<a href="memberliste69f.html?mode=viewprofile&amp;u=15" style="color: #AA0000;" class="username-coloured">Steve Rodrigues</a>
			</dt>

			<dd>Site Admin</dd>

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 723</dd><dd><strong>Joined:</strong> Mon May 24, 2004 10:57 pm</dd><dd><strong>Location:</strong> Brisbane, California</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p1631" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting128f.php?mode=quote&amp;f=5&amp;p=1631" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p1631">Falcon 195 for Advanced pilot to use for a few flights</a></h3>
			<p class="author"><a href="viewtopic57d5.php?p=1631#p1631"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist036d.html?mode=viewprofile&amp;u=1590">john@glidehome.com</a></strong> &raquo; Tue Jul 14, 2009 8:26 am </p>

			

			<div class="content">I am looking for a Falcon 195 to borrow to get a few hours at the Fort while waiting for a slot in the club house for my HPAT158.  I will be shipping my glider out once there is a spot and would love to get some time on a 195 while waiting.  Please contact me if you have one and want to work something out.  Thanks, 
<br />John Maloney
<br /><!-- e --><a href="mailto:john@glidehome.com">john@glidehome.com</a><!-- e --></div>

			<div id="sig1631" class="signature">John</div>

		</div>

		
			<dl class="postprofile" id="profile1631">
			<dt>
				<a href="memberlist036d.html?mode=viewprofile&amp;u=1590">john@glidehome.com</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 12</dd><dd><strong>Joined:</strong> Fri Jul 03, 2009 8:37 am</dd><dd><strong>Location:</strong> Charlotte, NC</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p1648" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting3292.php?mode=quote&amp;f=5&amp;p=1648" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p1648">latest list</a></h3>
			<p class="author"><a href="viewtopicd21a.html?p=1648#p1648"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlistc6bf.html?mode=viewprofile&amp;u=13">charlie nelson</a></strong> &raquo; Sun Jul 26, 2009 12:07 pm </p>

			

			<div class="content">in the interest of transparency, we are posting the clubhouse waiting list here on the discussion board.
<br />
<br />Active member pilots who presently fly more than 20 hours per year at the Fort may request a space.
<br />
<br />Spaces are allocated on a first come first served basis from the date the pilot was put on the waiting list. USHPA numbers are used for confidentiality.
<br />
<br />For further info please contact 2009 Clubhouse Manager me,Charlie Nelson, via the email button in one of my posts.
<br />
<br /># 81375 Date 05-13-2008
<br /># 38593 Date 03-01-2009</div>

			
				<div class="notice">Last edited by <a href="memberlistc6bf.html?mode=viewprofile&amp;u=13">charlie nelson</a> on Tue Sep 22, 2009 7:03 pm, edited 1 time in total.
					
				</div>
			<div id="sig1648" class="signature">email me at 'chahlieandkathy at  yahoo dotto  com'</div>

		</div>

		
			<dl class="postprofile" id="profile1648">
			<dt>
				<a href="memberlistc6bf.html?mode=viewprofile&amp;u=13"><img src="http://images.yuku.com/image/gif/b4836b1510a1318049a0a9e68005ce3b7f128ab1_t.gif" width="80" height="80" alt="User avatar" /></a><br />
				<a href="memberlistc6bf.html?mode=viewprofile&amp;u=13">charlie nelson</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 116</dd><dd><strong>Joined:</strong> Tue May 18, 2004 5:18 pm</dd><dd><strong>Location:</strong> redwood city</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p1663" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting00c1.html?mode=quote&amp;f=5&amp;p=1663" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p1663"></a></h3>
			<p class="author"><a href="viewtopic7b62.html?p=1663#p1663"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist036d.html?mode=viewprofile&amp;u=1590">john@glidehome.com</a></strong> &raquo; Thu Aug 06, 2009 5:23 pm </p>

			

			<div class="content">Thanks to Larry 6 hours down and 14 to go to get on the list.  Nothing like 30 landings in 3 days to start to feel current again.</div>

			<div id="sig1663" class="signature">John</div>

		</div>

		
			<dl class="postprofile" id="profile1663">
			<dt>
				<a href="memberlist036d.html?mode=viewprofile&amp;u=1590">john@glidehome.com</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 12</dd><dd><strong>Joined:</strong> Fri Jul 03, 2009 8:37 am</dd><dd><strong>Location:</strong> Charlotte, NC</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p1757" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postinga739.php?mode=quote&amp;f=5&amp;p=1757" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p1757"></a></h3>
			<p class="author"><a href="viewtopicdbcb.html?p=1757#p1757"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlistc6bf.html?mode=viewprofile&amp;u=13">charlie nelson</a></strong> &raquo; Tue Sep 22, 2009 7:00 pm </p>

			

			<div class="content">in the interest of transparency, we are posting the clubhouse waiting list here on the discussion board.
<br />
<br />Active member pilots who presently fly more than 20 hours per year at the Fort may request a space.
<br />
<br />Spaces are allocated on a first come first served basis from the date the pilot was put on the waiting list. USHPA numbers are used for confidentiality.
<br />
<br />For further info please contact 2009 Clubhouse Manager me,Charlie Nelson, via the email button in one of my posts.
<br />
<br /># 81375 Date 05-13-2008
<br /># 38593 Date 03-01-2009
<br /># 85669 Date 08-29-2009
<br /># 33432 Date 09-17-2009
<br />_________________
<br />and don't you eat that yellow snow</div>

			

		</div>

		
			<dl class="postprofile" id="profile1757">
			<dt>
				<a href="memberlistc6bf.html?mode=viewprofile&amp;u=13"><img src="http://images.yuku.com/image/gif/b4836b1510a1318049a0a9e68005ce3b7f128ab1_t.gif" width="80" height="80" alt="User avatar" /></a><br />
				<a href="memberlistc6bf.html?mode=viewprofile&amp;u=13">charlie nelson</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 116</dd><dd><strong>Joined:</strong> Tue May 18, 2004 5:18 pm</dd><dd><strong>Location:</strong> redwood city</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p1871" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postingf749.html?mode=quote&amp;f=5&amp;p=1871" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p1871"></a></h3>
			<p class="author"><a href="viewtopic48f6.php?p=1871#p1871"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlistc6bf.html?mode=viewprofile&amp;u=13">charlie nelson</a></strong> &raquo; Sat Nov 14, 2009 10:21 pm </p>

			

			<div class="content">in the interest of transparency, we are posting the clubhouse waiting list here on the discussion board.
<br />
<br />Active member pilots who presently fly more than 20 hours per year at the Fort may request a space.
<br />
<br />Spaces are allocated on a first come first served basis from the date the pilot was put on the waiting list. USHPA numbers are used for confidentiality.
<br />
<br />For further info please contact 2009 Clubhouse Manager me,Charlie Nelson, via the email button in one of my posts.
<br />
<br />USHPA NO.  date of request
<br />
<br />
<br /># 83372 Date 08-10-2009
<br /># 85669 Date 08-29-2009
<br /># 85588 Date 10-28-2009</div>

			
				<div class="notice">Last edited by <a href="memberlistc6bf.html?mode=viewprofile&amp;u=13">charlie nelson</a> on Sun Aug 01, 2010 1:02 am, edited 1 time in total.
					
				</div>
			

		</div>

		
			<dl class="postprofile" id="profile1871">
			<dt>
				<a href="memberlistc6bf.html?mode=viewprofile&amp;u=13"><img src="http://images.yuku.com/image/gif/b4836b1510a1318049a0a9e68005ce3b7f128ab1_t.gif" width="80" height="80" alt="User avatar" /></a><br />
				<a href="memberlistc6bf.html?mode=viewprofile&amp;u=13">charlie nelson</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 116</dd><dd><strong>Joined:</strong> Tue May 18, 2004 5:18 pm</dd><dd><strong>Location:</strong> redwood city</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2026" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postingfe40.html?mode=quote&amp;f=5&amp;p=2026" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2026">Nose bleeder</a></h3>
			<p class="author"><a href="viewtopic5b4f.html?p=2026#p2026"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist36d3.html?mode=viewprofile&amp;u=1514">vanpelham</a></strong> &raquo; Thu Apr 01, 2010 4:16 pm </p>

			

			<div class="content">I'd like to be put on the list for another glider spot.  I plan to share my sport 2 as a community glider.  Uspha number 85943,  thanks</div>

			<div id="sig2026" class="signature">fly safe..thx..Van</div>

		</div>

		
			<dl class="postprofile" id="profile2026">
			<dt>
				<a href="memberlist36d3.html?mode=viewprofile&amp;u=1514">vanpelham</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 9</dd><dd><strong>Joined:</strong> Tue Nov 25, 2008 7:47 pm</dd><dd><strong>Location:</strong> SF</dd>
			<dd>
				<ul class="profile-icons">
					<li class="web-icon"><a href="http://redfigurefilms.com/" title="WWW: http://redfigurefilms.com"><span>Website</span></a></li>
				</ul>
			</dd>
		

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2030" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting7905.html?mode=quote&amp;f=5&amp;p=2030" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2030">inner  space is  limtied</a></h3>
			<p class="author"><a href="viewtopicb776.php?p=2030#p2030"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlistc6bf.html?mode=viewprofile&amp;u=13">charlie nelson</a></strong> &raquo; Sun Apr 04, 2010 9:08 pm </p>

			

			<div class="content">sorry to  report that Club  rules  only  allow a single space  per pilot.</div>

			

		</div>

		
			<dl class="postprofile" id="profile2030">
			<dt>
				<a href="memberlistc6bf.html?mode=viewprofile&amp;u=13"><img src="http://images.yuku.com/image/gif/b4836b1510a1318049a0a9e68005ce3b7f128ab1_t.gif" width="80" height="80" alt="User avatar" /></a><br />
				<a href="memberlistc6bf.html?mode=viewprofile&amp;u=13">charlie nelson</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 116</dd><dd><strong>Joined:</strong> Tue May 18, 2004 5:18 pm</dd><dd><strong>Location:</strong> redwood city</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2151" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting9c15.html?mode=quote&amp;f=5&amp;p=2151" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2151">spaces available</a></h3>
			<p class="author"><a href="viewtopicc757.php?p=2151#p2151"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlistc6bf.html?mode=viewprofile&amp;u=13">charlie nelson</a></strong> &raquo; Fri Jun 25, 2010 11:45 am </p>

			

			<div class="content">space is available , subject to Club rules
<br />charlie    jaggie3  at  hotmail dot  com</div>

			

		</div>

		
			<dl class="postprofile" id="profile2151">
			<dt>
				<a href="memberlistc6bf.html?mode=viewprofile&amp;u=13"><img src="http://images.yuku.com/image/gif/b4836b1510a1318049a0a9e68005ce3b7f128ab1_t.gif" width="80" height="80" alt="User avatar" /></a><br />
				<a href="memberlistc6bf.html?mode=viewprofile&amp;u=13">charlie nelson</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 116</dd><dd><strong>Joined:</strong> Tue May 18, 2004 5:18 pm</dd><dd><strong>Location:</strong> redwood city</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2176" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postingf154.html?mode=quote&amp;f=5&amp;p=2176" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2176">posted list of  glider space  renters</a></h3>
			<p class="author"><a href="viewtopic1d86.html?p=2176#p2176"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlistc6bf.html?mode=viewprofile&amp;u=13">charlie nelson</a></strong> &raquo; Thu Jul 29, 2010 1:28 am </p>

			

			<div class="content">on the southwest. IE  photo wall   of the  Clubhouse , inside , is a  list  showing the respective spaces and their renters hanging on a string
<br />&quot;watch out  where  the pit bulls go , 
<br />and  don't  you eat that  yellow  wood  chip snow&quot;</div>

			
				<div class="notice">Last edited by <a href="memberlistc6bf.html?mode=viewprofile&amp;u=13">charlie nelson</a> on Wed Aug 04, 2010 5:06 pm, edited 1 time in total.
					
				</div>
			<div id="sig2176" class="signature">email me at 'chahlieandkathy at  yahoo dotto  com'</div>

		</div>

		
			<dl class="postprofile" id="profile2176">
			<dt>
				<a href="memberlistc6bf.html?mode=viewprofile&amp;u=13"><img src="http://images.yuku.com/image/gif/b4836b1510a1318049a0a9e68005ce3b7f128ab1_t.gif" width="80" height="80" alt="User avatar" /></a><br />
				<a href="memberlistc6bf.html?mode=viewprofile&amp;u=13">charlie nelson</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 116</dd><dd><strong>Joined:</strong> Tue May 18, 2004 5:18 pm</dd><dd><strong>Location:</strong> redwood city</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2185" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting02be.html?mode=quote&amp;f=5&amp;p=2185" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2185">clubhouse logbook</a></h3>
			<p class="author"><a href="viewtopicd1a6.html?p=2185#p2185"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist5cee.html?mode=viewprofile&amp;u=154">cliffblack</a></strong> &raquo; Sat Jul 31, 2010 2:53 pm </p>

			

			<div class="content">Charlie, the log book in the clubhouse is from 2009.   ahhh huh huh</div>

			<div id="sig2185" class="signature">Tom</div>

		</div>

		
			<dl class="postprofile" id="profile2185">
			<dt>
				<a href="memberlist5cee.html?mode=viewprofile&amp;u=154">cliffblack</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 103</dd><dd><strong>Joined:</strong> Mon May 30, 2005 11:54 am</dd><dd><strong>Location:</strong> palo alto</dd>
			<dd>
				<ul class="profile-icons">
					<li class="web-icon"><a href="http://www.cliffblack.com/" title="WWW: http://www.cliffblack.com"><span>Website</span></a></li>
				</ul>
			</dd>
		

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2193" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postingea4f.html?mode=quote&amp;f=5&amp;p=2193" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2193">log book</a></h3>
			<p class="author"><a href="viewtopicf23b.php?p=2193#p2193"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlistc6bf.html?mode=viewprofile&amp;u=13">charlie nelson</a></strong> &raquo; Wed Aug 04, 2010 5:09 pm </p>

			

			<div class="content">Tom , the Club  did not  choose to  place a new log book in the Clubhouse  this  year.  and the  2009  book has  been  removed.  does  anyone here know  who took that  book?</div>

			<div id="sig2193" class="signature">email me at 'chahlieandkathy at  yahoo dotto  com'</div>

		</div>

		
			<dl class="postprofile" id="profile2193">
			<dt>
				<a href="memberlistc6bf.html?mode=viewprofile&amp;u=13"><img src="http://images.yuku.com/image/gif/b4836b1510a1318049a0a9e68005ce3b7f128ab1_t.gif" width="80" height="80" alt="User avatar" /></a><br />
				<a href="memberlistc6bf.html?mode=viewprofile&amp;u=13">charlie nelson</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 116</dd><dd><strong>Joined:</strong> Tue May 18, 2004 5:18 pm</dd><dd><strong>Location:</strong> redwood city</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2319" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postingeda8.html?mode=quote&amp;f=5&amp;p=2319" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2319">Re: Clubhouse waiting list</a></h3>
			<p class="author"><a href="viewtopic2fc6.html?p=2319#p2319"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlistc6bf.html?mode=viewprofile&amp;u=13">charlie nelson</a></strong> &raquo; Wed Dec 01, 2010 12:47 am </p>

			

			<div class="content"># 83372 Date 08-10-2009<br /># 85669 Date 08-29-2009<br /># 84667 Date 06-07-2010<br /># 84775 Date  11-09-2010<br />#84164 Date 01-11-2011</div>

			<div id="sig2319" class="signature">email me at 'chahlieandkathy at  yahoo dotto  com'</div>

		</div>

		
			<dl class="postprofile" id="profile2319">
			<dt>
				<a href="memberlistc6bf.html?mode=viewprofile&amp;u=13"><img src="http://images.yuku.com/image/gif/b4836b1510a1318049a0a9e68005ce3b7f128ab1_t.gif" width="80" height="80" alt="User avatar" /></a><br />
				<a href="memberlistc6bf.html?mode=viewprofile&amp;u=13">charlie nelson</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 116</dd><dd><strong>Joined:</strong> Tue May 18, 2004 5:18 pm</dd><dd><strong>Location:</strong> redwood city</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2672" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postinge70f.php?mode=quote&amp;f=5&amp;p=2672" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2672">Re: Clubhouse waiting list</a></h3>
			<p class="author"><a href="viewtopic02c7.php?p=2672#p2672"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist5346.html?mode=viewprofile&amp;u=1948">Jose</a></strong> &raquo; Sat Apr 30, 2011 1:26 pm </p>

			

			<div class="content"><blockquote class="uncited"><div># 83372 Date 08-10-2009<br /># 85669 Date 08-29-2009<br /># 84667 Date 06-07-2010<br /># 84775 Date 11-09-2010<br />#84164 Date 01-11-2011</div></blockquote><br /><br />This 19 month wait for a slot in the clubhouse is ridiculous.<br /><br />If anyone has a wing stored in the clubhouse which they don't fly I will store it at my place and pay your annual club dues for you in exchange for your slot for a couple months.  It will remain your slot, I just get the opportunity to use it and your wing will be safely stored indoors on a rack similar to the racks in the clubhouse.  I have a great opportunity to fly every day the winds are good for the next few months.  Being able to store my wing at the clubhouse will make this possible.  Let me know if anyone can help.  -Jose</div>

			

		</div>

		
			<dl class="postprofile" id="profile2672">
			<dt>
				<a href="memberlist5346.html?mode=viewprofile&amp;u=1948">Jose</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 29</dd><dd><strong>Joined:</strong> Tue Mar 29, 2011 9:53 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2673" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting2ac0.php?mode=quote&amp;f=5&amp;p=2673" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2673">Re: Clubhouse waiting list</a></h3>
			<p class="author"><a href="viewtopicf915.html?p=2673#p2673"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlistd0bb.php?mode=viewprofile&amp;u=1552">sporty155</a></strong> &raquo; Sat Apr 30, 2011 6:32 pm </p>

			

			<div class="content">I have a new design for a cool rack system that will almost double the amount of gliders we store, and make long term storage much more user friendly...<br /><br />5 racks,  $350.00 or so material for each one...... <br /><br />Tell me this sounds good and I will draw something up......<br /><br />Rob</div>

			

		</div>

		
			<dl class="postprofile" id="profile2673">
			<dt>
				<a href="memberlistd0bb.php?mode=viewprofile&amp;u=1552">sporty155</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 127</dd><dd><strong>Joined:</strong> Sat Feb 28, 2009 2:04 am</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2674" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting1cf8.html?mode=quote&amp;f=5&amp;p=2674" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2674">Re: Clubhouse waiting list</a></h3>
			<p class="author"><a href="viewtopic8191.html?p=2674#p2674"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist5346.html?mode=viewprofile&amp;u=1948">Jose</a></strong> &raquo; Sat Apr 30, 2011 7:18 pm </p>

			

			<div class="content">It sounds good Rob, draw up your plans &amp; bring them to the next club meeting, I believe it's the second Tuesday of the month, making the next meeting Tuesday, May 10th.  I'll try to figure out a way to get the money.</div>

			

		</div>

		
			<dl class="postprofile" id="profile2674">
			<dt>
				<a href="memberlist5346.html?mode=viewprofile&amp;u=1948">Jose</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 29</dd><dd><strong>Joined:</strong> Tue Mar 29, 2011 9:53 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2676" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting84c7.php?mode=quote&amp;f=5&amp;p=2676" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2676">Re: Clubhouse waiting list</a></h3>
			<p class="author"><a href="viewtopicc5c7.html?p=2676#p2676"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlistd3cc.html?mode=viewprofile&amp;u=1478">fakeDecoy</a></strong> &raquo; Sat Apr 30, 2011 8:14 pm </p>

			

			<div class="content">Check with Charlie about the waiting list. I don't know all the facts, but I think the wait is actually quite short, even though there are 2009 dates on there. It's just a matter of pushing out the retired pilots one by one as the need arises. A year ago I got my spot in a month.<br /><br />Dave</div>

			

		</div>

		
			<dl class="postprofile" id="profile2676">
			<dt>
				<a href="memberlistd3cc.html?mode=viewprofile&amp;u=1478">fakeDecoy</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 140</dd><dd><strong>Joined:</strong> Thu Jul 24, 2008 8:22 am</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2677" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postingbf3f.html?mode=quote&amp;f=5&amp;p=2677" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2677">Re: Clubhouse waiting list</a></h3>
			<p class="author"><a href="viewtopicbee1.php?p=2677#p2677"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist5346.html?mode=viewprofile&amp;u=1948">Jose</a></strong> &raquo; Sat Apr 30, 2011 8:25 pm </p>

			

			<div class="content">I've been bugging Charlie monthly, he's doing a great job getting those who don't fly out of there but it is still looking like a long wait. There's gotta be a better solution.</div>

			

		</div>

		
			<dl class="postprofile" id="profile2677">
			<dt>
				<a href="memberlist5346.html?mode=viewprofile&amp;u=1948">Jose</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 29</dd><dd><strong>Joined:</strong> Tue Mar 29, 2011 9:53 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2679" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postingf68b.html?mode=quote&amp;f=5&amp;p=2679" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2679">Re: Clubhouse waiting list</a></h3>
			<p class="author"><a href="viewtopic7667.html?p=2679#p2679"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlistd0bb.php?mode=viewprofile&amp;u=1552">sporty155</a></strong> &raquo; Thu May 05, 2011 12:03 am </p>

			

			<div class="content">How many gliders do we have in the clubhouse???</div>

			

		</div>

		
			<dl class="postprofile" id="profile2679">
			<dt>
				<a href="memberlistd0bb.php?mode=viewprofile&amp;u=1552">sporty155</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 127</dd><dd><strong>Joined:</strong> Sat Feb 28, 2009 2:04 am</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<form id="viewtopic" method="post" action="http://flyfunston.org/bbs/viewtopic.php?f=5&amp;t=713">

	<fieldset class="display-options" style="margin-top: 0; ">
		<a href="viewtopicae9a.html?f=5&amp;t=713&amp;start=25" class="right-box right">Next</a>
		<label>Display posts from previous: <select name="st" id="st"><option value="0" selected="selected">All posts</option><option value="1">1 day</option><option value="7">7 days</option><option value="14">2 weeks</option><option value="30">1 month</option><option value="90">3 months</option><option value="180">6 months</option><option value="365">1 year</option></select></label>
		<label>Sort by <select name="sk" id="sk"><option value="a">Author</option><option value="t" selected="selected">Post time</option><option value="s">Subject</option></select></label> <label><select name="sd" id="sd"><option value="a" selected="selected">Ascending</option><option value="d">Descending</option></select> <input type="submit" name="sort" value="Go" class="button2" /></label>
		
	</fieldset>

	</form>
	<hr />


<div class="topic-actions">
	<div class="buttons">
	
		<div class="reply-icon"><a href="postingc803.html?mode=reply&amp;f=5&amp;t=713" title="Post a reply"><span></span>Post a reply</a></div>
	
	</div>

	
		<div class="pagination">
			31 posts
			 &bull; <a href="#" onclick="jumpto(); return false;" title="Click to jump to page…">Page <strong>1</strong> of <strong>2</strong></a> &bull; <span><strong>1</strong><span class="page-sep">, </span><a href="viewtopicae9a.html?f=5&amp;t=713&amp;start=25">2</a></span>
		</div>
	
</div>


	<p></p><p><a href="viewforume774.html?f=5" class="left-box left" accesskey="r">Return to General Discussion</a></p>

	<form method="post" id="jumpbox" action="http://flyfunston.org/bbs/viewforum.php" onsubmit="if(this.f.value == -1){return false;}">

	
		<fieldset class="jumpbox">
	
			<label for="f" accesskey="j">Jump to:</label>
			<select name="f" id="f" onchange="if(this.options[this.selectedIndex].value != -1){ document.forms['jumpbox'].submit() }">
			
				<option value="-1">Select a forum</option>
			<option value="-1">------------------</option>
				<option value="9">Discussion Groups</option>
			
				<option value="5" selected="selected">&nbsp; &nbsp;General Discussion</option>
			
				<option value="8">&nbsp; &nbsp;Announcements</option>
			
				<option value="7">&nbsp; &nbsp;For Sale/Wanted</option>
			
				<option value="6">&nbsp; &nbsp;Road Trips</option>
			
				<option value="2">&nbsp; &nbsp;Meeting Minutes and Treasurer Reports</option>
			
				<option value="11">&nbsp; &nbsp;Off Topic</option>
			
			</select>
			<input type="submit" value="Go" class="button2" />
		</fieldset>
	</form>


	<h3>Who is online</h3>
	<p>Users browsing this forum: No registered users and 5 guests</p>
</div>

<div id="page-footer">

	<div class="navbar">
		<div class="inner"><span class="corners-top"><span></span></span>

		<ul class="linklist">
			<li class="icon-home"><a href="index.html">Board index</a></li>
				
			<li class="rightside"><a href="memberlista2f5.html?mode=leaders">The team</a> &bull; <a href="ucp033a.html?mode=delete_cookies">Delete all board cookies</a> &bull; All times are UTC - 8 hours [ <abbr title="Daylight Saving Time">DST</abbr> ]</li>
		</ul>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<div class="copyright">Powered by <a href="https://www.phpbb.com/">phpBB</a>&reg; Forum Software &copy; phpBB Group
		
	</div>
</div>

</div>

<div>
	<a id="bottom" name="bottom" accesskey="z"></a>
	
</div>

</body>

<!-- Mirrored from flyfunston.org/bbs/viewtopic.php?p=2151 by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 08 Aug 2021 20:05:49 GMT -->
</html>