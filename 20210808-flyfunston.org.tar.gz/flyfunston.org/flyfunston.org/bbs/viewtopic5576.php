<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en-us" xml:lang="en-us">

<!-- Mirrored from flyfunston.org/bbs/viewtopic.php?p=4451 by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 08 Aug 2021 19:13:17 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>

<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<meta http-equiv="content-style-type" content="text/css" />
<meta http-equiv="content-language" content="en-us" />
<meta http-equiv="imagetoolbar" content="no" />
<meta name="resource-type" content="document" />
<meta name="distribution" content="global" />
<meta name="keywords" content="" />
<meta name="description" content="" />

<title>Flyfunston &bull; View topic - Dazes Long Ago :)</title>



<!--
	phpBB style name: prosilver
	Based on style:   prosilver (this is the default phpBB3 style)
	Original author:  Tom Beddard ( http://www.subBlue.com/ )
	Modified by:
-->

<script type="text/javascript">
// <![CDATA[
	var jump_page = 'Enter the page number you wish to go to:';
	var on_page = '1';
	var per_page = '';
	var base_url = '';
	var style_cookie = 'phpBBstyle';
	var style_cookie_settings = '; path=/; domain=flyfunston.org; secure';
	var onload_functions = new Array();
	var onunload_functions = new Array();

	

	/**
	* Find a member
	*/
	function find_username(url)
	{
		popup(url, 760, 570, '_usersearch');
		return false;
	}

	/**
	* New function for handling multiple calls to window.onload and window.unload by pentapenguin
	*/
	window.onload = function()
	{
		for (var i = 0; i < onload_functions.length; i++)
		{
			eval(onload_functions[i]);
		}
	};

	window.onunload = function()
	{
		for (var i = 0; i < onunload_functions.length; i++)
		{
			eval(onunload_functions[i]);
		}
	};

// ]]>
</script>
<script type="text/javascript" src="styles/prosilver/template/styleswitcher.js"></script>
<script type="text/javascript" src="styles/prosilver/template/forum_fn.js"></script>

<link href="styles/prosilver/theme/print.css" rel="stylesheet" type="text/css" media="print" title="printonly" />
<link href="style7a95.css?id=1&amp;lang=en_us" rel="stylesheet" type="text/css" media="screen, projection" />

<link href="styles/prosilver/theme/normal.css" rel="stylesheet" type="text/css" title="A" />
<link href="styles/prosilver/theme/medium.css" rel="alternate stylesheet" type="text/css" title="A+" />
<link href="styles/prosilver/theme/large.css" rel="alternate stylesheet" type="text/css" title="A++" />



</head>

<body id="phpbb" class="section-viewtopic ltr">

<div id="wrap">
	<a id="top" name="top" accesskey="t"></a>
	<div id="page-header">
		<div class="headerbar">
			<div class="inner"><span class="corners-top"><span></span></span>

			<div id="site-description">
				<a href="index.html" title="Board index" id="logo"><img src="styles/prosilver/imageset/site_logo.gif" width="149" height="52" alt="" title="" /></a>
				<h1>Flyfunston</h1>
				<p>Hang Gliding at Fort Funston</p>
				<p class="skiplink"><a href="#start_here">Skip to content</a></p>
			</div>

		
			<div id="search-box">
				<form action="http://flyfunston.org/bbs/search.php" method="get" id="search">
				<fieldset>
					<input name="keywords" id="keywords" type="text" maxlength="128" title="Search for keywords" class="inputbox search" value="Search…" onclick="if(this.value=='Search…')this.value='';" onblur="if(this.value=='')this.value='Search…';" />
					<input class="button2" value="Search" type="submit" /><br />
					<a href="search.html" title="View the advanced search options">Advanced search</a> 
				</fieldset>
				</form>
			</div>
		

			<span class="corners-bottom"><span></span></span></div>
		</div>

		<div class="navbar">
			<div class="inner"><span class="corners-top"><span></span></span>

			<ul class="linklist navlinks">
				<li class="icon-home"><a href="index.html" accesskey="h">Board index</a>  <strong>&#8249;</strong> <a href="viewforumfdc5.html?f=9">Discussion Groups</a> <strong>&#8249;</strong> <a href="viewforume774.html?f=5">General Discussion</a></li>

				<li class="rightside"><a href="#" onclick="fontsizeup(); return false;" onkeypress="return fontsizeup(event);" class="fontsize" title="Change font size">Change font size</a></li>

				<li class="rightside"><a href="viewtopic24f5.php?f=5&amp;t=1858&amp;view=print" title="Print view" accesskey="p" class="print">Print view</a></li>
			</ul>

			

			<ul class="linklist rightside">
				<li class="icon-faq"><a href="faq.html" title="Frequently Asked Questions">FAQ</a></li>
				
					<li class="icon-logout"><a href="ucp26c3.php?mode=login" title="Login" accesskey="x">Login</a></li>
				
			</ul>

			<span class="corners-bottom"><span></span></span></div>
		</div>

	</div>

	<a name="start_here"></a>
	<div id="page-body">
		
<h2><a href="viewtopic48bf.php?f=5&amp;t=1858">Dazes Long Ago :)</a></h2>
<!-- NOTE: remove the style="display: none" when you want to have the forum description on the topic body --><div style="display: none !important;">Talk about Hang Gliding at Ft Funston and the Fellow Feathers Club.<br /></div>

<div class="topic-actions">

	<div class="buttons">
	
		<div class="reply-icon"><a href="posting2baf.html?mode=reply&amp;f=5&amp;t=1858" title="Post a reply"><span></span>Post a reply</a></div>
	
	</div>

	
		<div class="search-box">
			<form method="get" id="topic-search" action="http://flyfunston.org/bbs/search.php">
			<fieldset>
				<input class="inputbox search tiny"  type="text" name="keywords" id="search_keywords" size="20" value="Search this topic…" onclick="if(this.value=='Search this topic…')this.value='';" onblur="if(this.value=='')this.value='Search this topic…';" />
				<input class="button2" type="submit" value="Search" />
				<input type="hidden" name="t" value="1858" />
<input type="hidden" name="sf" value="msgonly" />

			</fieldset>
			</form>
		</div>
	
		<div class="pagination">
			6 posts
			 &bull; Page <strong>1</strong> of <strong>1</strong>
		</div>
	

</div>
<div class="clear"></div>


	<div id="p4446" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting8c7d.html?mode=quote&amp;f=5&amp;p=4446" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 class="first"><a href="#p4446">Dazes Long Ago :)</a></h3>
			<p class="author"><a href="viewtopic56f1.html?p=4446#p4446"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlistc2d1.html?mode=viewprofile&amp;u=64">Big Bird</a></strong> &raquo; Thu Mar 08, 2018 3:26 pm </p>

			

			<div class="content">I'm converting some old 8mm film to digital.  This happens to be a screen capture from part of the footage at Funston ('74ish)...  If someone is interested in having all of the Funston footage from that time period I'd be happy to provide it.</div>

			
				<dl class="attachbox">
					<dt>Attachments</dt>
					
						<dd>
		<dl class="file">
			<dt class="attach-image"><img src="download/file39d7.jpg?id=145" alt="Funston.jpg" onclick="viewableArea(this);" /></dt>
			
			<dd>Funston.jpg (24.02 KiB) Viewed 11827 times</dd>
		</dl>
		</dd>
					
				</dl>
			

		</div>

		
			<dl class="postprofile" id="profile4446">
			<dt>
				<a href="memberlistc2d1.html?mode=viewprofile&amp;u=64">Big Bird</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 26</dd><dd><strong>Joined:</strong> Tue Oct 26, 2004 11:37 pm</dd>
			<dd>
				<ul class="profile-icons">
					<li class="web-icon"><a href="http://www.hatcreek.info/" title="WWW: http://www.hatcreek.info"><span>Website</span></a></li>
				</ul>
			</dd>
		

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p4447" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting878b.php?mode=quote&amp;f=5&amp;p=4447" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p4447">Re: Dazes Long Ago :)</a></h3>
			<p class="author"><a href="viewtopic6ae1.html?p=4447#p4447"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist7aa3.html?mode=viewprofile&amp;u=129">crvalley</a></strong> &raquo; Thu Mar 08, 2018 6:21 pm </p>

			

			<div class="content"><blockquote><div><cite>Big Bird wrote:</cite>If someone is interested in having all of the Funston footage from that time period I'd be happy to provide it.</div></blockquote><br /><br />That would be really cool!<br /><br />Is there a lot of footage or how much?<br /><br />Chris</div>

			<div id="sig4447" class="signature">“We abuse land because we see it as a commodity belonging to us. When we see land as a community to which we belong, we may begin to use it with love and respect.” ― Aldo Leopold</div>

		</div>

		
			<dl class="postprofile" id="profile4447">
			<dt>
				<a href="memberlist7aa3.html?mode=viewprofile&amp;u=129">crvalley</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 214</dd><dd><strong>Joined:</strong> Sun Apr 10, 2005 9:16 am</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p4448" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postingd628.php?mode=quote&amp;f=5&amp;p=4448" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p4448">Re: Dazes Long Ago :)</a></h3>
			<p class="author"><a href="viewtopic1eac-2.html?p=4448#p4448"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlistc2d1.html?mode=viewprofile&amp;u=64">Big Bird</a></strong> &raquo; Fri Mar 09, 2018 11:28 am </p>

			

			<div class="content">Hi Chris, <br />Right now I have maybe 10 minutes of Funston footage that I've converted to digital from 8mm film.  However, I have thousands of feet of old hang gliding film (see attached) that I'm just now beginning to review and convert to digital.  I'm guessing I might have another 30 minutes from Funston. <br /><br />Phil<br /><br /><div class="inline-attachment">
		<dl class="file">
			<dt class="attach-image"><img src="download/file0985.jpg?id=146" alt="8mmExtremeSm.jpg" onclick="viewableArea(this);" /></dt>
			
			<dd>8mmExtremeSm.jpg (42.92 KiB) Viewed 11810 times</dd>
		</dl>
		</div></div>

			

		</div>

		
			<dl class="postprofile" id="profile4448">
			<dt>
				<a href="memberlistc2d1.html?mode=viewprofile&amp;u=64">Big Bird</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 26</dd><dd><strong>Joined:</strong> Tue Oct 26, 2004 11:37 pm</dd>
			<dd>
				<ul class="profile-icons">
					<li class="web-icon"><a href="http://www.hatcreek.info/" title="WWW: http://www.hatcreek.info"><span>Website</span></a></li>
				</ul>
			</dd>
		

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p4449" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postingd28a.html?mode=quote&amp;f=5&amp;p=4449" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p4449">Re: Dazes Long Ago :)</a></h3>
			<p class="author"><a href="viewtopiccf66.html?p=4449#p4449"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist7aa3.html?mode=viewprofile&amp;u=129">crvalley</a></strong> &raquo; Sun Mar 11, 2018 12:40 pm </p>

			

			<div class="content">Phil,<br /><br />I think whatever footage you have of Funston HG from that era would be great.<br /><br />Stay in touch with us as you chug through all those reels.<br /><br />Thanks,<br /><br />Chris</div>

			<div id="sig4449" class="signature">“We abuse land because we see it as a commodity belonging to us. When we see land as a community to which we belong, we may begin to use it with love and respect.” ― Aldo Leopold</div>

		</div>

		
			<dl class="postprofile" id="profile4449">
			<dt>
				<a href="memberlist7aa3.html?mode=viewprofile&amp;u=129">crvalley</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 214</dd><dd><strong>Joined:</strong> Sun Apr 10, 2005 9:16 am</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p4451" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postingafcc.html?mode=quote&amp;f=5&amp;p=4451" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p4451">Re: Dazes Long Ago :)</a></h3>
			<p class="author"><a href="viewtopic5576.php?p=4451#p4451"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlistc2d1.html?mode=viewprofile&amp;u=64">Big Bird</a></strong> &raquo; Tue Mar 13, 2018 7:42 am </p>

			

			<div class="content">Will do, Chris.</div>

			

		</div>

		
			<dl class="postprofile" id="profile4451">
			<dt>
				<a href="memberlistc2d1.html?mode=viewprofile&amp;u=64">Big Bird</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 26</dd><dd><strong>Joined:</strong> Tue Oct 26, 2004 11:37 pm</dd>
			<dd>
				<ul class="profile-icons">
					<li class="web-icon"><a href="http://www.hatcreek.info/" title="WWW: http://www.hatcreek.info"><span>Website</span></a></li>
				</ul>
			</dd>
		

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p4454" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting83b7.html?mode=quote&amp;f=5&amp;p=4454" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p4454">Re: Dazes Long Ago :)</a></h3>
			<p class="author"><a href="viewtopic18ea.php?p=4454#p4454"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlistc2d1.html?mode=viewprofile&amp;u=64">Big Bird</a></strong> &raquo; Thu Mar 29, 2018 11:49 am </p>

			

			<div class="content">Here's the Funston footage I mentioned.  It's from '74ish and was converted from film to digital.  The film was jerky so I used Premiere Pro to try and correct that.  It did sort of, but being a new user of Premiere it's not as clean as I had hoped.  <br /><br />Here the link:  <!-- m --><a class="postlink" href="https://www.youtube.com/watch?v=gxs9bpyDzR4&amp;t=175s">https://www.youtube.com/watch?v=gxs9bpyDzR4&amp;t=175s</a><!-- m --></div>

			

		</div>

		
			<dl class="postprofile" id="profile4454">
			<dt>
				<a href="memberlistc2d1.html?mode=viewprofile&amp;u=64">Big Bird</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 26</dd><dd><strong>Joined:</strong> Tue Oct 26, 2004 11:37 pm</dd>
			<dd>
				<ul class="profile-icons">
					<li class="web-icon"><a href="http://www.hatcreek.info/" title="WWW: http://www.hatcreek.info"><span>Website</span></a></li>
				</ul>
			</dd>
		

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<form id="viewtopic" method="post" action="http://flyfunston.org/bbs/viewtopic.php?f=5&amp;t=1858">

	<fieldset class="display-options" style="margin-top: 0; ">
		
		<label>Display posts from previous: <select name="st" id="st"><option value="0" selected="selected">All posts</option><option value="1">1 day</option><option value="7">7 days</option><option value="14">2 weeks</option><option value="30">1 month</option><option value="90">3 months</option><option value="180">6 months</option><option value="365">1 year</option></select></label>
		<label>Sort by <select name="sk" id="sk"><option value="a">Author</option><option value="t" selected="selected">Post time</option><option value="s">Subject</option></select></label> <label><select name="sd" id="sd"><option value="a" selected="selected">Ascending</option><option value="d">Descending</option></select> <input type="submit" name="sort" value="Go" class="button2" /></label>
		
	</fieldset>

	</form>
	<hr />


<div class="topic-actions">
	<div class="buttons">
	
		<div class="reply-icon"><a href="posting2baf.html?mode=reply&amp;f=5&amp;t=1858" title="Post a reply"><span></span>Post a reply</a></div>
	
	</div>

	
		<div class="pagination">
			6 posts
			 &bull; Page <strong>1</strong> of <strong>1</strong>
		</div>
	
</div>


	<p></p><p><a href="viewforume774.html?f=5" class="left-box left" accesskey="r">Return to General Discussion</a></p>

	<form method="post" id="jumpbox" action="http://flyfunston.org/bbs/viewforum.php" onsubmit="if(this.f.value == -1){return false;}">

	
		<fieldset class="jumpbox">
	
			<label for="f" accesskey="j">Jump to:</label>
			<select name="f" id="f" onchange="if(this.options[this.selectedIndex].value != -1){ document.forms['jumpbox'].submit() }">
			
				<option value="-1">Select a forum</option>
			<option value="-1">------------------</option>
				<option value="9">Discussion Groups</option>
			
				<option value="5" selected="selected">&nbsp; &nbsp;General Discussion</option>
			
				<option value="8">&nbsp; &nbsp;Announcements</option>
			
				<option value="7">&nbsp; &nbsp;For Sale/Wanted</option>
			
				<option value="6">&nbsp; &nbsp;Road Trips</option>
			
				<option value="2">&nbsp; &nbsp;Meeting Minutes and Treasurer Reports</option>
			
				<option value="11">&nbsp; &nbsp;Off Topic</option>
			
			</select>
			<input type="submit" value="Go" class="button2" />
		</fieldset>
	</form>


	<h3>Who is online</h3>
	<p>Users browsing this forum: No registered users and 6 guests</p>
</div>

<div id="page-footer">

	<div class="navbar">
		<div class="inner"><span class="corners-top"><span></span></span>

		<ul class="linklist">
			<li class="icon-home"><a href="index.html">Board index</a></li>
				
			<li class="rightside"><a href="memberlista2f5.html?mode=leaders">The team</a> &bull; <a href="ucp033a.html?mode=delete_cookies">Delete all board cookies</a> &bull; All times are UTC - 8 hours [ <abbr title="Daylight Saving Time">DST</abbr> ]</li>
		</ul>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<div class="copyright">Powered by <a href="https://www.phpbb.com/">phpBB</a>&reg; Forum Software &copy; phpBB Group
		
	</div>
</div>

</div>

<div>
	<a id="bottom" name="bottom" accesskey="z"></a>
	<img src="cron5b0b.gif?cron_type=tidy_sessions" width="1" height="1" alt="cron" />
</div>

</body>

<!-- Mirrored from flyfunston.org/bbs/viewtopic.php?p=4451 by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 08 Aug 2021 19:13:17 GMT -->
</html>