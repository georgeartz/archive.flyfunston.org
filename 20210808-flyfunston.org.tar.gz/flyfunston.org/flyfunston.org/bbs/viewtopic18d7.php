<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en-us" xml:lang="en-us">

<!-- Mirrored from flyfunston.org/bbs/viewtopic.php?f=5&t=1733&view=print by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 08 Aug 2021 20:04:53 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>

<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<meta http-equiv="content-style-type" content="text/css" />
<meta http-equiv="content-language" content="en-us" />
<meta http-equiv="imagetoolbar" content="no" />
<meta name="resource-type" content="document" />
<meta name="distribution" content="global" />
<meta name="robots" content="noindex" />

<title>Flyfunston &bull; View topic - Wires</title>

<link href="styles/prosilver/theme/print.css" rel="stylesheet" type="text/css" />
</head>

<body id="phpbb">
<div id="wrap">
	<a id="top" name="top" accesskey="t"></a>

	<div id="page-header">
		<h1>Flyfunston</h1>
		<p>Hang Gliding at Fort Funston<br /><a href="index-2.html">http://flyfunston.org/bbs/</a></p>

		<h2>Wires</h2>
		<p><a href="viewtopic200c.html?f=5&amp;t=1733">http://flyfunston.org/bbs/viewtopic.php?f=5&amp;t=1733</a></p>
	</div>

	<div id="page-body">
		<div class="page-number">Page <strong>1</strong> of <strong>1</strong></div>
		
			<div class="post">
				<h3>Wires</h3>
				<div class="date"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" />Posted: <strong>Sun Sep 20, 2015 7:32 pm</strong></div>
				<div class="author">by <strong>Steve Davy</strong></div>
				<div class="content"><!-- m --><a class="postlink" href="https://vimeo.com/138095129">https://vimeo.com/138095129</a><!-- m --></div>
			</div>
			<hr />
		
			<div class="post">
				<h3>Re: Wires</h3>
				<div class="date"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" />Posted: <strong>Mon Sep 21, 2015 3:37 pm</strong></div>
				<div class="author">by <strong>flyin_canuck</strong></div>
				<div class="content">Did you notice the moron in the video rubs his wire on a big rock when he steps on it, then the second time actually comments to make sure the rock isn't sharp<br /><br />abrasion on a flat rock can still be pretty bad for wires</div>
			</div>
			<hr />
		
			<div class="post">
				<h3>Re: Wires</h3>
				<div class="date"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" />Posted: <strong>Mon Sep 21, 2015 9:19 pm</strong></div>
				<div class="author">by <strong>Steve Davy</strong></div>
				<div class="content"><blockquote><div><cite>flyin_canuck wrote:</cite>Did you notice the moron in the video rubs his wire on a big rock when he steps on it, then the second time actually comments to make sure the rock isn't sharp<br /><br />abrasion on a flat rock can still be pretty bad for wires</div></blockquote></div>
			</div>
			<hr />
		
			<div class="post">
				<h3>Re: Wires</h3>
				<div class="date"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" />Posted: <strong>Tue Sep 22, 2015 4:10 pm</strong></div>
				<div class="author">by <strong>brianscharp</strong></div>
				<div class="content"><blockquote class="uncited"><div>Did you notice the moron in the video rubs his wire on a big rock when he steps on it...</div></blockquote><br />No. What I saw was a deliberate demonstration that - with a little care - the test can be done with no rock contact even in that setting.</div>
			</div>
			<hr />
		
	</div>

	<div id="page-footer">
		<div class="page-number">All times are UTC - 8 hours [ <abbr title="Daylight Saving Time">DST</abbr> ]<br />Page <strong>1</strong> of <strong>1</strong></div>
		<div class="copyright">Powered by phpBB&reg; Forum Software &copy; phpBB Group<br />https://www.phpbb.com/</div>
	</div>
</div>

</body>

<!-- Mirrored from flyfunston.org/bbs/viewtopic.php?f=5&t=1733&view=print by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 08 Aug 2021 20:04:53 GMT -->
</html>