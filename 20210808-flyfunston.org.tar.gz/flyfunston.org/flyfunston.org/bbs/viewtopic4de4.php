<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en-us" xml:lang="en-us">

<!-- Mirrored from flyfunston.org/bbs/viewtopic.php?p=2359 by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 08 Aug 2021 20:14:43 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>

<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<meta http-equiv="content-style-type" content="text/css" />
<meta http-equiv="content-language" content="en-us" />
<meta http-equiv="imagetoolbar" content="no" />
<meta name="resource-type" content="document" />
<meta name="distribution" content="global" />
<meta name="keywords" content="" />
<meta name="description" content="" />

<title>Flyfunston &bull; View topic - New Funston Clubhouse Notice Rule</title>



<!--
	phpBB style name: prosilver
	Based on style:   prosilver (this is the default phpBB3 style)
	Original author:  Tom Beddard ( http://www.subBlue.com/ )
	Modified by:
-->

<script type="text/javascript">
// <![CDATA[
	var jump_page = 'Enter the page number you wish to go to:';
	var on_page = '1';
	var per_page = '25';
	var base_url = 'viewtopicf918.html?f=5&amp;t=1079';
	var style_cookie = 'phpBBstyle';
	var style_cookie_settings = '; path=/; domain=flyfunston.org; secure';
	var onload_functions = new Array();
	var onunload_functions = new Array();

	

	/**
	* Find a member
	*/
	function find_username(url)
	{
		popup(url, 760, 570, '_usersearch');
		return false;
	}

	/**
	* New function for handling multiple calls to window.onload and window.unload by pentapenguin
	*/
	window.onload = function()
	{
		for (var i = 0; i < onload_functions.length; i++)
		{
			eval(onload_functions[i]);
		}
	};

	window.onunload = function()
	{
		for (var i = 0; i < onunload_functions.length; i++)
		{
			eval(onunload_functions[i]);
		}
	};

// ]]>
</script>
<script type="text/javascript" src="styles/prosilver/template/styleswitcher.js"></script>
<script type="text/javascript" src="styles/prosilver/template/forum_fn.js"></script>

<link href="styles/prosilver/theme/print.css" rel="stylesheet" type="text/css" media="print" title="printonly" />
<link href="style7a95.css?id=1&amp;lang=en_us" rel="stylesheet" type="text/css" media="screen, projection" />

<link href="styles/prosilver/theme/normal.css" rel="stylesheet" type="text/css" title="A" />
<link href="styles/prosilver/theme/medium.css" rel="alternate stylesheet" type="text/css" title="A+" />
<link href="styles/prosilver/theme/large.css" rel="alternate stylesheet" type="text/css" title="A++" />



</head>

<body id="phpbb" class="section-viewtopic ltr">

<div id="wrap">
	<a id="top" name="top" accesskey="t"></a>
	<div id="page-header">
		<div class="headerbar">
			<div class="inner"><span class="corners-top"><span></span></span>

			<div id="site-description">
				<a href="index.html" title="Board index" id="logo"><img src="styles/prosilver/imageset/site_logo.gif" width="149" height="52" alt="" title="" /></a>
				<h1>Flyfunston</h1>
				<p>Hang Gliding at Fort Funston</p>
				<p class="skiplink"><a href="#start_here">Skip to content</a></p>
			</div>

		
			<div id="search-box">
				<form action="http://flyfunston.org/bbs/search.php" method="get" id="search">
				<fieldset>
					<input name="keywords" id="keywords" type="text" maxlength="128" title="Search for keywords" class="inputbox search" value="Search…" onclick="if(this.value=='Search…')this.value='';" onblur="if(this.value=='')this.value='Search…';" />
					<input class="button2" value="Search" type="submit" /><br />
					<a href="search.html" title="View the advanced search options">Advanced search</a> 
				</fieldset>
				</form>
			</div>
		

			<span class="corners-bottom"><span></span></span></div>
		</div>

		<div class="navbar">
			<div class="inner"><span class="corners-top"><span></span></span>

			<ul class="linklist navlinks">
				<li class="icon-home"><a href="index.html" accesskey="h">Board index</a>  <strong>&#8249;</strong> <a href="viewforumfdc5.html?f=9">Discussion Groups</a> <strong>&#8249;</strong> <a href="viewforume774.html?f=5">General Discussion</a></li>

				<li class="rightside"><a href="#" onclick="fontsizeup(); return false;" onkeypress="return fontsizeup(event);" class="fontsize" title="Change font size">Change font size</a></li>

				<li class="rightside"><a href="viewtopicab98-2.html?f=5&amp;t=1079&amp;view=print" title="Print view" accesskey="p" class="print">Print view</a></li>
			</ul>

			

			<ul class="linklist rightside">
				<li class="icon-faq"><a href="faq.html" title="Frequently Asked Questions">FAQ</a></li>
				
					<li class="icon-logout"><a href="ucp26c3.php?mode=login" title="Login" accesskey="x">Login</a></li>
				
			</ul>

			<span class="corners-bottom"><span></span></span></div>
		</div>

	</div>

	<a name="start_here"></a>
	<div id="page-body">
		
<h2><a href="viewtopicf918.html?f=5&amp;t=1079">New Funston Clubhouse Notice Rule</a></h2>
<!-- NOTE: remove the style="display: none" when you want to have the forum description on the topic body --><div style="display: none !important;">Talk about Hang Gliding at Ft Funston and the Fellow Feathers Club.<br /></div>

<div class="topic-actions">

	<div class="buttons">
	
		<div class="reply-icon"><a href="postingd75a.html?mode=reply&amp;f=5&amp;t=1079" title="Post a reply"><span></span>Post a reply</a></div>
	
	</div>

	
		<div class="search-box">
			<form method="get" id="topic-search" action="http://flyfunston.org/bbs/search.php">
			<fieldset>
				<input class="inputbox search tiny"  type="text" name="keywords" id="search_keywords" size="20" value="Search this topic…" onclick="if(this.value=='Search this topic…')this.value='';" onblur="if(this.value=='')this.value='Search this topic…';" />
				<input class="button2" type="submit" value="Search" />
				<input type="hidden" name="t" value="1079" />
<input type="hidden" name="sf" value="msgonly" />

			</fieldset>
			</form>
		</div>
	
		<div class="pagination">
			30 posts
			 &bull; <a href="#" onclick="jumpto(); return false;" title="Click to jump to page…">Page <strong>1</strong> of <strong>2</strong></a> &bull; <span><strong>1</strong><span class="page-sep">, </span><a href="viewtopic384b.html?f=5&amp;t=1079&amp;start=25">2</a></span>
		</div>
	

</div>
<div class="clear"></div>


	<div id="p2357" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting4c7d.html?mode=quote&amp;f=5&amp;p=2357" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 class="first"><a href="#p2357">New Funston Clubhouse Notice Rule</a></h3>
			<p class="author"><a href="viewtopicb50a.html?p=2357#p2357"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist9acc.html?mode=viewprofile&amp;u=126">Dan Brown</a></strong> &raquo; Thu Dec 23, 2010 2:51 pm </p>

			

			<div class="content">On the Fellow Feathers’ Permit and Voting membership form below the signature line is a new rule that should be w/drawn or revised. The rule states: “This member stipulates that for purpose of notice, official notification shall be placed in the Fellow Feathers clubhouse ….”<br /><br />Our bylaws state notice of meetings and bylaw changes shall be posted on the clubhouse door. The bylaws are silent on notice for other matters. Under the new rule a pilot could be given notice that he is being summoned to a disciplinary meeting to have his flying privileges revoked by a posting inside the clubhouse even if the pilot doesn’t have access to the clubhouse. Pilots w/access to the clubhouse who fly infrequently may not have the opportunity to see notices posted inside the building.<br /><br />I am sure Charley wouldn’t do this but a glider could be removed from the clubhouse w/o the courtesy of an e-mail or letter to pilot. Only a posting inside the building.<br /><br />Club rules should be made by club members and voted upon at meetings. I recommend the following notice rule: “Notice of disciplinary proceedings and removal of gliders from the clubhouse shall be by e-mail or regular mail sent to the pilot's last known address.&quot;<br /> <br /> Rules may be passed by a simple majority at a club meeting.<br /> <br />Dan Brown</div>

			

		</div>

		
			<dl class="postprofile" id="profile2357">
			<dt>
				<a href="memberlist9acc.html?mode=viewprofile&amp;u=126">Dan Brown</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 88</dd><dd><strong>Joined:</strong> Fri Apr 01, 2005 2:01 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2359" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postingd67f-2.html?mode=quote&amp;f=5&amp;p=2359" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2359">Re: New Funston Clubhouse Notice Rule</a></h3>
			<p class="author"><a href="viewtopic4de4.php?p=2359#p2359"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberliste69f.html?mode=viewprofile&amp;u=15" style="color: #AA0000;" class="username-coloured">Steve Rodrigues</a></strong> &raquo; Fri Dec 24, 2010 8:03 am </p>

			

			<div class="content">I don’t have a problem with spelling out how the club contacts members in regard to disciplinary actions and clubhouse management. Even though the club has been handling this fine for decades, it can’t hurt to have procedures in writing.<br /><br />But just to clarify: The one line notice to which you are referring is not a new rule. It has been in place since we incorporated as a non-profit and is a legal requirement for corporations.<br /><br />To reiterate what I said in our private email: This statement has nothing to do with disciplinary actions or clubhouse management. It is a legal requirement for non-profit corporations to inform its voting members how they will be notified of official business meetings.<br /><br />By having this statement on the membership form, the corporation is relieved of its duty to mail a letter to each voting member whenever there is a proposed bylaws change. The club has been using the clubhouse door for notices of proposed bylaws changes since its early days and as I recall, you lobbied very hard to keep it that way. This notice is in line with your wishes!<br /><br />The language for club disciplinary actions and clubhouse management that appears in the FF rules and Bylaws has not changed for many years. And you are right, they don’t specify how members should be notified of important issues like suspensions or glider auctions. If you think these documents need revision, please feel free to make a motion to change them. Just understand that this has nothing to do with the one line notice on the membership form.</div>

			<div id="sig2359" class="signature">USHPA # 30605<br />H-5, Mentor and Observer</div>

		</div>

		
			<dl class="postprofile" id="profile2359">
			<dt>
				<a href="memberliste69f.html?mode=viewprofile&amp;u=15"><img src="download/file9b05.php?avatar=15_1575056796.jpg" width="200" height="149" alt="User avatar" /></a><br />
				<a href="memberliste69f.html?mode=viewprofile&amp;u=15" style="color: #AA0000;" class="username-coloured">Steve Rodrigues</a>
			</dt>

			<dd>Site Admin</dd>

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 723</dd><dd><strong>Joined:</strong> Mon May 24, 2004 10:57 pm</dd><dd><strong>Location:</strong> Brisbane, California</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2360" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting6fbf.html?mode=quote&amp;f=5&amp;p=2360" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2360">Re: New Funston Clubhouse Notice Rule</a></h3>
			<p class="author"><a href="viewtopic9252.html?p=2360#p2360"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist9acc.html?mode=viewprofile&amp;u=126">Dan Brown</a></strong> &raquo; Fri Dec 24, 2010 11:16 am </p>

			

			<div class="content">Not to prolong the discussion since there appears to be basic agreement but posting on the door for meetings and bylaw changes has been the procedure since 2000 when I wrote the previous set of  bylaws.<br /><br />  Despite the new rule, bylaw changes and notice of meetings still must be posted on the door. According to the new rule, all other notices must be posted inside the clubhouse and many pilots never go inside the clubhouse or go there infrequently. Also since the new rule was not passed by the members at a meeting, it is unenforceable.</div>

			

		</div>

		
			<dl class="postprofile" id="profile2360">
			<dt>
				<a href="memberlist9acc.html?mode=viewprofile&amp;u=126">Dan Brown</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 88</dd><dd><strong>Joined:</strong> Fri Apr 01, 2005 2:01 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2363" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postingdcfe.php?mode=quote&amp;f=5&amp;p=2363" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2363">Re: New Funston Clubhouse Notice Rule</a></h3>
			<p class="author"><a href="viewtopicc200.html?p=2363#p2363"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberliste69f.html?mode=viewprofile&amp;u=15" style="color: #AA0000;" class="username-coloured">Steve Rodrigues</a></strong> &raquo; Sat Dec 25, 2010 12:04 pm </p>

			

			<div class="content">I want to point out that we are talking about “apples and oranges” in that one type of notice applies to all Voting Members in regard to corporate business, and the other notice is for an individual in regard to a suspension or clubhouse eviction that only affects them. These are two different types of notices and need to be handled differently.<br /><br />&quot;Purpose of notice&quot; is a term from corporate law. The Fellow Feathers non-profit corporation is by law, required to inform Voting Members how they will be notified of BOD meetings and opportunities to vote.<br /><br />The statement currently reads &quot;This member stipulates by signature that for purpose of notice, official notifications shall be posted in the Fellow Feathers clubhouse, Building FF-206, Fort Funston, San Francisco, CA.&quot;<br /><br />I agree that this statement should not be in conflict with the bylaws so I propose that we change the word &quot;in&quot; to &quot;on&quot;.<br /><br />It would then read:<br /><br />&quot;This member stipulates by signature that for purpose of notice, official notifications shall be posted on the Fellow Feathers clubhouse, Building FF-206, Fort Funston, San Francisco, CA.&quot;<br /><br />As for your proposal to have our rules specify how individual FF members, both voting and non-voting, will be notified of disciplinary actions and clubhouse evictions:<br /><br />“Notice of disciplinary proceedings and removal of gliders from the clubhouse shall be by e-mail or regular mail sent to the pilot's last known address.&quot;<br /><br />Question: Would this best appear in the FF rules or the bylaws?<br /><br />Thanks for your help in getting our documents right!</div>

			<div id="sig2363" class="signature">USHPA # 30605<br />H-5, Mentor and Observer</div>

		</div>

		
			<dl class="postprofile" id="profile2363">
			<dt>
				<a href="memberliste69f.html?mode=viewprofile&amp;u=15"><img src="download/file9b05.php?avatar=15_1575056796.jpg" width="200" height="149" alt="User avatar" /></a><br />
				<a href="memberliste69f.html?mode=viewprofile&amp;u=15" style="color: #AA0000;" class="username-coloured">Steve Rodrigues</a>
			</dt>

			<dd>Site Admin</dd>

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 723</dd><dd><strong>Joined:</strong> Mon May 24, 2004 10:57 pm</dd><dd><strong>Location:</strong> Brisbane, California</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2364" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting9ef6.html?mode=quote&amp;f=5&amp;p=2364" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2364">Re: New Funston Clubhouse Notice Rule</a></h3>
			<p class="author"><a href="viewtopic97da.html?p=2364#p2364"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist9acc.html?mode=viewprofile&amp;u=126">Dan Brown</a></strong> &raquo; Sun Dec 26, 2010 2:37 pm </p>

			

			<div class="content">Both notices, the stipulation beneath the signature line and the Bylaws/Disciplinary, should be submitted to the members for simple majority vote at a regular meeting. There is no need to go through the complicated Bylaw procedure. <br /><br />I suggest we include the term &quot;reasonable&quot; in the notices. For example: &quot;Reasonable notice shall be given ... .&quot;<br /><br />The problem w/making rules by stipulation is that it prevents a full discussion of the rules and deprives members of a voice in rule making. The only reason I became aware of this matter is that a pilot contacted me about the stipulation. He is a club member w/o access to the Clubhouse.</div>

			

		</div>

		
			<dl class="postprofile" id="profile2364">
			<dt>
				<a href="memberlist9acc.html?mode=viewprofile&amp;u=126">Dan Brown</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 88</dd><dd><strong>Joined:</strong> Fri Apr 01, 2005 2:01 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2365" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting665d.php?mode=quote&amp;f=5&amp;p=2365" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2365">Re: New Funston Clubhouse Notice Rule</a></h3>
			<p class="author"><a href="viewtopicd7ab.html?p=2365#p2365"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberliste69f.html?mode=viewprofile&amp;u=15" style="color: #AA0000;" class="username-coloured">Steve Rodrigues</a></strong> &raquo; Mon Dec 27, 2010 9:00 am </p>

			

			<div class="content">See you at the January meeting.  <img src="images/smilies/icon_biggrin.html" alt=":D" title="Very Happy" /></div>

			<div id="sig2365" class="signature">USHPA # 30605<br />H-5, Mentor and Observer</div>

		</div>

		
			<dl class="postprofile" id="profile2365">
			<dt>
				<a href="memberliste69f.html?mode=viewprofile&amp;u=15"><img src="download/file9b05.php?avatar=15_1575056796.jpg" width="200" height="149" alt="User avatar" /></a><br />
				<a href="memberliste69f.html?mode=viewprofile&amp;u=15" style="color: #AA0000;" class="username-coloured">Steve Rodrigues</a>
			</dt>

			<dd>Site Admin</dd>

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 723</dd><dd><strong>Joined:</strong> Mon May 24, 2004 10:57 pm</dd><dd><strong>Location:</strong> Brisbane, California</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2366" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting949a.html?mode=quote&amp;f=5&amp;p=2366" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2366">Re: New Funston Clubhouse Notice Rule</a></h3>
			<p class="author"><a href="viewtopic99a0.html?p=2366#p2366"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist9c48.php?mode=viewprofile&amp;u=1873">e j</a></strong> &raquo; Wed Dec 29, 2010 12:35 pm </p>

			

			<div class="content">Dear Sirs,<br /><br />I have read over the new &quot;Fellow Feather Application for hang gliding permit&quot; and I am concerned about the changes to the form.  Below the line where the Pilot's Signature is Required to complete the application, a line has been added, &quot;This member stipulates by signature that for purpose of notice, official notification shall be...&quot;.<br /><br />I feel that it is improper to make the ability to fly at Fort Funston as a voting member contingent on the member agreeing to changes in the club notice requirements.  Any changes should be submitted to the members for a vote at a regular meeting.<br /><br />I am curious to know who is responsible for the changes to Application form. <br /><br />Also, I would like to know if our new club officers feel this change is appropriate: <br /><br />Tech Officer: Chuck K ranz<br />Safety Officer: Raphael L evin<br />Vice Pres: Eric M eis<br />Clubhouse Manager: Charlie N elson<br />Secretary: Dave K iesling<br />Treasurer: Van P elham<br />President: Tom R ust<br /><br />Sincerely,<br />e j</div>

			

		</div>

		
			<dl class="postprofile" id="profile2366">
			<dt>
				<a href="memberlist9c48.php?mode=viewprofile&amp;u=1873">e j</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 11</dd><dd><strong>Joined:</strong> Tue Dec 28, 2010 7:16 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2367" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting672c.php?mode=quote&amp;f=5&amp;p=2367" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2367">Re: New Funston Clubhouse Notice Rule</a></h3>
			<p class="author"><a href="viewtopicc517.php?p=2367#p2367"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist1d86.php?mode=viewprofile&amp;u=1867">cliffblack1</a></strong> &raquo; Wed Dec 29, 2010 5:36 pm </p>

			

			<div class="content">Hi EJ, Thanks for ther interest, I think the forum would appreciate a full name.<br />best regards<br />Tom Jensen</div>

			

		</div>

		
			<dl class="postprofile" id="profile2367">
			<dt>
				<a href="memberlist1d86.php?mode=viewprofile&amp;u=1867">cliffblack1</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 27</dd><dd><strong>Joined:</strong> Fri Dec 10, 2010 12:34 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2368" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postingb985.html?mode=quote&amp;f=5&amp;p=2368" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2368">Re: New Funston Clubhouse Notice Rule</a></h3>
			<p class="author"><a href="viewtopic07c5.html?p=2368#p2368"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist9c48.php?mode=viewprofile&amp;u=1873">e j</a></strong> &raquo; Wed Dec 29, 2010 7:10 pm </p>

			

			<div class="content">Hello Tom Jensen,<br /><br />Thank you for the suggestion.  However, since I am really not interested in being indexed on Google, Yahoo, and other search engines, I will pass at this time.<br /><br />In the interim, what do you think about the content of my post, specifically; Below the line where the Pilot's Signature is Required to complete the application, a line has been added, &quot;This member stipulates by signature that for purpose of notice, official notification shall be...&quot;.  <br /><br />Is it proper to make the ability to fly at Fort Funston as a voting member contingent on the member agreeing to changes in the club notice requirements?<br /><br />e j</div>

			

		</div>

		
			<dl class="postprofile" id="profile2368">
			<dt>
				<a href="memberlist9c48.php?mode=viewprofile&amp;u=1873">e j</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 11</dd><dd><strong>Joined:</strong> Tue Dec 28, 2010 7:16 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2369" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting7378.html?mode=quote&amp;f=5&amp;p=2369" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2369">Re: New Funston Clubhouse Notice Rule</a></h3>
			<p class="author"><a href="viewtopic57e2.php?p=2369#p2369"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberliste69f.html?mode=viewprofile&amp;u=15" style="color: #AA0000;" class="username-coloured">Steve Rodrigues</a></strong> &raquo; Wed Dec 29, 2010 9:56 pm </p>

			

			<div class="content">&quot;EJ&quot; wrote: Is it proper to make the ability to fly at Fort Funston as a voting member contingent on the member agreeing to changes in the club notice requirements?&quot;<br /><br />Dear &quot;EJ&quot;,<br />Yes, it is proper. The Fellow Feathers of Fort Funston Hang Gliding Club and its Voting Members must comply with California corporate law. Voting members must comply with FF rules and bylaws. Posting on the clubhouse door is FF SOP. Comply or don't fly, simple as that.<br /><br />Please bring your concerns to the next meeting. I will not reply to your future posts until you identify yourself. If you have issues with public forums you can contact me off line.<br /><br />Yours Truly,<br />Steve Rodrigues</div>

			<div id="sig2369" class="signature">USHPA # 30605<br />H-5, Mentor and Observer</div>

		</div>

		
			<dl class="postprofile" id="profile2369">
			<dt>
				<a href="memberliste69f.html?mode=viewprofile&amp;u=15"><img src="download/file9b05.php?avatar=15_1575056796.jpg" width="200" height="149" alt="User avatar" /></a><br />
				<a href="memberliste69f.html?mode=viewprofile&amp;u=15" style="color: #AA0000;" class="username-coloured">Steve Rodrigues</a>
			</dt>

			<dd>Site Admin</dd>

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 723</dd><dd><strong>Joined:</strong> Mon May 24, 2004 10:57 pm</dd><dd><strong>Location:</strong> Brisbane, California</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2372" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postingd174.html?mode=quote&amp;f=5&amp;p=2372" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2372">Re: New Funston Clubhouse Notice Rule</a></h3>
			<p class="author"><a href="viewtopicaa19.html?p=2372#p2372"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist9c48.php?mode=viewprofile&amp;u=1873">e j</a></strong> &raquo; Thu Dec 30, 2010 11:07 am </p>

			

			<div class="content">Thank You Steve Rodrigues,<br /><br />I noticed that you edited your last response and struck the original from the record.  I guess that that is within your powers being site administrator, &quot;the person who controls the content of the web site&quot;.<br /><br />It is ok that you will not be replying to my post as you have not answered my questions and maybe there is someone else who can:<br /><br />I have read over the new &quot;Fellow Feather Application for hang gliding permit&quot; and I am concerned about the changes to the form. Below the line where the Pilot's Signature is Required to complete the application, a line has been added, &quot;This member stipulates by signature that for purpose of notice, official notification shall be...&quot;.<br /><br />I feel that it is improper to make the ability to fly at Fort Funston as a voting member contingent on the member agreeing to changes in the club notice requirements. Any changes should be submitted to the members for a vote at a regular meeting.<br /><br />I am curious to know who is responsible for the changes to the Application form.<br /><br />Also, I would like to know if our new club officers feel this change to the form is appropriate:<br /><br />Tech Officer: Chuck K ranz<br />Safety Officer: Raphael L evin<br />Vice Pres: Eric M eis<br />Clubhouse Manager: Charlie N elson<br />Secretary: Dave K iesling<br />Treasurer: Van P elham<br />President: Tom R ust<br /><br />Sincerely,<br />e j</div>

			

		</div>

		
			<dl class="postprofile" id="profile2372">
			<dt>
				<a href="memberlist9c48.php?mode=viewprofile&amp;u=1873">e j</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 11</dd><dd><strong>Joined:</strong> Tue Dec 28, 2010 7:16 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2373" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting3cad.html?mode=quote&amp;f=5&amp;p=2373" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2373">Re: New Funston Clubhouse Notice Rule</a></h3>
			<p class="author"><a href="viewtopic6a23.php?p=2373#p2373"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist9acc.html?mode=viewprofile&amp;u=126">Dan Brown</a></strong> &raquo; Thu Dec 30, 2010 11:55 am </p>

			

			<div class="content">Before the discussion further deteriorates, it should be noted that the Club doesn't have SOPs or a notice rule. (See rules pulbished on WEB site.) The Bylaws  have a notice requirement for meetings and Bylaw changes but are silent on notice for other matters.<br /><br />The Club needs to have a notice requirement for other matters and that is why I made the above recommendations. The recommendations are not limited to changing &quot;in&quot; to &quot;on&quot;. Perhaps better notice than posting on the clubhouse would be posting on the WEB site. However notice is to be provided, it should be decided by the members and not by a stipulation on a form.<br /><br />E.J. has a valid concern about editing a post on the WEB site particularly when only one party has the ability to make the change. Rather than editing/removing a post, a better procedure would be to post an amendment or correction.</div>

			

		</div>

		
			<dl class="postprofile" id="profile2373">
			<dt>
				<a href="memberlist9acc.html?mode=viewprofile&amp;u=126">Dan Brown</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 88</dd><dd><strong>Joined:</strong> Fri Apr 01, 2005 2:01 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2374" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting65a0.html?mode=quote&amp;f=5&amp;p=2374" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2374">Re: New Funston Clubhouse Notice Rule</a></h3>
			<p class="author"><a href="viewtopic9f9d-2.html?p=2374#p2374"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlistd3cc.html?mode=viewprofile&amp;u=1478">fakeDecoy</a></strong> &raquo; Fri Dec 31, 2010 12:50 am </p>

			

			<div class="content">I decline to comment until my corporate campaign contributors who bought me into office tell me what my opinion is. But to be honest I plan on expending all my energy into fulfilling my obligations to my campaign contributors by pushing for an oil derrick in the setup area.<br /><br />I'll add this to the next meeting agenda. <br /><br />Dave K<br />Secretary</div>

			

		</div>

		
			<dl class="postprofile" id="profile2374">
			<dt>
				<a href="memberlistd3cc.html?mode=viewprofile&amp;u=1478">fakeDecoy</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 140</dd><dd><strong>Joined:</strong> Thu Jul 24, 2008 8:22 am</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2375" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting8488.php?mode=quote&amp;f=5&amp;p=2375" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2375">Re: New Funston Clubhouse Notice Rule</a></h3>
			<p class="author"><a href="viewtopic708c.html?p=2375#p2375"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberliste69f.html?mode=viewprofile&amp;u=15" style="color: #AA0000;" class="username-coloured">Steve Rodrigues</a></strong> &raquo; Fri Dec 31, 2010 5:54 am </p>

			

			<div class="content">Dan,<br /><br />You are often a champion against injustice and wrongdoing and I applaud you for your efforts!<br /><br />However, before you get too fired up about what “EJ” said in regard to my posting, I’d like to point out the facts:<br /><br />I recently posted a rather long winded reply that I decided was inappropriate. I deleted that reply and re-posted a shorter and more succinct reply.<br /><br />Everyone who posts on this discussion board has both the ability and the right to delete their own posts, so while you might have your personal preferences as to how someone should or shouldn’t post, my actions were not an abuse of, nor involve in any way, my Admin privileges.<br /><br />I take pride in my honesty and ethics and trust that this alleviates your concerns. I’m sure you will advise me otherwise!  <img src="images/smilies/icon_wink.html" alt=";-)" title="Wink" /><br /><br />Yours truly,<br />Steve</div>

			<div id="sig2375" class="signature">USHPA # 30605<br />H-5, Mentor and Observer</div>

		</div>

		
			<dl class="postprofile" id="profile2375">
			<dt>
				<a href="memberliste69f.html?mode=viewprofile&amp;u=15"><img src="download/file9b05.php?avatar=15_1575056796.jpg" width="200" height="149" alt="User avatar" /></a><br />
				<a href="memberliste69f.html?mode=viewprofile&amp;u=15" style="color: #AA0000;" class="username-coloured">Steve Rodrigues</a>
			</dt>

			<dd>Site Admin</dd>

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 723</dd><dd><strong>Joined:</strong> Mon May 24, 2004 10:57 pm</dd><dd><strong>Location:</strong> Brisbane, California</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2376" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postinged97.html?mode=quote&amp;f=5&amp;p=2376" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2376">Re: New Funston Clubhouse Notice Rule</a></h3>
			<p class="author"><a href="viewtopic5b90.html?p=2376#p2376"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist9c48.php?mode=viewprofile&amp;u=1873">e j</a></strong> &raquo; Fri Dec 31, 2010 3:16 pm </p>

			

			<div class="content">I think a simplification is in order,<br /><br />I am curious to know who is responsible for the changes to the Application form.<br /><br />Sincerely,<br />e j</div>

			

		</div>

		
			<dl class="postprofile" id="profile2376">
			<dt>
				<a href="memberlist9c48.php?mode=viewprofile&amp;u=1873">e j</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 11</dd><dd><strong>Joined:</strong> Tue Dec 28, 2010 7:16 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2378" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting56bd.php?mode=quote&amp;f=5&amp;p=2378" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2378">Re: New Funston Clubhouse Notice Rule</a></h3>
			<p class="author"><a href="viewtopic9f15.html?p=2378#p2378"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberliste69f.html?mode=viewprofile&amp;u=15" style="color: #AA0000;" class="username-coloured">Steve Rodrigues</a></strong> &raquo; Sat Jan 01, 2011 5:38 pm </p>

			

			<div class="content">EJ, <br />I will be happy to answer your question publicly if you ID your self, or in private if you contact me directly.<br />Happy New Year!<br />Steve</div>

			<div id="sig2378" class="signature">USHPA # 30605<br />H-5, Mentor and Observer</div>

		</div>

		
			<dl class="postprofile" id="profile2378">
			<dt>
				<a href="memberliste69f.html?mode=viewprofile&amp;u=15"><img src="download/file9b05.php?avatar=15_1575056796.jpg" width="200" height="149" alt="User avatar" /></a><br />
				<a href="memberliste69f.html?mode=viewprofile&amp;u=15" style="color: #AA0000;" class="username-coloured">Steve Rodrigues</a>
			</dt>

			<dd>Site Admin</dd>

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 723</dd><dd><strong>Joined:</strong> Mon May 24, 2004 10:57 pm</dd><dd><strong>Location:</strong> Brisbane, California</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2379" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting2bdd.html?mode=quote&amp;f=5&amp;p=2379" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2379">Re: New Funston Clubhouse Notice Rule</a></h3>
			<p class="author"><a href="viewtopic0047.php?p=2379#p2379"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist1d86.php?mode=viewprofile&amp;u=1867">cliffblack1</a></strong> &raquo; Sun Jan 02, 2011 12:04 pm </p>

			

			<div class="content">Great response Steve! We should respond to real people not people that hide. <br />Sincerly <br />Tom Jensen</div>

			

		</div>

		
			<dl class="postprofile" id="profile2379">
			<dt>
				<a href="memberlist1d86.php?mode=viewprofile&amp;u=1867">cliffblack1</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 27</dd><dd><strong>Joined:</strong> Fri Dec 10, 2010 12:34 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2381" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postinge093.html?mode=quote&amp;f=5&amp;p=2381" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2381">Re: New Funston Clubhouse Notice Rule</a></h3>
			<p class="author"><a href="viewtopicd17a.php?p=2381#p2381"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist9c48.php?mode=viewprofile&amp;u=1873">e j</a></strong> &raquo; Sun Jan 02, 2011 3:17 pm </p>

			

			<div class="content">Thank you for the Classic Red Herring: <!-- m --><a class="postlink" href="http://en.wikipedia.org/wiki/Red_herring">http://en.wikipedia.org/wiki/Red_herring</a><!-- m --><br /><br />Last discussion of changes to forms: Meeting Minutes November 2009; <br /><br />1) Revised clubhouse rules and waiver form by Dan Brown submitted by Steve Rodriguez. Adds wording regarding liability. Seconded, passed by unanimous vote.<br />2) Disciplinary protocol added to rules package, was only in bylaws, now in sticker package. Submitted, seconded, passed by unanimous vote. <br /><!-- l --><a class="postlink-local" href="viewtopic4d0b.html?f=2&amp;t=878">viewtopic.php?f=2&amp;t=878</a><!-- l --><br /><br />Changes to the form: Application for hang gliding permit at Fort Funston... was NOT DISCUSSED at the November 2009 meeting.<br /><br />No club discussion about changing forms has taken place since November 2009. (See Minutes)<br /><br />WHO is responsible for the changes to the Application form that took place without club discussion?<br /><br />Sincerely,<br />e j</div>

			

		</div>

		
			<dl class="postprofile" id="profile2381">
			<dt>
				<a href="memberlist9c48.php?mode=viewprofile&amp;u=1873">e j</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 11</dd><dd><strong>Joined:</strong> Tue Dec 28, 2010 7:16 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2382" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting3703.html?mode=quote&amp;f=5&amp;p=2382" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2382">Re: New Funston Clubhouse Notice Rule</a></h3>
			<p class="author"><a href="viewtopic1c8c.php?p=2382#p2382"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberliste69f.html?mode=viewprofile&amp;u=15" style="color: #AA0000;" class="username-coloured">Steve Rodrigues</a></strong> &raquo; Mon Jan 03, 2011 12:34 pm </p>

			

			<div class="content">Question: &quot;WHO is responsible for the changes to the Application form that took place without club discussion? Sincerely, e j&quot;<br /><br />Answer: Nobody is responsible for the changes to the Application form without club discussion.<br /><br />Someone IS responsible for the changes on the Application form WITH club discussion!<br />I happen to know who it was and how and when it came about.<br /><br />“ej”, If you peruse this discussion board you will find posts where many of us have taken time over the years to write detailed replies to sincere questions from honest members.<br /><br />It is all too easy to cast dispersions and innuendo if one does not have to take responsibility for what one says, so not one of us is obligated to interact with a person who insists on hiding behind a veil of anonymity.<br /><br />We have nothing to hide so I'll say this again: If you honestly want the facts, you will either ID yourself, contact me in person, or come to the next club meeting.</div>

			<div id="sig2382" class="signature">USHPA # 30605<br />H-5, Mentor and Observer</div>

		</div>

		
			<dl class="postprofile" id="profile2382">
			<dt>
				<a href="memberliste69f.html?mode=viewprofile&amp;u=15"><img src="download/file9b05.php?avatar=15_1575056796.jpg" width="200" height="149" alt="User avatar" /></a><br />
				<a href="memberliste69f.html?mode=viewprofile&amp;u=15" style="color: #AA0000;" class="username-coloured">Steve Rodrigues</a>
			</dt>

			<dd>Site Admin</dd>

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 723</dd><dd><strong>Joined:</strong> Mon May 24, 2004 10:57 pm</dd><dd><strong>Location:</strong> Brisbane, California</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2383" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting43a3.html?mode=quote&amp;f=5&amp;p=2383" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2383">Re: New Funston Clubhouse Notice Rule</a></h3>
			<p class="author"><a href="viewtopic160e.html?p=2383#p2383"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist9c48.php?mode=viewprofile&amp;u=1873">e j</a></strong> &raquo; Mon Jan 03, 2011 1:05 pm </p>

			

			<div class="content">NO RECORD in Club Minutes: <!-- l --><a class="postlink-local" href="viewforum12a3.html?f=2">viewforum.php?f=2</a><!-- l --><br /><br />WHO is responsible for the changes to the Application form that took place without club discussion?<br /><br />Every Joe wants to know.<br />Sincerely,<br />e j</div>

			

		</div>

		
			<dl class="postprofile" id="profile2383">
			<dt>
				<a href="memberlist9c48.php?mode=viewprofile&amp;u=1873">e j</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 11</dd><dd><strong>Joined:</strong> Tue Dec 28, 2010 7:16 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2384" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting2ce4.html?mode=quote&amp;f=5&amp;p=2384" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2384">Re: New Funston Clubhouse Notice Rule</a></h3>
			<p class="author"><a href="viewtopic90ed-2.html?p=2384#p2384"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberliste1b6.html?mode=viewprofile&amp;u=1877">thermal pirate</a></strong> &raquo; Mon Jan 03, 2011 3:22 pm </p>

			

			<div class="content">Hey ej,<br />UR posting same BS over and over.<br />RU retarded ?</div>

			

		</div>

		
			<dl class="postprofile" id="profile2384">
			<dt>
				<a href="memberliste1b6.html?mode=viewprofile&amp;u=1877">thermal pirate</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 10</dd><dd><strong>Joined:</strong> Mon Jan 03, 2011 3:12 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2385" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postingc4c2.html?mode=quote&amp;f=5&amp;p=2385" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2385">Re: New Funston Clubhouse Notice Rule</a></h3>
			<p class="author"><a href="viewtopic8b36.html?p=2385#p2385"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist9c48.php?mode=viewprofile&amp;u=1873">e j</a></strong> &raquo; Mon Jan 03, 2011 9:55 pm </p>

			

			<div class="content">Steve appears to know how the form was changed, &quot;I happen to know who it was and how and when it came about.&quot; <img src="images/smilies/icon_eek.gif" alt=":shock:" title="Shocked" /> <br /><br />There is NO RECORD of this change in the Club Minutes <img src="images/smilies/icon_redface.gif" alt=":oops:" title="Embarassed" /> <!-- l --><a class="postlink-local" href="viewforum12a3.html?f=2">viewforum.php?f=2</a><!-- l --><br /><br />When did the club elect to have club business conducted in this manor?  <img src="images/smilies/icon_question.gif" alt=":?:" title="Question" /> <br /><br />WHO is responsible for the changes to the Application form that took place without club discussion?<br /><br />Every Joe wants to know.<br />Sincerely,<br />e j</div>

			

		</div>

		
			<dl class="postprofile" id="profile2385">
			<dt>
				<a href="memberlist9c48.php?mode=viewprofile&amp;u=1873">e j</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 11</dd><dd><strong>Joined:</strong> Tue Dec 28, 2010 7:16 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2386" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postingec7a.php?mode=quote&amp;f=5&amp;p=2386" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2386">Re: New Funston Clubhouse Notice Rule</a></h3>
			<p class="author"><a href="viewtopic9210.html?p=2386#p2386"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberliste1b6.html?mode=viewprofile&amp;u=1877">thermal pirate</a></strong> &raquo; Tue Jan 04, 2011 11:42 am </p>

			

			<div class="content">Hey ej,<br /><br />just for a second, think about the answer to your questions as being a piece of cheese.<br /><br />if you put a rat in a plastic maze looking for some cheese, and he runs down a dead end where he can see the cheese on the other side but can’t get to it , sooner or later the rat will take another route to get the cheese.<br /><br />dude, you are just like the rat at a dead end except you won’t take another route to the cheese even after someone has shown you the way! That seems really retarded to me.<br /><br />I think a simplification is in order: Are you retarded, or just stubborn to the point of stupidity?<br /><br />Every Joe wants to know.<br /><br />Sincerely,<br />Thermal Pirate</div>

			

		</div>

		
			<dl class="postprofile" id="profile2386">
			<dt>
				<a href="memberliste1b6.html?mode=viewprofile&amp;u=1877">thermal pirate</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 10</dd><dd><strong>Joined:</strong> Mon Jan 03, 2011 3:12 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2387" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting82eb.php?mode=quote&amp;f=5&amp;p=2387" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2387">Re: New Funston Clubhouse Notice Rule</a></h3>
			<p class="author"><a href="viewtopica2b2-2.html?p=2387#p2387"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist9c48.php?mode=viewprofile&amp;u=1873">e j</a></strong> &raquo; Tue Jan 04, 2011 12:09 pm </p>

			

			<div class="content">It is interesting that there seems to be a person or group of people who don't want my question to be asked. They want to frame the question and control the answer.<br /><br />They have now resorted to name calling.  They don't want to answer the question and they don't want other members of the club to hear that there is a question being asked.  Actually, I would prefer that they stop responding as their responses assume that I want the question answered by them in this forum.  <br /><br />They have made it clear that they are not interested in answering the question and that is fine.  However, I think that it important that other club members see that there is a question that remains to be answered:<br /><br />I have read over the new &quot;Fellow Feather Application for hang gliding permit&quot; and I am concerned about the changes to the form. Below the line where the Pilot's Signature is Required to complete the application, a line has been added, &quot;This member stipulates by signature that for purpose of notice, official notification shall be...&quot;.<br /><br />Since, There is NO RECORD of this change in the Club Minutes <img src="images/smilies/icon_redface.gif" alt=":oops:" title="Embarassed" /> <!-- l --><a class="postlink-local" href="viewforum12a3.html?f=2">viewforum.php?f=2</a><!-- l --><br /><br />WHO is responsible for the changes to the Application form that took place without club discussion?<br /><br />Every Joe wants to know.<br />Sincerely,<br />e j</div>

			

		</div>

		
			<dl class="postprofile" id="profile2387">
			<dt>
				<a href="memberlist9c48.php?mode=viewprofile&amp;u=1873">e j</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 11</dd><dd><strong>Joined:</strong> Tue Dec 28, 2010 7:16 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2388" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postingb0dd.html?mode=quote&amp;f=5&amp;p=2388" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2388">Re: New Funston Clubhouse Notice Rule</a></h3>
			<p class="author"><a href="viewtopicf75b.php?p=2388#p2388"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberliste1b6.html?mode=viewprofile&amp;u=1877">thermal pirate</a></strong> &raquo; Tue Jan 04, 2011 2:42 pm </p>

			

			<div class="content">Hey ej, buddy, dont get me wrong, I totally get why you like nobody to know who you are online, I happen to like being able to speak my mind too without having to be PC and all.  Thats how you and me get to have this fun conversation! But as a covert renegade, at least I’m smart enough to know better than to post serious questions and expect a serious answer. You gotta get that concept through your skull or youre gonna be one frustrated muther efer!<br /><br />Seriously dude, heres a little tip from your pirate friend... if you really have such a high and mighty interest, go off line and ask Steve directly. You got him pinned down because he says he knows it all  and already said he would tell you. Then you can do this huge service you are all bent out of shape about and tell all us other Joes what he said! Is that simple enough for you or are you retarded?<br /><br />Either that or STFU for now and go to the meeting and ask as many questions as you want there because it looks pretty clear that you aint gonna get it here staying all undercover and s**T.<br />I’m not calling you names but you should pay more attention to what our cousin Forrest said... Stupid is as stupid does!</div>

			

		</div>

		
			<dl class="postprofile" id="profile2388">
			<dt>
				<a href="memberliste1b6.html?mode=viewprofile&amp;u=1877">thermal pirate</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 10</dd><dd><strong>Joined:</strong> Mon Jan 03, 2011 3:12 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<form id="viewtopic" method="post" action="http://flyfunston.org/bbs/viewtopic.php?f=5&amp;t=1079">

	<fieldset class="display-options" style="margin-top: 0; ">
		<a href="viewtopic384b.html?f=5&amp;t=1079&amp;start=25" class="right-box right">Next</a>
		<label>Display posts from previous: <select name="st" id="st"><option value="0" selected="selected">All posts</option><option value="1">1 day</option><option value="7">7 days</option><option value="14">2 weeks</option><option value="30">1 month</option><option value="90">3 months</option><option value="180">6 months</option><option value="365">1 year</option></select></label>
		<label>Sort by <select name="sk" id="sk"><option value="a">Author</option><option value="t" selected="selected">Post time</option><option value="s">Subject</option></select></label> <label><select name="sd" id="sd"><option value="a" selected="selected">Ascending</option><option value="d">Descending</option></select> <input type="submit" name="sort" value="Go" class="button2" /></label>
		
	</fieldset>

	</form>
	<hr />


<div class="topic-actions">
	<div class="buttons">
	
		<div class="reply-icon"><a href="postingd75a.html?mode=reply&amp;f=5&amp;t=1079" title="Post a reply"><span></span>Post a reply</a></div>
	
	</div>

	
		<div class="pagination">
			30 posts
			 &bull; <a href="#" onclick="jumpto(); return false;" title="Click to jump to page…">Page <strong>1</strong> of <strong>2</strong></a> &bull; <span><strong>1</strong><span class="page-sep">, </span><a href="viewtopic384b.html?f=5&amp;t=1079&amp;start=25">2</a></span>
		</div>
	
</div>


	<p></p><p><a href="viewforume774.html?f=5" class="left-box left" accesskey="r">Return to General Discussion</a></p>

	<form method="post" id="jumpbox" action="http://flyfunston.org/bbs/viewforum.php" onsubmit="if(this.f.value == -1){return false;}">

	
		<fieldset class="jumpbox">
	
			<label for="f" accesskey="j">Jump to:</label>
			<select name="f" id="f" onchange="if(this.options[this.selectedIndex].value != -1){ document.forms['jumpbox'].submit() }">
			
				<option value="-1">Select a forum</option>
			<option value="-1">------------------</option>
				<option value="9">Discussion Groups</option>
			
				<option value="5" selected="selected">&nbsp; &nbsp;General Discussion</option>
			
				<option value="8">&nbsp; &nbsp;Announcements</option>
			
				<option value="7">&nbsp; &nbsp;For Sale/Wanted</option>
			
				<option value="6">&nbsp; &nbsp;Road Trips</option>
			
				<option value="2">&nbsp; &nbsp;Meeting Minutes and Treasurer Reports</option>
			
				<option value="11">&nbsp; &nbsp;Off Topic</option>
			
			</select>
			<input type="submit" value="Go" class="button2" />
		</fieldset>
	</form>


	<h3>Who is online</h3>
	<p>Users browsing this forum: <span style="color: #9E8DA7;" class="username-coloured">Google [Bot]</span> and 7 guests</p>
</div>

<div id="page-footer">

	<div class="navbar">
		<div class="inner"><span class="corners-top"><span></span></span>

		<ul class="linklist">
			<li class="icon-home"><a href="index.html">Board index</a></li>
				
			<li class="rightside"><a href="memberlista2f5.html?mode=leaders">The team</a> &bull; <a href="ucp033a.html?mode=delete_cookies">Delete all board cookies</a> &bull; All times are UTC - 8 hours [ <abbr title="Daylight Saving Time">DST</abbr> ]</li>
		</ul>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<div class="copyright">Powered by <a href="https://www.phpbb.com/">phpBB</a>&reg; Forum Software &copy; phpBB Group
		
	</div>
</div>

</div>

<div>
	<a id="bottom" name="bottom" accesskey="z"></a>
	
</div>

</body>

<!-- Mirrored from flyfunston.org/bbs/viewtopic.php?p=2359 by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 08 Aug 2021 20:14:43 GMT -->
</html>