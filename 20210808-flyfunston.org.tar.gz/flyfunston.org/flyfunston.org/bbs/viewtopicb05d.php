<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en-us" xml:lang="en-us">

<!-- Mirrored from flyfunston.org/bbs/viewtopic.php?p=3174 by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 08 Aug 2021 19:48:05 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>

<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<meta http-equiv="content-style-type" content="text/css" />
<meta http-equiv="content-language" content="en-us" />
<meta http-equiv="imagetoolbar" content="no" />
<meta name="resource-type" content="document" />
<meta name="distribution" content="global" />
<meta name="keywords" content="" />
<meta name="description" content="" />

<title>Flyfunston &bull; View topic - Fort Funston Air Races 2012</title>



<!--
	phpBB style name: prosilver
	Based on style:   prosilver (this is the default phpBB3 style)
	Original author:  Tom Beddard ( http://www.subBlue.com/ )
	Modified by:
-->

<script type="text/javascript">
// <![CDATA[
	var jump_page = 'Enter the page number you wish to go to:';
	var on_page = '1';
	var per_page = '';
	var base_url = '';
	var style_cookie = 'phpBBstyle';
	var style_cookie_settings = '; path=/; domain=flyfunston.org; secure';
	var onload_functions = new Array();
	var onunload_functions = new Array();

	

	/**
	* Find a member
	*/
	function find_username(url)
	{
		popup(url, 760, 570, '_usersearch');
		return false;
	}

	/**
	* New function for handling multiple calls to window.onload and window.unload by pentapenguin
	*/
	window.onload = function()
	{
		for (var i = 0; i < onload_functions.length; i++)
		{
			eval(onload_functions[i]);
		}
	};

	window.onunload = function()
	{
		for (var i = 0; i < onunload_functions.length; i++)
		{
			eval(onunload_functions[i]);
		}
	};

// ]]>
</script>
<script type="text/javascript" src="styles/prosilver/template/styleswitcher.js"></script>
<script type="text/javascript" src="styles/prosilver/template/forum_fn.js"></script>

<link href="styles/prosilver/theme/print.css" rel="stylesheet" type="text/css" media="print" title="printonly" />
<link href="style7a95.css?id=1&amp;lang=en_us" rel="stylesheet" type="text/css" media="screen, projection" />

<link href="styles/prosilver/theme/normal.css" rel="stylesheet" type="text/css" title="A" />
<link href="styles/prosilver/theme/medium.css" rel="alternate stylesheet" type="text/css" title="A+" />
<link href="styles/prosilver/theme/large.css" rel="alternate stylesheet" type="text/css" title="A++" />



</head>

<body id="phpbb" class="section-viewtopic ltr">

<div id="wrap">
	<a id="top" name="top" accesskey="t"></a>
	<div id="page-header">
		<div class="headerbar">
			<div class="inner"><span class="corners-top"><span></span></span>

			<div id="site-description">
				<a href="index.html" title="Board index" id="logo"><img src="styles/prosilver/imageset/site_logo.gif" width="149" height="52" alt="" title="" /></a>
				<h1>Flyfunston</h1>
				<p>Hang Gliding at Fort Funston</p>
				<p class="skiplink"><a href="#start_here">Skip to content</a></p>
			</div>

		
			<div id="search-box">
				<form action="http://flyfunston.org/bbs/search.php" method="get" id="search">
				<fieldset>
					<input name="keywords" id="keywords" type="text" maxlength="128" title="Search for keywords" class="inputbox search" value="Search…" onclick="if(this.value=='Search…')this.value='';" onblur="if(this.value=='')this.value='Search…';" />
					<input class="button2" value="Search" type="submit" /><br />
					<a href="search.html" title="View the advanced search options">Advanced search</a> 
				</fieldset>
				</form>
			</div>
		

			<span class="corners-bottom"><span></span></span></div>
		</div>

		<div class="navbar">
			<div class="inner"><span class="corners-top"><span></span></span>

			<ul class="linklist navlinks">
				<li class="icon-home"><a href="index.html" accesskey="h">Board index</a>  <strong>&#8249;</strong> <a href="viewforumfdc5.html?f=9">Discussion Groups</a> <strong>&#8249;</strong> <a href="viewforume774.html?f=5">General Discussion</a></li>

				<li class="rightside"><a href="#" onclick="fontsizeup(); return false;" onkeypress="return fontsizeup(event);" class="fontsize" title="Change font size">Change font size</a></li>

				<li class="rightside"><a href="viewtopic3bd8.html?f=5&amp;t=1332&amp;view=print" title="Print view" accesskey="p" class="print">Print view</a></li>
			</ul>

			

			<ul class="linklist rightside">
				<li class="icon-faq"><a href="faq.html" title="Frequently Asked Questions">FAQ</a></li>
				
					<li class="icon-logout"><a href="ucp26c3.php?mode=login" title="Login" accesskey="x">Login</a></li>
				
			</ul>

			<span class="corners-bottom"><span></span></span></div>
		</div>

	</div>

	<a name="start_here"></a>
	<div id="page-body">
		
<h2><a href="viewtopic5ec2.html?f=5&amp;t=1332">Fort Funston Air Races 2012</a></h2>
<!-- NOTE: remove the style="display: none" when you want to have the forum description on the topic body --><div style="display: none !important;">Talk about Hang Gliding at Ft Funston and the Fellow Feathers Club.<br /></div>

<div class="topic-actions">

	<div class="buttons">
	
		<div class="reply-icon"><a href="posting98bc.html?mode=reply&amp;f=5&amp;t=1332" title="Post a reply"><span></span>Post a reply</a></div>
	
	</div>

	
		<div class="search-box">
			<form method="get" id="topic-search" action="http://flyfunston.org/bbs/search.php">
			<fieldset>
				<input class="inputbox search tiny"  type="text" name="keywords" id="search_keywords" size="20" value="Search this topic…" onclick="if(this.value=='Search this topic…')this.value='';" onblur="if(this.value=='')this.value='Search this topic…';" />
				<input class="button2" type="submit" value="Search" />
				<input type="hidden" name="t" value="1332" />
<input type="hidden" name="sf" value="msgonly" />

			</fieldset>
			</form>
		</div>
	
		<div class="pagination">
			13 posts
			 &bull; Page <strong>1</strong> of <strong>1</strong>
		</div>
	

</div>
<div class="clear"></div>


	<div id="p3158" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting055c.html?mode=quote&amp;f=5&amp;p=3158" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 class="first"><a href="#p3158">Fort Funston Air Races 2012</a></h3>
			<p class="author"><a href="viewtopic1538.html?p=3158#p3158"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist8ddf.html?mode=viewprofile&amp;u=1811">tom rust</a></strong> &raquo; Sat Jul 21, 2012 1:06 pm </p>

			

			<div class="content">I've emailed members a short questionaire to assist us in planning for this event.<br />Please take a moment and respond.<br />If you didnt get it, let me know what dates you prefer for the event and if your willing to help.<br />Thanks!</div>

			

		</div>

		
			<dl class="postprofile" id="profile3158">
			<dt>
				<a href="memberlist8ddf.html?mode=viewprofile&amp;u=1811">tom rust</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 49</dd><dd><strong>Joined:</strong> Wed Nov 03, 2010 11:36 am</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3159" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting4eee.html?mode=quote&amp;f=5&amp;p=3159" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3159">Re: Fort Funston Air Races 2012</a></h3>
			<p class="author"><a href="viewtopic5438.php?p=3159#p3159"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlistfe9c.html?mode=viewprofile&amp;u=3">Daniel Pifko</a></strong> &raquo; Sun Jul 22, 2012 12:49 pm </p>

			

			<div class="content">Hi Tom,<br /><br />Why not just post the survey here? There are many pilots who fly Funston but who are not members.  <br /><br />Thanks,<br /><br />Daniel</div>

			

		</div>

		
			<dl class="postprofile" id="profile3159">
			<dt>
				<a href="memberlistfe9c.html?mode=viewprofile&amp;u=3"><img src="http://www.pifko.com/fly/images/avatar.jpg" width="60" height="80" alt="User avatar" /></a><br />
				<a href="memberlistfe9c.html?mode=viewprofile&amp;u=3">Daniel Pifko</a>
			</dt>

			<dd>Site Admin</dd>

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 249</dd><dd><strong>Joined:</strong> Tue Jan 13, 2004 5:23 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3161" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting93b1.html?mode=quote&amp;f=5&amp;p=3161" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3161">Re: Fort Funston Air Races 2012</a></h3>
			<p class="author"><a href="viewtopiced28.php?p=3161#p3161"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlistd0bb.php?mode=viewprofile&amp;u=1552">sporty155</a></strong> &raquo; Sun Jul 22, 2012 10:19 pm </p>

			

			<div class="content">I agree... Might have more volunteers that way..?</div>

			

		</div>

		
			<dl class="postprofile" id="profile3161">
			<dt>
				<a href="memberlistd0bb.php?mode=viewprofile&amp;u=1552">sporty155</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 127</dd><dd><strong>Joined:</strong> Sat Feb 28, 2009 2:04 am</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3162" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting96b9.html?mode=quote&amp;f=5&amp;p=3162" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3162">Re: Fort Funston Air Races 2012</a></h3>
			<p class="author"><a href="viewtopic4377-2.html?p=3162#p3162"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist7aa3.html?mode=viewprofile&amp;u=129">crvalley</a></strong> &raquo; Mon Jul 23, 2012 8:46 am </p>

			

			<div class="content">...</div>

			
				<div class="notice">Last edited by <a href="memberlist7aa3.html?mode=viewprofile&amp;u=129">crvalley</a> on Wed Jul 25, 2012 5:11 pm, edited 1 time in total.
					
				</div>
			<div id="sig3162" class="signature">“We abuse land because we see it as a commodity belonging to us. When we see land as a community to which we belong, we may begin to use it with love and respect.” ― Aldo Leopold</div>

		</div>

		
			<dl class="postprofile" id="profile3162">
			<dt>
				<a href="memberlist7aa3.html?mode=viewprofile&amp;u=129">crvalley</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 214</dd><dd><strong>Joined:</strong> Sun Apr 10, 2005 9:16 am</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3168" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postingac39.html?mode=quote&amp;f=5&amp;p=3168" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3168">Re: Fort Funston Air Races 2012</a></h3>
			<p class="author"><a href="viewtopic9a18.html?p=3168#p3168"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlistf276.html?mode=viewprofile&amp;u=2064">jimmyanderson45</a></strong> &raquo; Tue Jul 24, 2012 10:53 pm </p>

			

			<div class="content"><img src="images/smilies/icon_biggrin.html" alt=":D" title="Very Happy" /> Depending on the day that is chosen, I'll volunteer to be the Westlake turnpoint dude. <img src="images/smilies/icon_lol.gif" alt=":lol:" title="Laughing" /></div>

			<div id="sig3168" class="signature">Alex...</div>

		</div>

		
			<dl class="postprofile" id="profile3168">
			<dt>
				<a href="memberlistf276.html?mode=viewprofile&amp;u=2064">jimmyanderson45</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 1</dd><dd><strong>Joined:</strong> Tue Jul 24, 2012 10:00 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3170" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postingab22.html?mode=quote&amp;f=5&amp;p=3170" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3170">Re: Fort Funston Air Races 2012</a></h3>
			<p class="author"><a href="viewtopic3655.html?p=3170#p3170"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944">bobk</a></strong> &raquo; Wed Jul 25, 2012 9:28 am </p>

			

			<div class="content"><blockquote><div><cite>Daniel Pifko wrote:</cite>Why not just post the survey here? There are many pilots who fly Funston but who are not members. </div></blockquote><br />Ditto.<br /><br />I'm mostly in San Diego, but I participated in the races a few years ago when I was passing through. I'm not much of a competitor (sunk out on the way to Westlake in my Falcon), but I didn't mind participating to help the club.<br /><br />Funston is a national treasure for hang gliding, and I think it would be good for the club to think in those terms.  <img src="images/smilies/icon_smile.html" alt=":)" title="Smile" /><br /><br />As far as myself, my only major commitment is to our Torrey Hawks &quot;Second Sunday&quot; fly-ins which happen on the second Sunday of each month (August 12th, September 9th, October 14th, November 11th, and December 9th). So any days other than those are best for me. If the timing is right, I might be able to volunteer to help out during the event as well.</div>

			<div id="sig3170" class="signature"><span style="font-size: 130%; line-height: 116%;"><span style="color: #000080"><span style="font-style: italic">Join a National Hang Gliding Organization:</span></span> <span style="font-weight: bold"><span style="color: #000080"><a href="http://ushawks.org/" class="postlink">US Hawks at ushawks.org</a></span></span></span></div>

		</div>

		
			<dl class="postprofile" id="profile3170">
			<dt>
				<a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944"><img src="download/file3928.html?avatar=1944_1390380842.jpeg" width="200" height="150" alt="User avatar" /></a><br />
				<a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944">bobk</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 138</dd><dd><strong>Joined:</strong> Tue Mar 22, 2011 1:53 pm</dd>
			<dd>
				<ul class="profile-icons">
					<li class="web-icon"><a href="http://ushawks.org/" title="WWW: http://ushawks.org"><span>Website</span></a></li>
				</ul>
			</dd>
		

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3174" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting7604.html?mode=quote&amp;f=5&amp;p=3174" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3174">Re: Fort Funston Air Races 2012</a></h3>
			<p class="author"><a href="viewtopicb05d.php?p=3174#p3174"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlistd0bb.php?mode=viewprofile&amp;u=1552">sporty155</a></strong> &raquo; Thu Aug 02, 2012 10:41 pm </p>

			

			<div class="content">Ok...??  So is there a date set yet? <br />Please confirm...</div>

			

		</div>

		
			<dl class="postprofile" id="profile3174">
			<dt>
				<a href="memberlistd0bb.php?mode=viewprofile&amp;u=1552">sporty155</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 127</dd><dd><strong>Joined:</strong> Sat Feb 28, 2009 2:04 am</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3175" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting03ef.html?mode=quote&amp;f=5&amp;p=3175" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3175">Re: Fort Funston Air Races 2012</a></h3>
			<p class="author"><a href="viewtopice0de.html?p=3175#p3175"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist8ddf.html?mode=viewprofile&amp;u=1811">tom rust</a></strong> &raquo; Sat Aug 04, 2012 11:12 am </p>

			

			<div class="content">Primary date set for August 25th, Saturday. If unflyable, Sunday the 26th. We had 10 volunteers with a good mix, so think we're set on help. Thanks to all who responded!<br />We'll discuss furthur at club meeting on the 14th. Joe V has designed a sweet T-shirt - let us know your T-shirt size request ASAP so we can get in the correct order in the next few days.<br />Thanks!</div>

			

		</div>

		
			<dl class="postprofile" id="profile3175">
			<dt>
				<a href="memberlist8ddf.html?mode=viewprofile&amp;u=1811">tom rust</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 49</dd><dd><strong>Joined:</strong> Wed Nov 03, 2010 11:36 am</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3178" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postingfd2a.php?mode=quote&amp;f=5&amp;p=3178" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3178">Re: Fort Funston Air Races 2012</a></h3>
			<p class="author"><a href="viewtopic8372.html?p=3178#p3178"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist2501.html?mode=viewprofile&amp;u=41">diev</a></strong> &raquo; Tue Aug 07, 2012 12:47 pm </p>

			

			<div class="content">One shirt for me please = XL<br />Thanks<br />Diev</div>

			<div id="sig3178" class="signature">Diev Hart<br />KG6UST<br /><!-- m --><a class="postlink" href="http://www.dievhart.com/hangglide.html">http://www.dievhart.com/hangglide.html</a><!-- m --></div>

		</div>

		
			<dl class="postprofile" id="profile3178">
			<dt>
				<a href="memberlist2501.html?mode=viewprofile&amp;u=41">diev</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 253</dd><dd><strong>Joined:</strong> Tue Sep 28, 2004 1:40 pm</dd><dd><strong>Location:</strong> Santa Cruz, CA</dd>
			<dd>
				<ul class="profile-icons">
					<li class="web-icon"><a href="http://www.dievhart.com/hangglide.html" title="WWW: http://www.dievhart.com/hangglide.html"><span>Website</span></a></li><li class="yahoo-icon"><a href="http://edit.yahoo.com/config/send_webmesg?.target=dievhart&amp;.src=pg" onclick="popup(this.href, 780, 550); return false;" title="YIM"><span>YIM</span></a></li>
				</ul>
			</dd>
		

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3206" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting1fb1.html?mode=quote&amp;f=5&amp;p=3206" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3206">Air Races Times</a></h3>
			<p class="author"><a href="viewtopic4163.php?p=3206#p3206"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist8ddf.html?mode=viewprofile&amp;u=1811">tom rust</a></strong> &raquo; Mon Aug 27, 2012 10:56 am </p>

			

			<div class="content">I asked the pilots if they wanted their time sheets back at the races, and some of them did, so I don't have all the times. But here are the ones I have, ordered fastest to slowest for each category:<br />rigid<br />brian porter	4:06<br />brian porter	4:06<br />Darrell robbins	4:11<br />Darrell robbins	4:18<br />stephen morris	5:09<br />Darrell robbins	5:13<br />stephen morris	5:30<br />stephen morris	5:36<br /><br />topless<br />zac majors		4:58<br />zac majors		5:02<br />brian horgan		5:08<br />brian horgan		5:22<br />ben dunn		5:22<br />ward carter		5:38<br />ben dunn		5:39<br />ben dunn		5:45<br />John taylor		5:48<br />John taylor		5:52<br />wayne michelson		6:03<br />John taylor		6:11<br />don martin		6:20<br />charlie nelson		6:24<br />peter welch		6:30<br />charlie nelson		6:30<br />peter welch		6:36<br />karl allmendinger		6:49<br /><br />kingpost<br />ken brown			6:12<br />ben dunn			6:23<br />brian foster			6:26<br />joey fresquez			6:39<br />brian foster			6:40<br />brian foster			7:02<br />brian foster			7:08<br />ben dunn			7:10<br />brad martin			7:12<br />zach hazen			7:14<br />brad martin			7:15<br />bob shelton			7:33<br />brad martin			7:35<br />zach hazen			7:43<br />terry strahl			7:44<br />alex wright			8:14<br />carmela moreno			10:03<br />terry strahl			10:28<br /><br />single surface<br />mark mulholland				9:42</div>

			

		</div>

		
			<dl class="postprofile" id="profile3206">
			<dt>
				<a href="memberlist8ddf.html?mode=viewprofile&amp;u=1811">tom rust</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 49</dd><dd><strong>Joined:</strong> Wed Nov 03, 2010 11:36 am</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3207" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postingd162.html?mode=quote&amp;f=5&amp;p=3207" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3207">Re: Fort Funston Air Races 2012</a></h3>
			<p class="author"><a href="viewtopicb140.php?p=3207#p3207"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist1d1f.html?mode=viewprofile&amp;u=1996">flyzguy</a></strong> &raquo; Mon Aug 27, 2012 10:59 am </p>

			

			<div class="content">Thanks for posting the times!<br /><br />Was there going to be another T-shirt order?  I missed out on my XL and would love to get one.  <br /><br />~Zach</div>

			

		</div>

		
			<dl class="postprofile" id="profile3207">
			<dt>
				<a href="memberlist1d1f.html?mode=viewprofile&amp;u=1996">flyzguy</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 2</dd><dd><strong>Joined:</strong> Sun Aug 07, 2011 1:58 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3208" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postinge30c.html?mode=quote&amp;f=5&amp;p=3208" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3208">Re: Fort Funston Air Races 2012</a></h3>
			<p class="author"><a href="viewtopicfaac.html?p=3208#p3208"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist532f.html?mode=viewprofile&amp;u=1933">hbittner</a></strong> &raquo; Mon Aug 27, 2012 8:50 pm </p>

			

			<div class="content">Hey Tom, <br /><br />You forgot my 5:17 time and Kenny's time 5:16 and 5:18<br /><br />Im in for an XL shirt as well!! and even a very small one for Thor!!<br /><br />Thanks for making this happen it was great to see everyone out there<br /><br />Henry</div>

			

		</div>

		
			<dl class="postprofile" id="profile3208">
			<dt>
				<a href="memberlist532f.html?mode=viewprofile&amp;u=1933">hbittner</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 16</dd><dd><strong>Joined:</strong> Fri Feb 04, 2011 5:06 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3218" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting0e25.html?mode=quote&amp;f=5&amp;p=3218" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3218">Re: Fort Funston Air Races 2012</a></h3>
			<p class="author"><a href="viewtopicaaba.html?p=3218#p3218"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist3c69.html?mode=viewprofile&amp;u=2079">Xander</a></strong> &raquo; Tue Sep 11, 2012 10:54 pm </p>

			

			<div class="content">Thanks for the great event.   I ordered an XL T-shirt, but I haven't seen any info about when to pick it up.  Did I miss the second batch too?!<br /><br />-Alex Wright</div>

			

		</div>

		
			<dl class="postprofile" id="profile3218">
			<dt>
				<a href="memberlist3c69.html?mode=viewprofile&amp;u=2079">Xander</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 1</dd><dd><strong>Joined:</strong> Mon Sep 10, 2012 10:15 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<form id="viewtopic" method="post" action="http://flyfunston.org/bbs/viewtopic.php?f=5&amp;t=1332">

	<fieldset class="display-options" style="margin-top: 0; ">
		
		<label>Display posts from previous: <select name="st" id="st"><option value="0" selected="selected">All posts</option><option value="1">1 day</option><option value="7">7 days</option><option value="14">2 weeks</option><option value="30">1 month</option><option value="90">3 months</option><option value="180">6 months</option><option value="365">1 year</option></select></label>
		<label>Sort by <select name="sk" id="sk"><option value="a">Author</option><option value="t" selected="selected">Post time</option><option value="s">Subject</option></select></label> <label><select name="sd" id="sd"><option value="a" selected="selected">Ascending</option><option value="d">Descending</option></select> <input type="submit" name="sort" value="Go" class="button2" /></label>
		
	</fieldset>

	</form>
	<hr />


<div class="topic-actions">
	<div class="buttons">
	
		<div class="reply-icon"><a href="posting98bc.html?mode=reply&amp;f=5&amp;t=1332" title="Post a reply"><span></span>Post a reply</a></div>
	
	</div>

	
		<div class="pagination">
			13 posts
			 &bull; Page <strong>1</strong> of <strong>1</strong>
		</div>
	
</div>


	<p></p><p><a href="viewforume774.html?f=5" class="left-box left" accesskey="r">Return to General Discussion</a></p>

	<form method="post" id="jumpbox" action="http://flyfunston.org/bbs/viewforum.php" onsubmit="if(this.f.value == -1){return false;}">

	
		<fieldset class="jumpbox">
	
			<label for="f" accesskey="j">Jump to:</label>
			<select name="f" id="f" onchange="if(this.options[this.selectedIndex].value != -1){ document.forms['jumpbox'].submit() }">
			
				<option value="-1">Select a forum</option>
			<option value="-1">------------------</option>
				<option value="9">Discussion Groups</option>
			
				<option value="5" selected="selected">&nbsp; &nbsp;General Discussion</option>
			
				<option value="8">&nbsp; &nbsp;Announcements</option>
			
				<option value="7">&nbsp; &nbsp;For Sale/Wanted</option>
			
				<option value="6">&nbsp; &nbsp;Road Trips</option>
			
				<option value="2">&nbsp; &nbsp;Meeting Minutes and Treasurer Reports</option>
			
				<option value="11">&nbsp; &nbsp;Off Topic</option>
			
			</select>
			<input type="submit" value="Go" class="button2" />
		</fieldset>
	</form>


	<h3>Who is online</h3>
	<p>Users browsing this forum: No registered users and 7 guests</p>
</div>

<div id="page-footer">

	<div class="navbar">
		<div class="inner"><span class="corners-top"><span></span></span>

		<ul class="linklist">
			<li class="icon-home"><a href="index.html">Board index</a></li>
				
			<li class="rightside"><a href="memberlista2f5.html?mode=leaders">The team</a> &bull; <a href="ucp033a.html?mode=delete_cookies">Delete all board cookies</a> &bull; All times are UTC - 8 hours [ <abbr title="Daylight Saving Time">DST</abbr> ]</li>
		</ul>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<div class="copyright">Powered by <a href="https://www.phpbb.com/">phpBB</a>&reg; Forum Software &copy; phpBB Group
		
	</div>
</div>

</div>

<div>
	<a id="bottom" name="bottom" accesskey="z"></a>
	
</div>

</body>

<!-- Mirrored from flyfunston.org/bbs/viewtopic.php?p=3174 by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 08 Aug 2021 19:48:05 GMT -->
</html>