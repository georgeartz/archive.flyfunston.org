<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en-us" xml:lang="en-us">

<!-- Mirrored from flyfunston.org/bbs/viewtopic.php?p=1701 by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 08 Aug 2021 20:18:28 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>

<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<meta http-equiv="content-style-type" content="text/css" />
<meta http-equiv="content-language" content="en-us" />
<meta http-equiv="imagetoolbar" content="no" />
<meta name="resource-type" content="document" />
<meta name="distribution" content="global" />
<meta name="keywords" content="" />
<meta name="description" content="" />

<title>Flyfunston &bull; View topic - Noob Question</title>



<!--
	phpBB style name: prosilver
	Based on style:   prosilver (this is the default phpBB3 style)
	Original author:  Tom Beddard ( http://www.subBlue.com/ )
	Modified by:
-->

<script type="text/javascript">
// <![CDATA[
	var jump_page = 'Enter the page number you wish to go to:';
	var on_page = '1';
	var per_page = '';
	var base_url = '';
	var style_cookie = 'phpBBstyle';
	var style_cookie_settings = '; path=/; domain=flyfunston.org; secure';
	var onload_functions = new Array();
	var onunload_functions = new Array();

	

	/**
	* Find a member
	*/
	function find_username(url)
	{
		popup(url, 760, 570, '_usersearch');
		return false;
	}

	/**
	* New function for handling multiple calls to window.onload and window.unload by pentapenguin
	*/
	window.onload = function()
	{
		for (var i = 0; i < onload_functions.length; i++)
		{
			eval(onload_functions[i]);
		}
	};

	window.onunload = function()
	{
		for (var i = 0; i < onunload_functions.length; i++)
		{
			eval(onunload_functions[i]);
		}
	};

// ]]>
</script>
<script type="text/javascript" src="styles/prosilver/template/styleswitcher.js"></script>
<script type="text/javascript" src="styles/prosilver/template/forum_fn.js"></script>

<link href="styles/prosilver/theme/print.css" rel="stylesheet" type="text/css" media="print" title="printonly" />
<link href="style7a95.css?id=1&amp;lang=en_us" rel="stylesheet" type="text/css" media="screen, projection" />

<link href="styles/prosilver/theme/normal.css" rel="stylesheet" type="text/css" title="A" />
<link href="styles/prosilver/theme/medium.css" rel="alternate stylesheet" type="text/css" title="A+" />
<link href="styles/prosilver/theme/large.css" rel="alternate stylesheet" type="text/css" title="A++" />



</head>

<body id="phpbb" class="section-viewtopic ltr">

<div id="wrap">
	<a id="top" name="top" accesskey="t"></a>
	<div id="page-header">
		<div class="headerbar">
			<div class="inner"><span class="corners-top"><span></span></span>

			<div id="site-description">
				<a href="index.html" title="Board index" id="logo"><img src="styles/prosilver/imageset/site_logo.gif" width="149" height="52" alt="" title="" /></a>
				<h1>Flyfunston</h1>
				<p>Hang Gliding at Fort Funston</p>
				<p class="skiplink"><a href="#start_here">Skip to content</a></p>
			</div>

		
			<div id="search-box">
				<form action="http://flyfunston.org/bbs/search.php" method="get" id="search">
				<fieldset>
					<input name="keywords" id="keywords" type="text" maxlength="128" title="Search for keywords" class="inputbox search" value="Search…" onclick="if(this.value=='Search…')this.value='';" onblur="if(this.value=='')this.value='Search…';" />
					<input class="button2" value="Search" type="submit" /><br />
					<a href="search.html" title="View the advanced search options">Advanced search</a> 
				</fieldset>
				</form>
			</div>
		

			<span class="corners-bottom"><span></span></span></div>
		</div>

		<div class="navbar">
			<div class="inner"><span class="corners-top"><span></span></span>

			<ul class="linklist navlinks">
				<li class="icon-home"><a href="index.html" accesskey="h">Board index</a>  <strong>&#8249;</strong> <a href="viewforumfdc5.html?f=9">Discussion Groups</a> <strong>&#8249;</strong> <a href="viewforume774.html?f=5">General Discussion</a></li>

				<li class="rightside"><a href="#" onclick="fontsizeup(); return false;" onkeypress="return fontsizeup(event);" class="fontsize" title="Change font size">Change font size</a></li>

				<li class="rightside"><a href="viewtopicd346.html?f=5&amp;t=817&amp;view=print" title="Print view" accesskey="p" class="print">Print view</a></li>
			</ul>

			

			<ul class="linklist rightside">
				<li class="icon-faq"><a href="faq.html" title="Frequently Asked Questions">FAQ</a></li>
				
					<li class="icon-logout"><a href="ucp26c3.php?mode=login" title="Login" accesskey="x">Login</a></li>
				
			</ul>

			<span class="corners-bottom"><span></span></span></div>
		</div>

	</div>

	<a name="start_here"></a>
	<div id="page-body">
		
<h2><a href="viewtopic4811.php?f=5&amp;t=817">Noob Question</a></h2>
<!-- NOTE: remove the style="display: none" when you want to have the forum description on the topic body --><div style="display: none !important;">Talk about Hang Gliding at Ft Funston and the Fellow Feathers Club.<br /></div>

<div class="topic-actions">

	<div class="buttons">
	
		<div class="reply-icon"><a href="posting881a.html?mode=reply&amp;f=5&amp;t=817" title="Post a reply"><span></span>Post a reply</a></div>
	
	</div>

	
		<div class="search-box">
			<form method="get" id="topic-search" action="http://flyfunston.org/bbs/search.php">
			<fieldset>
				<input class="inputbox search tiny"  type="text" name="keywords" id="search_keywords" size="20" value="Search this topic…" onclick="if(this.value=='Search this topic…')this.value='';" onblur="if(this.value=='')this.value='Search this topic…';" />
				<input class="button2" type="submit" value="Search" />
				<input type="hidden" name="t" value="817" />
<input type="hidden" name="sf" value="msgonly" />

			</fieldset>
			</form>
		</div>
	
		<div class="pagination">
			6 posts
			 &bull; Page <strong>1</strong> of <strong>1</strong>
		</div>
	

</div>
<div class="clear"></div>


	<div id="p1686" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting907a.html?mode=quote&amp;f=5&amp;p=1686" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 class="first"><a href="#p1686">Noob Question</a></h3>
			<p class="author"><a href="viewtopic08ac.html?p=1686#p1686"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist65aa.html?mode=viewprofile&amp;u=1606">amouramis</a></strong> &raquo; Mon Aug 17, 2009 3:43 pm </p>

			

			<div class="content">I'm just getting into hang gliding (learning everyday!! ) an I don't have a glider or the big $$$ for it, but I found some hang gliders for sale and they have 1 advanced one for $1300 and the novice ones for $1100.  Assuming I'm a fast learner and use the training hill instead of tandems to learn which one should I spend my hard earned whole pay check on?  What's the rating scale for how 'difficult' a glider is establish from?  What's the difference between the gliders shown for sale? (ginormous link below)
<br />
<br /><!-- m --><a class="postlink" href="http://store.kittyhawk.com/listItems.asp?displayType=Across&amp;Cat=HGMAIN&amp;CatDesc=Hang%20Gliding%20Gear&amp;SubCat=HGGLIDERS&amp;SubCatDesc=Hang%20Gliders&amp;T1=USEDHANGS&amp;SubSubCatDesc=Used%20Hang%20Gliders&amp;Search=Link">http://store.kittyhawk.com/listItems.as ... earch=Link</a><!-- m -->
<br />
<br />PS
<br />I'm an idiot and didn't realize you guys are on the other coast.  Fast physical learner, not the brain type.</div>

			

		</div>

		
			<dl class="postprofile" id="profile1686">
			<dt>
				<a href="memberlist65aa.html?mode=viewprofile&amp;u=1606">amouramis</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 2</dd><dd><strong>Joined:</strong> Fri Aug 14, 2009 2:20 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p1688" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting5c64.html?mode=quote&amp;f=5&amp;p=1688" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p1688">glider to buy</a></h3>
			<p class="author"><a href="viewtopic7321.html?p=1688#p1688"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist5cee.html?mode=viewprofile&amp;u=154">cliffblack</a></strong> &raquo; Tue Aug 18, 2009 1:24 am </p>

			

			<div class="content">buy the $1100 Falcon and get some wheels, hire an instructor and practice!  good luck</div>

			<div id="sig1688" class="signature">Tom</div>

		</div>

		
			<dl class="postprofile" id="profile1688">
			<dt>
				<a href="memberlist5cee.html?mode=viewprofile&amp;u=154">cliffblack</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 103</dd><dd><strong>Joined:</strong> Mon May 30, 2005 11:54 am</dd><dd><strong>Location:</strong> palo alto</dd>
			<dd>
				<ul class="profile-icons">
					<li class="web-icon"><a href="http://www.cliffblack.com/" title="WWW: http://www.cliffblack.com"><span>Website</span></a></li>
				</ul>
			</dd>
		

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p1690" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting9675.html?mode=quote&amp;f=5&amp;p=1690" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p1690"></a></h3>
			<p class="author"><a href="viewtopic2a36.html?p=1690#p1690"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist5036.html?mode=viewprofile&amp;u=6">Steve Urbach</a></strong> &raquo; Tue Aug 18, 2009 10:06 am </p>

			

			<div class="content">Cliff Black is right on.
<br />Get the 1100 glider (have it inspected by a knowledgeable 3rd party if not from a HG shop).
<br />
<br />Performance gliders only <span style="font-style: italic">look</span> easy to fly. 
<br />Their pilots have dialed in the <span style="font-style: italic">exact touch</span> needed for that model
<br />
<br />It is easy (and very scary) to over control a new glider. 
<br />Any new glider.
<br />Beginner gliders are more forgiving of a &quot;heavy hand&quot; and should serve you through H2 or H3.</div>

			

		</div>

		
			<dl class="postprofile" id="profile1690">
			<dt>
				<a href="memberlist5036.html?mode=viewprofile&amp;u=6">Steve Urbach</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 43</dd><dd><strong>Joined:</strong> Sat Feb 07, 2004 9:22 am</dd><dd><strong>Location:</strong> Palo Alto</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p1693" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postingbad8.html?mode=quote&amp;f=5&amp;p=1693" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p1693"></a></h3>
			<p class="author"><a href="viewtopicaf21.html?p=1693#p1693"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist69e5.html?mode=viewprofile&amp;u=1551">Alan</a></strong> &raquo; Thu Aug 20, 2009 11:08 am </p>

			

			<div class="content">Before you spring for the Falcon, check to make sure you are in the right weight range.  The one on that web page is a 140 (the number means the number of square feet of sail area) which is good for someone up to about 150 pounds (I think -- the 140 isn't made anymore).   You don't want too small a glider -- you will never get off the ground!
<br />
<br />Also budget for a harness and helmet.</div>

			

		</div>

		
			<dl class="postprofile" id="profile1693">
			<dt>
				<a href="memberlist69e5.html?mode=viewprofile&amp;u=1551">Alan</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 29</dd><dd><strong>Joined:</strong> Fri Feb 27, 2009 3:31 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p1700" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postingb1ba.html?mode=quote&amp;f=5&amp;p=1700" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p1700"></a></h3>
			<p class="author"><a href="viewtopicb5db.php?p=1700#p1700"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist65aa.html?mode=viewprofile&amp;u=1606">amouramis</a></strong> &raquo; Tue Aug 25, 2009 8:06 am </p>

			

			<div class="content">That last one is especially good to know.  I would have wasted money and been pissed!  I weigh 180 so I'll look for something else.  Thanks!</div>

			

		</div>

		
			<dl class="postprofile" id="profile1700">
			<dt>
				<a href="memberlist65aa.html?mode=viewprofile&amp;u=1606">amouramis</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 2</dd><dd><strong>Joined:</strong> Fri Aug 14, 2009 2:20 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p1701" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postinga676.html?mode=quote&amp;f=5&amp;p=1701" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p1701">newbie</a></h3>
			<p class="author"><a href="viewtopic9cab.php?p=1701#p1701"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist5cee.html?mode=viewprofile&amp;u=154">cliffblack</a></strong> &raquo; Tue Aug 25, 2009 2:17 pm </p>

			

			<div class="content">$1300 for a Wills Wing AT is insane, they are giving them away here, a pristine one &quot;Might &quot; get sold for $200 max! forget the AT it's way OLD! You would be much better off with a euro sport or super sport 158</div>

			<div id="sig1701" class="signature">Tom</div>

		</div>

		
			<dl class="postprofile" id="profile1701">
			<dt>
				<a href="memberlist5cee.html?mode=viewprofile&amp;u=154">cliffblack</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 103</dd><dd><strong>Joined:</strong> Mon May 30, 2005 11:54 am</dd><dd><strong>Location:</strong> palo alto</dd>
			<dd>
				<ul class="profile-icons">
					<li class="web-icon"><a href="http://www.cliffblack.com/" title="WWW: http://www.cliffblack.com"><span>Website</span></a></li>
				</ul>
			</dd>
		

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<form id="viewtopic" method="post" action="http://flyfunston.org/bbs/viewtopic.php?f=5&amp;t=817">

	<fieldset class="display-options" style="margin-top: 0; ">
		
		<label>Display posts from previous: <select name="st" id="st"><option value="0" selected="selected">All posts</option><option value="1">1 day</option><option value="7">7 days</option><option value="14">2 weeks</option><option value="30">1 month</option><option value="90">3 months</option><option value="180">6 months</option><option value="365">1 year</option></select></label>
		<label>Sort by <select name="sk" id="sk"><option value="a">Author</option><option value="t" selected="selected">Post time</option><option value="s">Subject</option></select></label> <label><select name="sd" id="sd"><option value="a" selected="selected">Ascending</option><option value="d">Descending</option></select> <input type="submit" name="sort" value="Go" class="button2" /></label>
		
	</fieldset>

	</form>
	<hr />


<div class="topic-actions">
	<div class="buttons">
	
		<div class="reply-icon"><a href="posting881a.html?mode=reply&amp;f=5&amp;t=817" title="Post a reply"><span></span>Post a reply</a></div>
	
	</div>

	
		<div class="pagination">
			6 posts
			 &bull; Page <strong>1</strong> of <strong>1</strong>
		</div>
	
</div>


	<p></p><p><a href="viewforume774.html?f=5" class="left-box left" accesskey="r">Return to General Discussion</a></p>

	<form method="post" id="jumpbox" action="http://flyfunston.org/bbs/viewforum.php" onsubmit="if(this.f.value == -1){return false;}">

	
		<fieldset class="jumpbox">
	
			<label for="f" accesskey="j">Jump to:</label>
			<select name="f" id="f" onchange="if(this.options[this.selectedIndex].value != -1){ document.forms['jumpbox'].submit() }">
			
				<option value="-1">Select a forum</option>
			<option value="-1">------------------</option>
				<option value="9">Discussion Groups</option>
			
				<option value="5" selected="selected">&nbsp; &nbsp;General Discussion</option>
			
				<option value="8">&nbsp; &nbsp;Announcements</option>
			
				<option value="7">&nbsp; &nbsp;For Sale/Wanted</option>
			
				<option value="6">&nbsp; &nbsp;Road Trips</option>
			
				<option value="2">&nbsp; &nbsp;Meeting Minutes and Treasurer Reports</option>
			
				<option value="11">&nbsp; &nbsp;Off Topic</option>
			
			</select>
			<input type="submit" value="Go" class="button2" />
		</fieldset>
	</form>


	<h3>Who is online</h3>
	<p>Users browsing this forum: No registered users and 8 guests</p>
</div>

<div id="page-footer">

	<div class="navbar">
		<div class="inner"><span class="corners-top"><span></span></span>

		<ul class="linklist">
			<li class="icon-home"><a href="index.html">Board index</a></li>
				
			<li class="rightside"><a href="memberlista2f5.html?mode=leaders">The team</a> &bull; <a href="ucp033a.html?mode=delete_cookies">Delete all board cookies</a> &bull; All times are UTC - 8 hours [ <abbr title="Daylight Saving Time">DST</abbr> ]</li>
		</ul>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<div class="copyright">Powered by <a href="https://www.phpbb.com/">phpBB</a>&reg; Forum Software &copy; phpBB Group
		
	</div>
</div>

</div>

<div>
	<a id="bottom" name="bottom" accesskey="z"></a>
	<img src="cronb999.gif?cron_type=tidy_search" width="1" height="1" alt="cron" />
</div>

</body>

<!-- Mirrored from flyfunston.org/bbs/viewtopic.php?p=1701 by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 08 Aug 2021 20:18:29 GMT -->
</html>