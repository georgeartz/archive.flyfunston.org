<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en-us" xml:lang="en-us">

<!-- Mirrored from flyfunston.org/bbs/viewtopic.php?f=2&t=1779 by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 08 Aug 2021 17:15:38 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>

<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<meta http-equiv="content-style-type" content="text/css" />
<meta http-equiv="content-language" content="en-us" />
<meta http-equiv="imagetoolbar" content="no" />
<meta name="resource-type" content="document" />
<meta name="distribution" content="global" />
<meta name="keywords" content="" />
<meta name="description" content="" />

<title>Flyfunston &bull; View topic - October 5th 2016 Fellow Feather’s Meeting Minutes</title>



<!--
	phpBB style name: prosilver
	Based on style:   prosilver (this is the default phpBB3 style)
	Original author:  Tom Beddard ( http://www.subBlue.com/ )
	Modified by:
-->

<script type="text/javascript">
// <![CDATA[
	var jump_page = 'Enter the page number you wish to go to:';
	var on_page = '1';
	var per_page = '';
	var base_url = '';
	var style_cookie = 'phpBBstyle';
	var style_cookie_settings = '; path=/; domain=flyfunston.org; secure';
	var onload_functions = new Array();
	var onunload_functions = new Array();

	

	/**
	* Find a member
	*/
	function find_username(url)
	{
		popup(url, 760, 570, '_usersearch');
		return false;
	}

	/**
	* New function for handling multiple calls to window.onload and window.unload by pentapenguin
	*/
	window.onload = function()
	{
		for (var i = 0; i < onload_functions.length; i++)
		{
			eval(onload_functions[i]);
		}
	};

	window.onunload = function()
	{
		for (var i = 0; i < onunload_functions.length; i++)
		{
			eval(onunload_functions[i]);
		}
	};

// ]]>
</script>
<script type="text/javascript" src="styles/prosilver/template/styleswitcher.js"></script>
<script type="text/javascript" src="styles/prosilver/template/forum_fn.js"></script>

<link href="styles/prosilver/theme/print.css" rel="stylesheet" type="text/css" media="print" title="printonly" />
<link href="style7a95.css?id=1&amp;lang=en_us" rel="stylesheet" type="text/css" media="screen, projection" />

<link href="styles/prosilver/theme/normal.css" rel="stylesheet" type="text/css" title="A" />
<link href="styles/prosilver/theme/medium.css" rel="alternate stylesheet" type="text/css" title="A+" />
<link href="styles/prosilver/theme/large.css" rel="alternate stylesheet" type="text/css" title="A++" />



</head>

<body id="phpbb" class="section-viewtopic ltr">

<div id="wrap">
	<a id="top" name="top" accesskey="t"></a>
	<div id="page-header">
		<div class="headerbar">
			<div class="inner"><span class="corners-top"><span></span></span>

			<div id="site-description">
				<a href="index.html" title="Board index" id="logo"><img src="styles/prosilver/imageset/site_logo.gif" width="149" height="52" alt="" title="" /></a>
				<h1>Flyfunston</h1>
				<p>Hang Gliding at Fort Funston</p>
				<p class="skiplink"><a href="#start_here">Skip to content</a></p>
			</div>

		
			<div id="search-box">
				<form action="http://flyfunston.org/bbs/search.php" method="get" id="search">
				<fieldset>
					<input name="keywords" id="keywords" type="text" maxlength="128" title="Search for keywords" class="inputbox search" value="Search…" onclick="if(this.value=='Search…')this.value='';" onblur="if(this.value=='')this.value='Search…';" />
					<input class="button2" value="Search" type="submit" /><br />
					<a href="search.html" title="View the advanced search options">Advanced search</a> 
				</fieldset>
				</form>
			</div>
		

			<span class="corners-bottom"><span></span></span></div>
		</div>

		<div class="navbar">
			<div class="inner"><span class="corners-top"><span></span></span>

			<ul class="linklist navlinks">
				<li class="icon-home"><a href="index.html" accesskey="h">Board index</a>  <strong>&#8249;</strong> <a href="viewforumfdc5.html?f=9">Discussion Groups</a> <strong>&#8249;</strong> <a href="viewforum12a3.html?f=2">Meeting Minutes and Treasurer Reports</a></li>

				<li class="rightside"><a href="#" onclick="fontsizeup(); return false;" onkeypress="return fontsizeup(event);" class="fontsize" title="Change font size">Change font size</a></li>

				<li class="rightside"><a href="viewtopic9452.php?f=2&amp;t=1779&amp;view=print" title="Print view" accesskey="p" class="print">Print view</a></li>
			</ul>

			

			<ul class="linklist rightside">
				<li class="icon-faq"><a href="faq.html" title="Frequently Asked Questions">FAQ</a></li>
				
					<li class="icon-logout"><a href="ucp26c3.php?mode=login" title="Login" accesskey="x">Login</a></li>
				
			</ul>

			<span class="corners-bottom"><span></span></span></div>
		</div>

	</div>

	<a name="start_here"></a>
	<div id="page-body">
		
<h2><a href="viewtopic5e40.php?f=2&amp;t=1779">October 5th 2016 Fellow Feather’s Meeting Minutes</a></h2>
<!-- NOTE: remove the style="display: none" when you want to have the forum description on the topic body --><div style="display: none !important;">Minutes and Treasurer Reports from the Fellow Feathers monthly meetings.<br /></div>

<div class="topic-actions">

	<div class="buttons">
	
		<div class="reply-icon"><a href="posting3482.html?mode=reply&amp;f=2&amp;t=1779" title="Post a reply"><span></span>Post a reply</a></div>
	
	</div>

	
		<div class="search-box">
			<form method="get" id="topic-search" action="http://flyfunston.org/bbs/search.php">
			<fieldset>
				<input class="inputbox search tiny"  type="text" name="keywords" id="search_keywords" size="20" value="Search this topic…" onclick="if(this.value=='Search this topic…')this.value='';" onblur="if(this.value=='')this.value='Search this topic…';" />
				<input class="button2" type="submit" value="Search" />
				<input type="hidden" name="t" value="1779" />
<input type="hidden" name="sf" value="msgonly" />

			</fieldset>
			</form>
		</div>
	
		<div class="pagination">
			1 post
			 &bull; Page <strong>1</strong> of <strong>1</strong>
		</div>
	

</div>
<div class="clear"></div>


	<div id="p4360" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postingd76d.html?mode=quote&amp;f=2&amp;p=4360" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 class="first"><a href="#p4360">October 5th 2016 Fellow Feather’s Meeting Minutes</a></h3>
			<p class="author"><a href="viewtopicbe24.html?p=4360#p4360"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist7aa3.html?mode=viewprofile&amp;u=129">crvalley</a></strong> &raquo; Wed Oct 05, 2016 9:49 pm </p>

			

			<div class="content">October 5th 2016 Fellow Feather’s Meeting Minutes<br /><br />In Attendance: Chris Valley, John Simpson, Steve Rodriques, Mitch Shipley, Rob Johnson, Dave Egli, Urs Kellenberger, George Artz, Rick Hawkin, Jim Mueller,<br /><br />Guests / New Members: Returning pilot Dave Egli.<br /><br />Great Flights: Dave Egli had some good flights at Funston. <br /><br />President’s Report (John Simpson): Discussed concern of new pilots flying the Fort and whether or not they are properly prepared and trained to fly the site. Mitch Shipley: Suggested Assisted Windy Cliff Launch (AWCL) and Restricted Landing Field (RLF) skills sign-off. Rick suggested having observers on site to assist with AWCL and RLF sign-off(s). It was suggested the Club offer a “New Pilot Workshop”<br /><br />Vice President’s Report (Wayne Michelsen): Nothing to report.<br /><br />Secretary’s Report (Chris Valley): August meeting minutes posted. No meeting in September, so no minutes posted.<br /><br />Treasurer’s Report (Lisa Lesser): Steve Rodrigues: Discussed budget. Motion for increasing the clubhouse membership dues by $10 to $75 for a balanced budget. Motion passed. Based upon dues increase, we’ll have a balanced budget and those present voted in favor for the 2015-16 budget.<br /><br />Clubhouse Officer’s Report (Rob Johnson): Clubhouse cleanup. Gliders in purgatory have been impounded and are in storage and will be held for 30 days - they will be held until November 1, 2016, then will be recycled. Hose reel installed and holders for brooms to help organize things. Discussed a redo of the glider racks (spacing and better support) and the cost associated. 15 members have not paid dues and are not current with stickers. Round of applause for Rob and his efforts.<br /><br />Safety Officer’s Report (Chris Carrillo): Nothing to report. <br /><br />Tech Officer’s Report (Chuck Kranz): Nothing to report. <br /><br />Administrator Reports:<br />~ Tandem (Urs Kellenberger): Nothing to report.<br />~ Training Bowl (Mark Lilledahl): Nothing to report.<br /><br />GGNRA Liaison Report (Steve Rodrigues): Permit needs to get renewed. Steve spoke with Park officials regarding status of permit and agreement with BAPA. The Club’s goal is to have a 5-year agreement moving forward.<br /><br />Old Business: No old business.<br /><br />New Business: See President’s Report. A motion was made and passed for a “New Pilot Workshop” committee consisting Mitch Shipley, Steve Rodrigues, John Simpson, Wayne Michelsen, Chris Valley, and Urs Kellenberger.<br /><br />Meeting adjourned by 9:00 pm.</div>

			<div id="sig4360" class="signature">“We abuse land because we see it as a commodity belonging to us. When we see land as a community to which we belong, we may begin to use it with love and respect.” ― Aldo Leopold</div>

		</div>

		
			<dl class="postprofile" id="profile4360">
			<dt>
				<a href="memberlist7aa3.html?mode=viewprofile&amp;u=129">crvalley</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 214</dd><dd><strong>Joined:</strong> Sun Apr 10, 2005 9:16 am</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />


<div class="topic-actions">
	<div class="buttons">
	
		<div class="reply-icon"><a href="posting3482.html?mode=reply&amp;f=2&amp;t=1779" title="Post a reply"><span></span>Post a reply</a></div>
	
	</div>

	
		<div class="pagination">
			1 post
			 &bull; Page <strong>1</strong> of <strong>1</strong>
		</div>
	
</div>


	<p></p><p><a href="viewforum12a3.html?f=2" class="left-box left" accesskey="r">Return to Meeting Minutes and Treasurer Reports</a></p>

	<form method="post" id="jumpbox" action="http://flyfunston.org/bbs/viewforum.php" onsubmit="if(this.f.value == -1){return false;}">

	
		<fieldset class="jumpbox">
	
			<label for="f" accesskey="j">Jump to:</label>
			<select name="f" id="f" onchange="if(this.options[this.selectedIndex].value != -1){ document.forms['jumpbox'].submit() }">
			
				<option value="-1">Select a forum</option>
			<option value="-1">------------------</option>
				<option value="9">Discussion Groups</option>
			
				<option value="5">&nbsp; &nbsp;General Discussion</option>
			
				<option value="8">&nbsp; &nbsp;Announcements</option>
			
				<option value="7">&nbsp; &nbsp;For Sale/Wanted</option>
			
				<option value="6">&nbsp; &nbsp;Road Trips</option>
			
				<option value="2" selected="selected">&nbsp; &nbsp;Meeting Minutes and Treasurer Reports</option>
			
				<option value="11">&nbsp; &nbsp;Off Topic</option>
			
			</select>
			<input type="submit" value="Go" class="button2" />
		</fieldset>
	</form>


	<h3>Who is online</h3>
	<p>Users browsing this forum: No registered users and 5 guests</p>
</div>

<div id="page-footer">

	<div class="navbar">
		<div class="inner"><span class="corners-top"><span></span></span>

		<ul class="linklist">
			<li class="icon-home"><a href="index.html">Board index</a></li>
				
			<li class="rightside"><a href="memberlista2f5.html?mode=leaders">The team</a> &bull; <a href="ucp033a.html?mode=delete_cookies">Delete all board cookies</a> &bull; All times are UTC - 8 hours [ <abbr title="Daylight Saving Time">DST</abbr> ]</li>
		</ul>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<div class="copyright">Powered by <a href="https://www.phpbb.com/">phpBB</a>&reg; Forum Software &copy; phpBB Group
		
	</div>
</div>

</div>

<div>
	<a id="bottom" name="bottom" accesskey="z"></a>
	
</div>

</body>

<!-- Mirrored from flyfunston.org/bbs/viewtopic.php?f=2&t=1779 by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 08 Aug 2021 17:15:38 GMT -->
</html>