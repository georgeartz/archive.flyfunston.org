<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en-us" xml:lang="en-us">

<!-- Mirrored from flyfunston.org/bbs/viewtopic.php?p=1448 by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 08 Aug 2021 20:19:21 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>

<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<meta http-equiv="content-style-type" content="text/css" />
<meta http-equiv="content-language" content="en-us" />
<meta http-equiv="imagetoolbar" content="no" />
<meta name="resource-type" content="document" />
<meta name="distribution" content="global" />
<meta name="keywords" content="" />
<meta name="description" content="" />

<title>Flyfunston &bull; View topic - Should H-2 soar?</title>



<!--
	phpBB style name: prosilver
	Based on style:   prosilver (this is the default phpBB3 style)
	Original author:  Tom Beddard ( http://www.subBlue.com/ )
	Modified by:
-->

<script type="text/javascript">
// <![CDATA[
	var jump_page = 'Enter the page number you wish to go to:';
	var on_page = '1';
	var per_page = '';
	var base_url = '';
	var style_cookie = 'phpBBstyle';
	var style_cookie_settings = '; path=/; domain=flyfunston.org; secure';
	var onload_functions = new Array();
	var onunload_functions = new Array();

	

	/**
	* Find a member
	*/
	function find_username(url)
	{
		popup(url, 760, 570, '_usersearch');
		return false;
	}

	/**
	* New function for handling multiple calls to window.onload and window.unload by pentapenguin
	*/
	window.onload = function()
	{
		for (var i = 0; i < onload_functions.length; i++)
		{
			eval(onload_functions[i]);
		}
	};

	window.onunload = function()
	{
		for (var i = 0; i < onunload_functions.length; i++)
		{
			eval(onunload_functions[i]);
		}
	};

// ]]>
</script>
<script type="text/javascript" src="styles/prosilver/template/styleswitcher.js"></script>
<script type="text/javascript" src="styles/prosilver/template/forum_fn.js"></script>

<link href="styles/prosilver/theme/print.css" rel="stylesheet" type="text/css" media="print" title="printonly" />
<link href="style7a95.css?id=1&amp;lang=en_us" rel="stylesheet" type="text/css" media="screen, projection" />

<link href="styles/prosilver/theme/normal.css" rel="stylesheet" type="text/css" title="A" />
<link href="styles/prosilver/theme/medium.css" rel="alternate stylesheet" type="text/css" title="A+" />
<link href="styles/prosilver/theme/large.css" rel="alternate stylesheet" type="text/css" title="A++" />



</head>

<body id="phpbb" class="section-viewtopic ltr">

<div id="wrap">
	<a id="top" name="top" accesskey="t"></a>
	<div id="page-header">
		<div class="headerbar">
			<div class="inner"><span class="corners-top"><span></span></span>

			<div id="site-description">
				<a href="index.html" title="Board index" id="logo"><img src="styles/prosilver/imageset/site_logo.gif" width="149" height="52" alt="" title="" /></a>
				<h1>Flyfunston</h1>
				<p>Hang Gliding at Fort Funston</p>
				<p class="skiplink"><a href="#start_here">Skip to content</a></p>
			</div>

		
			<div id="search-box">
				<form action="http://flyfunston.org/bbs/search.php" method="get" id="search">
				<fieldset>
					<input name="keywords" id="keywords" type="text" maxlength="128" title="Search for keywords" class="inputbox search" value="Search…" onclick="if(this.value=='Search…')this.value='';" onblur="if(this.value=='')this.value='Search…';" />
					<input class="button2" value="Search" type="submit" /><br />
					<a href="search.html" title="View the advanced search options">Advanced search</a> 
				</fieldset>
				</form>
			</div>
		

			<span class="corners-bottom"><span></span></span></div>
		</div>

		<div class="navbar">
			<div class="inner"><span class="corners-top"><span></span></span>

			<ul class="linklist navlinks">
				<li class="icon-home"><a href="index.html" accesskey="h">Board index</a>  <strong>&#8249;</strong> <a href="viewforumfdc5.html?f=9">Discussion Groups</a> <strong>&#8249;</strong> <a href="viewforume774.html?f=5">General Discussion</a></li>

				<li class="rightside"><a href="#" onclick="fontsizeup(); return false;" onkeypress="return fontsizeup(event);" class="fontsize" title="Change font size">Change font size</a></li>

				<li class="rightside"><a href="viewtopic49d6.html?f=5&amp;t=729&amp;view=print" title="Print view" accesskey="p" class="print">Print view</a></li>
			</ul>

			

			<ul class="linklist rightside">
				<li class="icon-faq"><a href="faq.html" title="Frequently Asked Questions">FAQ</a></li>
				
					<li class="icon-logout"><a href="ucp26c3.php?mode=login" title="Login" accesskey="x">Login</a></li>
				
			</ul>

			<span class="corners-bottom"><span></span></span></div>
		</div>

	</div>

	<a name="start_here"></a>
	<div id="page-body">
		
<h2><a href="viewtopic9c19.html?f=5&amp;t=729">Should H-2 soar?</a></h2>
<!-- NOTE: remove the style="display: none" when you want to have the forum description on the topic body --><div style="display: none !important;">Talk about Hang Gliding at Ft Funston and the Fellow Feathers Club.<br /></div>

<div class="topic-actions">

	<div class="buttons">
	
		<div class="reply-icon"><a href="posting56a9.html?mode=reply&amp;f=5&amp;t=729" title="Post a reply"><span></span>Post a reply</a></div>
	
	</div>

	
		<div class="search-box">
			<form method="get" id="topic-search" action="http://flyfunston.org/bbs/search.php">
			<fieldset>
				<input class="inputbox search tiny"  type="text" name="keywords" id="search_keywords" size="20" value="Search this topic…" onclick="if(this.value=='Search this topic…')this.value='';" onblur="if(this.value=='')this.value='Search this topic…';" />
				<input class="button2" type="submit" value="Search" />
				<input type="hidden" name="t" value="729" />
<input type="hidden" name="sf" value="msgonly" />

			</fieldset>
			</form>
		</div>
	
		<div class="pagination">
			6 posts
			 &bull; Page <strong>1</strong> of <strong>1</strong>
		</div>
	

</div>
<div class="clear"></div>


	<div id="p1426" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting024d-2.html?mode=quote&amp;f=5&amp;p=1426" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 class="first"><a href="#p1426">Should H-2 soar?</a></h3>
			<p class="author"><a href="viewtopicde70.html?p=1426#p1426"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberliste69f.html?mode=viewprofile&amp;u=15" style="color: #AA0000;" class="username-coloured">Steve Rodrigues</a></strong> &raquo; Sat Feb 28, 2009 10:21 am </p>

			

			<div class="content">DB wrote;
<br />The new H-2 Rules need refinement.
<br />3. After four flights, an H-2 is still an H-2. If the H-2 wants to soar at Funston, he should become an H-3.
<br />
<br />&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;
<br />
<br />The majority of members who voted in 2008 and 2009 feel that there are times when H-2's can safely soar the Training Bowl and they modified the rules as such.
<br />
<br />I believe it is the Boards duty to follow the rules and allow H-2's to fly while doing everything in our power to keep them safe.</div>

			

		</div>

		
			<dl class="postprofile" id="profile1426">
			<dt>
				<a href="memberliste69f.html?mode=viewprofile&amp;u=15"><img src="download/file9b05.php?avatar=15_1575056796.jpg" width="200" height="149" alt="User avatar" /></a><br />
				<a href="memberliste69f.html?mode=viewprofile&amp;u=15" style="color: #AA0000;" class="username-coloured">Steve Rodrigues</a>
			</dt>

			<dd>Site Admin</dd>

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 723</dd><dd><strong>Joined:</strong> Mon May 24, 2004 10:57 pm</dd><dd><strong>Location:</strong> Brisbane, California</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p1440" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting2d60.html?mode=quote&amp;f=5&amp;p=1440" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p1440"></a></h3>
			<p class="author"><a href="viewtopicd728.html?p=1440#p1440"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlistd0bb.php?mode=viewprofile&amp;u=1552">sporty155</a></strong> &raquo; Sun Mar 01, 2009 8:51 pm </p>

			

			<div class="content">Im kinda confused when it comes to this rule, why would a H2 want to set up his or her glider, launch and fly to the beach? sounds like a big pain in the butt all for a 45 second sled run, and then to haul your glider up the hill without help? OUCH!!!!!! 
<br />
<br />How about the supervised pilot launch in appropriate conditions, soar under the given parameters until the person supervising flags him or her to then land on the beach?  
<br />
<br />Rob</div>

			

		</div>

		
			<dl class="postprofile" id="profile1440">
			<dt>
				<a href="memberlistd0bb.php?mode=viewprofile&amp;u=1552">sporty155</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 127</dd><dd><strong>Joined:</strong> Sat Feb 28, 2009 2:04 am</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p1442" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting9ba4-2.html?mode=quote&amp;f=5&amp;p=1442" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p1442"></a></h3>
			<p class="author"><a href="viewtopic8bab.php?p=1442#p1442"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberliste69f.html?mode=viewprofile&amp;u=15" style="color: #AA0000;" class="username-coloured">Steve Rodrigues</a></strong> &raquo; Sun Mar 01, 2009 11:57 pm </p>

			

			<div class="content">Pilots don't do the sled ride for the actual airtime but rather for the learning experience. Fort Funston has been a H-3 rated site since it's inception 27 or so years ago and untold numbers of H-2's have done the sled ride and subsequent hike back to launch as part of their training. These pilots often use the sled ride as a way to get their glider to the training bowl for more practice. This process has been a fundamental building block for pilots prior to flying the Fort.
<br />
<br />An average H-2 does not have the skills to launch and go directly into soaring flight, especially at Fort Funston. They need to learn about the site through practice flights and build their skills gradually. Our goal is to offer quality mentoring so H-2's pilots can advance to their next rating. Hucking them off into soarable conditions without the proper experience would be irresponsible, IMHO.</div>

			

		</div>

		
			<dl class="postprofile" id="profile1442">
			<dt>
				<a href="memberliste69f.html?mode=viewprofile&amp;u=15"><img src="download/file9b05.php?avatar=15_1575056796.jpg" width="200" height="149" alt="User avatar" /></a><br />
				<a href="memberliste69f.html?mode=viewprofile&amp;u=15" style="color: #AA0000;" class="username-coloured">Steve Rodrigues</a>
			</dt>

			<dd>Site Admin</dd>

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 723</dd><dd><strong>Joined:</strong> Mon May 24, 2004 10:57 pm</dd><dd><strong>Location:</strong> Brisbane, California</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p1448" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting45d8.html?mode=quote&amp;f=5&amp;p=1448" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p1448"></a></h3>
			<p class="author"><a href="viewtopic9a20.php?p=1448#p1448"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist0101.html?mode=viewprofile&amp;u=1533">mooncricket</a></strong> &raquo; Wed Mar 04, 2009 6:03 pm </p>

			

			<div class="content">&quot;If the H-2 wants to soar at Funston, he should become an H-3.&quot;
<br />
<br />Is this tongue-in-cheek? 
<br />If its serious - its a just a dismissal of the issue: H-2s have very few sites in the bay area which can give them the airtime and experience to build towards their H-3.
<br />Its easy for us H3+ pilots to forget that it is not an easy transition or effort to get your H3. This effects us all as we have fewer people coming into the sport and fewer people at the site.
<br />
<br />What is the goal of the fellow feathers? Seeing as its on public (or state) land - I would think part of the goal should to make a reasonable effort to make it available to everyone safely. 
<br />
<br />I don't believe restricting funston to H3+'s only makes anyone safer either.
<br />We have people bending and breaking the rules, hotdogging it at unregulated sites (like the dumps), pioneering launches or just dropping out of the sport because they don't have places to build airtime. This has seemingly become the norm.
<br />
<br />I think the drafted set of rules make a great attempt at making funston safely available to H2.5s in a way that allows them to continue to learn and progress towards their H3.
<br />
<br />(and I'd also say we've been seeing a lot of new faces hanging around  - women included)
<br />
<br />Dirk</div>

			

		</div>

		
			<dl class="postprofile" id="profile1448">
			<dt>
				<a href="memberlist0101.html?mode=viewprofile&amp;u=1533"><img src="http://metaloft.com/pics/mooncricket.gif" width="78" height="80" alt="User avatar" /></a><br />
				<a href="memberlist0101.html?mode=viewprofile&amp;u=1533">mooncricket</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 5</dd><dd><strong>Joined:</strong> Sun Jan 25, 2009 11:51 am</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p1449" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting94a6.html?mode=quote&amp;f=5&amp;p=1449" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p1449"></a></h3>
			<p class="author"><a href="viewtopicd699.html?p=1449#p1449"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlistd3cc.html?mode=viewprofile&amp;u=1478">fakeDecoy</a></strong> &raquo; Wed Mar 04, 2009 11:59 pm </p>

			

			<div class="content">It's no Ed Levin, but I want to see H2.5s out there on good days to fly one at a time under supervision. On a day with favorable conditions they're not going to be much worse than any random H3 mountain pilot getting humbled at the Fort.</div>

			

		</div>

		
			<dl class="postprofile" id="profile1449">
			<dt>
				<a href="memberlistd3cc.html?mode=viewprofile&amp;u=1478">fakeDecoy</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 140</dd><dd><strong>Joined:</strong> Thu Jul 24, 2008 8:22 am</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p1452" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postinga5ce.html?mode=quote&amp;f=5&amp;p=1452" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p1452"></a></h3>
			<p class="author"><a href="viewtopic2ba6.html?p=1452#p1452"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberliste849.html?mode=viewprofile&amp;u=1541">Frontman</a></strong> &raquo; Fri Mar 06, 2009 12:27 am </p>

			

			<div class="content">(edit- after re-reading my post, I wanted to add that although I am new to the site, I do have over 75 flights and almost 10 hours logged.  I just don't want anyone assuming that my first flights at Funston were the same day that I earned my H2) 
<br />
<br />First, I'd like to thank all the Funston pilots that have spent time with me, either in lecture, or walking the LZ etc.
<br />
<br />As a new pilot, and as an H2, I can give you firsthand and current information on how a new H2 feels.
<br />
<br />Ratings, I'm finding, are but a rough guidline regarding pilot skills.  I do not envy the responsibility of any instructors or Funston mentor types have when launching a new pilot at the site.  What I can say, is some people are ready, some are not.  As an H2 that has soared and traveled to Westlake, I can say that the site is awesome, and that I have respect for it's dangers.  I can also say that landing on the beach absolutely sucks, but I feel that it is an important &quot;Right of Passage&quot; for any and all new pilots.  You must know how to land on the beach if the lift dies out.  Landing on the beach all through your H2 status?  Brutal.
<br />
<br />I feel that certain H2 pilots should be allowed access to Westlake when lower risk conditions are present.  As stated here before, new pilots long for experience and hours in the air.  Learning to fly at Sled Heaven, on my 8 min flights, does teach me launch and landing skills, but just about the time I'm settled in my harness and comfortable flying, it's time to land.  My 2nd flight at Funston I logged 3 hours, and learned SO much it was awesome.  However, since I am now denied access to Westlake, I'm really not even jazzed about flying there again until I earn my H3.  Let's face it, is not altitude our friend when it comes to making mistakes?  Why would I want to fly the bowls, 50ft off the ground, as a newbie?
<br />
<br />I agree on having all new pilots to the sight, regardless of rating, to sport a streamer designating them as a new pilot.  Most sports have the same, such as go kart racers putting a big X on the newbie's helmet so as not to scare the shit out of them.
<br />
<br />I'm not asking for rule changes.  I'm simply telling you of my impressions of the site as an H2.  I feel very lucky to fly the site as an H2, and always have an open ear when a veteran pilot speaks.  However, if I had my choice, I'd let me soar to Westlake, again, providing the conditions were permitting, and at a certain point, start teaching me to top land.
<br />
<br />I do think it should be mandatory though, for all H2 pilots to be in constant radio/cellular communication with a veteran Funston pilot.  How are you supposed to know you are, or about to, do something very stupid and life threatening without the input of someone who knows the site?
<br />
<br />Thanks again for all who have spent time with me.  See you when the wind blows west!
<br />
<br />
<br />
<br />Gary</div>

			

		</div>

		
			<dl class="postprofile" id="profile1452">
			<dt>
				<a href="memberliste849.html?mode=viewprofile&amp;u=1541">Frontman</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 15</dd><dd><strong>Joined:</strong> Fri Feb 06, 2009 4:27 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<form id="viewtopic" method="post" action="http://flyfunston.org/bbs/viewtopic.php?f=5&amp;t=729">

	<fieldset class="display-options" style="margin-top: 0; ">
		
		<label>Display posts from previous: <select name="st" id="st"><option value="0" selected="selected">All posts</option><option value="1">1 day</option><option value="7">7 days</option><option value="14">2 weeks</option><option value="30">1 month</option><option value="90">3 months</option><option value="180">6 months</option><option value="365">1 year</option></select></label>
		<label>Sort by <select name="sk" id="sk"><option value="a">Author</option><option value="t" selected="selected">Post time</option><option value="s">Subject</option></select></label> <label><select name="sd" id="sd"><option value="a" selected="selected">Ascending</option><option value="d">Descending</option></select> <input type="submit" name="sort" value="Go" class="button2" /></label>
		
	</fieldset>

	</form>
	<hr />


<div class="topic-actions">
	<div class="buttons">
	
		<div class="reply-icon"><a href="posting56a9.html?mode=reply&amp;f=5&amp;t=729" title="Post a reply"><span></span>Post a reply</a></div>
	
	</div>

	
		<div class="pagination">
			6 posts
			 &bull; Page <strong>1</strong> of <strong>1</strong>
		</div>
	
</div>


	<p></p><p><a href="viewforume774.html?f=5" class="left-box left" accesskey="r">Return to General Discussion</a></p>

	<form method="post" id="jumpbox" action="http://flyfunston.org/bbs/viewforum.php" onsubmit="if(this.f.value == -1){return false;}">

	
		<fieldset class="jumpbox">
	
			<label for="f" accesskey="j">Jump to:</label>
			<select name="f" id="f" onchange="if(this.options[this.selectedIndex].value != -1){ document.forms['jumpbox'].submit() }">
			
				<option value="-1">Select a forum</option>
			<option value="-1">------------------</option>
				<option value="9">Discussion Groups</option>
			
				<option value="5" selected="selected">&nbsp; &nbsp;General Discussion</option>
			
				<option value="8">&nbsp; &nbsp;Announcements</option>
			
				<option value="7">&nbsp; &nbsp;For Sale/Wanted</option>
			
				<option value="6">&nbsp; &nbsp;Road Trips</option>
			
				<option value="2">&nbsp; &nbsp;Meeting Minutes and Treasurer Reports</option>
			
				<option value="11">&nbsp; &nbsp;Off Topic</option>
			
			</select>
			<input type="submit" value="Go" class="button2" />
		</fieldset>
	</form>


	<h3>Who is online</h3>
	<p>Users browsing this forum: No registered users and 9 guests</p>
</div>

<div id="page-footer">

	<div class="navbar">
		<div class="inner"><span class="corners-top"><span></span></span>

		<ul class="linklist">
			<li class="icon-home"><a href="index.html">Board index</a></li>
				
			<li class="rightside"><a href="memberlista2f5.html?mode=leaders">The team</a> &bull; <a href="ucp033a.html?mode=delete_cookies">Delete all board cookies</a> &bull; All times are UTC - 8 hours [ <abbr title="Daylight Saving Time">DST</abbr> ]</li>
		</ul>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<div class="copyright">Powered by <a href="https://www.phpbb.com/">phpBB</a>&reg; Forum Software &copy; phpBB Group
		
	</div>
</div>

</div>

<div>
	<a id="bottom" name="bottom" accesskey="z"></a>
	<img src="cronb999.gif?cron_type=tidy_search" width="1" height="1" alt="cron" />
</div>

</body>

<!-- Mirrored from flyfunston.org/bbs/viewtopic.php?p=1448 by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 08 Aug 2021 20:19:21 GMT -->
</html>