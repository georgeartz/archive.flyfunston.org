<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en-us" xml:lang="en-us">

<!-- Mirrored from flyfunston.org/bbs/viewtopic.php?p=2527 by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 08 Aug 2021 20:18:26 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>

<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<meta http-equiv="content-style-type" content="text/css" />
<meta http-equiv="content-language" content="en-us" />
<meta http-equiv="imagetoolbar" content="no" />
<meta name="resource-type" content="document" />
<meta name="distribution" content="global" />
<meta name="keywords" content="" />
<meta name="description" content="" />

<title>Flyfunston &bull; View topic - USHPA and Funston</title>



<!--
	phpBB style name: prosilver
	Based on style:   prosilver (this is the default phpBB3 style)
	Original author:  Tom Beddard ( http://www.subBlue.com/ )
	Modified by:
-->

<script type="text/javascript">
// <![CDATA[
	var jump_page = 'Enter the page number you wish to go to:';
	var on_page = '1';
	var per_page = '25';
	var base_url = 'viewtopicb4b3.php?f=5&amp;t=1106';
	var style_cookie = 'phpBBstyle';
	var style_cookie_settings = '; path=/; domain=flyfunston.org; secure';
	var onload_functions = new Array();
	var onunload_functions = new Array();

	

	/**
	* Find a member
	*/
	function find_username(url)
	{
		popup(url, 760, 570, '_usersearch');
		return false;
	}

	/**
	* New function for handling multiple calls to window.onload and window.unload by pentapenguin
	*/
	window.onload = function()
	{
		for (var i = 0; i < onload_functions.length; i++)
		{
			eval(onload_functions[i]);
		}
	};

	window.onunload = function()
	{
		for (var i = 0; i < onunload_functions.length; i++)
		{
			eval(onunload_functions[i]);
		}
	};

// ]]>
</script>
<script type="text/javascript" src="styles/prosilver/template/styleswitcher.js"></script>
<script type="text/javascript" src="styles/prosilver/template/forum_fn.js"></script>

<link href="styles/prosilver/theme/print.css" rel="stylesheet" type="text/css" media="print" title="printonly" />
<link href="style7a95.css?id=1&amp;lang=en_us" rel="stylesheet" type="text/css" media="screen, projection" />

<link href="styles/prosilver/theme/normal.css" rel="stylesheet" type="text/css" title="A" />
<link href="styles/prosilver/theme/medium.css" rel="alternate stylesheet" type="text/css" title="A+" />
<link href="styles/prosilver/theme/large.css" rel="alternate stylesheet" type="text/css" title="A++" />



</head>

<body id="phpbb" class="section-viewtopic ltr">

<div id="wrap">
	<a id="top" name="top" accesskey="t"></a>
	<div id="page-header">
		<div class="headerbar">
			<div class="inner"><span class="corners-top"><span></span></span>

			<div id="site-description">
				<a href="index.html" title="Board index" id="logo"><img src="styles/prosilver/imageset/site_logo.gif" width="149" height="52" alt="" title="" /></a>
				<h1>Flyfunston</h1>
				<p>Hang Gliding at Fort Funston</p>
				<p class="skiplink"><a href="#start_here">Skip to content</a></p>
			</div>

		
			<div id="search-box">
				<form action="http://flyfunston.org/bbs/search.php" method="get" id="search">
				<fieldset>
					<input name="keywords" id="keywords" type="text" maxlength="128" title="Search for keywords" class="inputbox search" value="Search…" onclick="if(this.value=='Search…')this.value='';" onblur="if(this.value=='')this.value='Search…';" />
					<input class="button2" value="Search" type="submit" /><br />
					<a href="search.html" title="View the advanced search options">Advanced search</a> 
				</fieldset>
				</form>
			</div>
		

			<span class="corners-bottom"><span></span></span></div>
		</div>

		<div class="navbar">
			<div class="inner"><span class="corners-top"><span></span></span>

			<ul class="linklist navlinks">
				<li class="icon-home"><a href="index.html" accesskey="h">Board index</a>  <strong>&#8249;</strong> <a href="viewforumfdc5.html?f=9">Discussion Groups</a> <strong>&#8249;</strong> <a href="viewforume774.html?f=5">General Discussion</a></li>

				<li class="rightside"><a href="#" onclick="fontsizeup(); return false;" onkeypress="return fontsizeup(event);" class="fontsize" title="Change font size">Change font size</a></li>

				<li class="rightside"><a href="viewtopica60f.html?f=5&amp;t=1106&amp;view=print" title="Print view" accesskey="p" class="print">Print view</a></li>
			</ul>

			

			<ul class="linklist rightside">
				<li class="icon-faq"><a href="faq.html" title="Frequently Asked Questions">FAQ</a></li>
				
					<li class="icon-logout"><a href="ucp26c3.php?mode=login" title="Login" accesskey="x">Login</a></li>
				
			</ul>

			<span class="corners-bottom"><span></span></span></div>
		</div>

	</div>

	<a name="start_here"></a>
	<div id="page-body">
		
<h2><a href="viewtopicb4b3.php?f=5&amp;t=1106">USHPA and Funston</a></h2>
<!-- NOTE: remove the style="display: none" when you want to have the forum description on the topic body --><div style="display: none !important;">Talk about Hang Gliding at Ft Funston and the Fellow Feathers Club.<br /></div>

<div class="topic-actions">

	<div class="buttons">
	
		<div class="reply-icon"><a href="postinge4b2.html?mode=reply&amp;f=5&amp;t=1106" title="Post a reply"><span></span>Post a reply</a></div>
	
	</div>

	
		<div class="search-box">
			<form method="get" id="topic-search" action="http://flyfunston.org/bbs/search.php">
			<fieldset>
				<input class="inputbox search tiny"  type="text" name="keywords" id="search_keywords" size="20" value="Search this topic…" onclick="if(this.value=='Search this topic…')this.value='';" onblur="if(this.value=='')this.value='Search this topic…';" />
				<input class="button2" type="submit" value="Search" />
				<input type="hidden" name="t" value="1106" />
<input type="hidden" name="sf" value="msgonly" />

			</fieldset>
			</form>
		</div>
	
		<div class="pagination">
			31 posts
			 &bull; <a href="#" onclick="jumpto(); return false;" title="Click to jump to page…">Page <strong>1</strong> of <strong>2</strong></a> &bull; <span><strong>1</strong><span class="page-sep">, </span><a href="viewtopicafa7.html?f=5&amp;t=1106&amp;start=25">2</a></span>
		</div>
	

</div>
<div class="clear"></div>


	<div id="p2453" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting85e2.php?mode=quote&amp;f=5&amp;p=2453" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 class="first"><a href="#p2453">USHPA and Funston</a></h3>
			<p class="author"><a href="viewtopicf0fc.html?p=2453#p2453"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist9acc.html?mode=viewprofile&amp;u=126">Dan Brown</a></strong> &raquo; Sun Mar 06, 2011 7:59 pm </p>

			

			<div class="content">The recent replacement of our waiver by USHPA’s waiver and the manner in which it was done are not cause for celebration. The waiver was our waiver. We negotiated it and had a voice in its terms and conditions. Now it has been eliminated by USHPA’s attorney and a USHPA Director negotiating directly with our landlord. For 40 years we had kept third parties out of our relationship with our landlord.<br /><br />To maintain our independence we need to distance ourselves from USHPA; not become more dependent upon it. USHPA is an organization increasingly devoted to a sport that is not ours, disliked by many of its members, with a long history of financial irregularities and run by  Directors who voted to impose a gag rule, end the independence of local clubs and force Fellow Feathers to allow non-hang gliding pilots to vote in our elections.<br /><br />Instead of USHPA negotiating to end our waiver, we should be negotiating to end our dependence upon USHPA. The only purpose USHPA serves is to sell us, reportedly at a profit, insurance. Our landlord requires liability insurance. We should try to convince it that insurance is unnecessary. Recreational use immunity statutes and California Supreme Court decisions provide protection. <br /><br />I don’t question Steve’s good intentions in eliminating our waiver but it is hard to balance the diminishment of local control with the claimed saving of a few dollars. The waiver simply was part of the Funston rule package printed on the back of the sticker application.<br /><br />Even if our landlord continues to require insurance, there is hope that a new organization may end our dependence upon USHPA. A former USHPA Director has established a national HANG GLIDING organization, <!-- m --><a class="postlink" href="http://www.ushawks.org/">http://www.ushawks.org/</a><!-- m --> . If it obtains insurance, USHPA will have competition and we no longer will forced to join it to fly at Funston.</div>

			

		</div>

		
			<dl class="postprofile" id="profile2453">
			<dt>
				<a href="memberlist9acc.html?mode=viewprofile&amp;u=126">Dan Brown</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 88</dd><dd><strong>Joined:</strong> Fri Apr 01, 2005 2:01 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2454" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting6d50.php?mode=quote&amp;f=5&amp;p=2454" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2454">Re: USHPA and Funston</a></h3>
			<p class="author"><a href="viewtopic6529.html?p=2454#p2454"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlistd3cc.html?mode=viewprofile&amp;u=1478">fakeDecoy</a></strong> &raquo; Tue Mar 08, 2011 9:58 am </p>

			

			<div class="content"><blockquote class="uncited"><div>Our landlord requires liability insurance. We should try to convince it that insurance is unnecessary. Recreational use immunity statutes and California Supreme Court decisions provide protection. </div></blockquote><br /><br />Do you have more info on what statutes would cover it? Could a case still go to court and incur $$$ in legal fees before it's dismissed, or appealed in a higher court outside of the statute jurisdiction and win?<br /><br />Interesting fact - I was told by the USHPA insurance chairman last year that USHPA has never once had a lawsuit against a landowner, which site insurance would apply to.<br /><br />Dave</div>

			

		</div>

		
			<dl class="postprofile" id="profile2454">
			<dt>
				<a href="memberlistd3cc.html?mode=viewprofile&amp;u=1478">fakeDecoy</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 140</dd><dd><strong>Joined:</strong> Thu Jul 24, 2008 8:22 am</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2458" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting5a73.html?mode=quote&amp;f=5&amp;p=2458" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2458">Re: USHPA and Funston</a></h3>
			<p class="author"><a href="viewtopica683.html?p=2458#p2458"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist9acc.html?mode=viewprofile&amp;u=126">Dan Brown</a></strong> &raquo; Fri Mar 11, 2011 5:30 pm </p>

			

			<div class="content">California and most other states have enacted recreational use immunity statutes to encourage landowners to allow recreational users access to their properties without fear of liability and lawsuits. The California version applicable to Funston is Civil Code Sec. 846. It specifically includes activities like “sport parachuting” and “hang gliding”. It and similar statutes in other states have been upheld in hundreds of cases. In the unlikely event a claimant sought damages against the GGNRA for a hang glider injury, it would have to pay its own attorney fees and costs and, because of the meritless nature of the lawsuit, have to pay the attorney fees and costs of the GGNRA. <br /><br />	Many landowners do not require site insurance. BABA has no insurance for the heavily used Dumps but has it for the little used Stables. <br /><br />Not relevant to insurance but an important part of the recreational use statute is the requirement that the recreational activity be non-commercial. Commercial activity like commercial tandem flights places the protection in jeopardy and at Funston is prohibited.</div>

			

		</div>

		
			<dl class="postprofile" id="profile2458">
			<dt>
				<a href="memberlist9acc.html?mode=viewprofile&amp;u=126">Dan Brown</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 88</dd><dd><strong>Joined:</strong> Fri Apr 01, 2005 2:01 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2460" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postingc4d2.php?mode=quote&amp;f=5&amp;p=2460" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2460">Re: USHPA and Funston</a></h3>
			<p class="author"><a href="viewtopice15f.html?p=2460#p2460"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlistd3cc.html?mode=viewprofile&amp;u=1478">fakeDecoy</a></strong> &raquo; Fri Mar 18, 2011 9:22 pm </p>

			

			<div class="content">Is the Fellow Feathers corp open to litigation by an injured park visitor?<br /><br />Dave</div>

			

		</div>

		
			<dl class="postprofile" id="profile2460">
			<dt>
				<a href="memberlistd3cc.html?mode=viewprofile&amp;u=1478">fakeDecoy</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 140</dd><dd><strong>Joined:</strong> Thu Jul 24, 2008 8:22 am</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2463" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postinge1ae.php?mode=quote&amp;f=5&amp;p=2463" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2463">Re: USHPA and Funston</a></h3>
			<p class="author"><a href="viewtopic8d34.html?p=2463#p2463"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist9acc.html?mode=viewprofile&amp;u=126">Dan Brown</a></strong> &raquo; Sat Mar 19, 2011 12:24 pm </p>

			

			<div class="content">Under the present arrangement w/our landlord, we cannot operate as a private club w/o site insurance. If we left USHPA, we would have to obtain site insurance directly from a carrier or through another organization. If USHAWKS obtains a policy, we could join it and leave USHPA.<br /><br />Since USHPA now negotiates directly with our landlord, it is unlikely to try to convince it that USHPA insurance is unnecessary and that the recreational use immunity statute provides sufficient protection. <br /><br />USHPA gradually is taking over Funston to our detriment. Several years ago a USHPA Director threatened to revoke our site insurance unless we allowed paragliding. At its last meeting, USHPA Directors voted not only to impose a gag rule on members but to require Fellow Feathers to allow non-pilots to vote in our elections and to prohibit except under limited circumstances hang gliding only sites. Urs voted for the measures. Member outrage forced USHPA to withdraw them.<br /><br />There are circumstances under which an injured spectator could sue the club. Assume a spectator were injured in the crash of a commercial tandem flight. If the club violated its permit and agreement with the landlord and allowed/tolerated/condoned commercial tandem flights, it could be held liable and club officers sued individually particularly the tandem director. The insurance company probably would disclaim coverage claiming the club knowingly allowed a prohibited activity.</div>

			

		</div>

		
			<dl class="postprofile" id="profile2463">
			<dt>
				<a href="memberlist9acc.html?mode=viewprofile&amp;u=126">Dan Brown</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 88</dd><dd><strong>Joined:</strong> Fri Apr 01, 2005 2:01 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2465" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postingd10a.php?mode=quote&amp;f=5&amp;p=2465" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2465">Re: USHPA and Funston</a></h3>
			<p class="author"><a href="viewtopicae85.html?p=2465#p2465"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist3887.html?mode=viewprofile&amp;u=590">Urs</a></strong> &raquo; Sat Mar 19, 2011 5:45 pm </p>

			

			<div class="content">Some pilots may remember the waiver fiasco that Dan Brown caused. He sued USHGA and almost single handedly bankrupted the association. He lost the law suit.<br /><br />Dan's battle with USHPA is similar to a story about windmills that takes place in Spain a long time ago. <br /><br />If you'd like to know the truth about Dan's incorrect claims just ask me personally. Dan distorts the facts for a living.<br /><br />Here are some more facts:<br />The GGNRA has said we don't need to sign any extra waivers besides the USHPA waiver. Dan wrote the waiver that's no longer necessary.<br />Dan also wrote an affidavit that my kids and friends need to sign before I fly them tandem that I'm not receiving funds or &quot;benefits  <img src="images/smilies/icon_redface.gif" alt=":oops:" title="Embarassed" /> &quot;<br />Maybe Dan is afraid of being waked by 3 tandems in a row on the cliff. I can understand that. This can be worked on through civil conversation about ones fears.<br />The US has 70% of all the lawyers world wide.  The rest of the world expects you to be responsible for yourself and they have a looser pays law when a lawsuit is filed. Therefore lawyers limit our flying because of &quot;FEAR OF LAWSUITS&quot;.<br /><br />Dan, you're like Fox News and I will NOT respond to any more of your false accusations. It's apparent to me that you don't enjoy flying with too many people in the air and therefore wish to limit pilot growth in our region. There are other less populated sites to fly, but you choose to only fly Funston. Stop being a roadblock and start sharing the air with new fellow hang glider pilots.</div>

			

		</div>

		
			<dl class="postprofile" id="profile2465">
			<dt>
				<a href="memberlist3887.html?mode=viewprofile&amp;u=590">Urs</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 32</dd><dd><strong>Joined:</strong> Wed Sep 06, 2006 10:16 am</dd><dd><strong>Location:</strong> Redwood City, CA</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2468" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting9c18.php?mode=quote&amp;f=5&amp;p=2468" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2468">Re: USHPA and Funston</a></h3>
			<p class="author"><a href="viewtopic1877.html?p=2468#p2468"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist9acc.html?mode=viewprofile&amp;u=126">Dan Brown</a></strong> &raquo; Sun Mar 20, 2011 12:20 pm </p>

			

			<div class="content">Personal attacks only reflect upon the person making the attacks. They prevent rational discussion of issues and discourage people from becoming involved in organizations.<br /><br />There were several issues I raised in the posts deserving of factual rebuttal. I claimed USHPA is an organization increasingly devoted to a sport that is not ours, disliked by many of its members, with a long history of financial irregularities and run by Directors like Urs who voted to impose a gag rule, end the independence of local clubs and force Fellow Feathers to allow non-hang gliding pilots to vote in our elections. <br /><br />Urs did not respond to any of the issues declining even to explain his vote.<br /><br />Urs’ comments about me are minor compared to his comments about a good friend, Mark Lilledahl. Urs has been feuding for years with Mark. Previously Urs had forced Mark out of hang gliding for a year when he got USHPA to reduce Mark’s rating to a Hang II. Last year Urs accused Mark of killing Tom Mayer. Tom died last June in an aerobatics meet at Crestline flying a Wills Wing TC2 that he had purchased six months previously from Mark. In this month’s USHPA magazine there is a two page accident report on Tom’s death. The report concluded the sole cause was pilot error. The accident was witnessed by many pilots and videotaped. All agree it was pilot error. <br /><br />The meet director notified Urs it was pilot error.<br /><br />Despite the overwhelming evidence that it was pilot error, Urs told several pilots at Funston that Mark had killed Tom. “Mark is going to kill more than one [pilot]” and “Mark’s glider killed another pilot because of tuning.” Urs contacted a Canadian pilot, Doug Dofler, to whom Mark had sold a Wills Wing T2 two years previously warning him that Mark’s gliders are “dangerous”.<br />                           <br />When Mike Meier, the president of Wills Wing, learned that Urs had blamed Mark for the accident, he wrote:  <br />“Anyone who saw the incident, or the video, and has the least <br />understanding of hang gliders and aerobatic maneuvers can see <br />that Tom's accident was completely pilot error. Anyone who did <br />not see either, or who is without the least understanding has no <br />business making a comment on the issue at all. I don't get why <br />someone would make a totally off the wall, unjustified statement <br />like that...”<br /><br />Urs, like everyone else, is entitled to his opinion but it ceases to be an opinion when it is offensive, made in bad faith and without a factual basis. <br /><br />Urs’ comments should not prevent pilots from voicing their opinions without fear of personal attacks. There is an old saying: “The dogs bark but the caravan goes on.”</div>

			

		</div>

		
			<dl class="postprofile" id="profile2468">
			<dt>
				<a href="memberlist9acc.html?mode=viewprofile&amp;u=126">Dan Brown</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 88</dd><dd><strong>Joined:</strong> Fri Apr 01, 2005 2:01 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2472" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting5b96.php?mode=quote&amp;f=5&amp;p=2472" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2472">Re: USHPA and Funston</a></h3>
			<p class="author"><a href="viewtopic65ff.html?p=2472#p2472"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist3887.html?mode=viewprofile&amp;u=590">Urs</a></strong> &raquo; Sun Mar 20, 2011 9:22 pm </p>

			

			<div class="content">Dan, just because you say it, doesn't make it true. ALL OF YOUR STATEMENTS ARE A LIE. I will not argue with a fool. Don't waste my time.<br /><br />I'll say it again, anyone that wants to know the truth can simply ask me.<br /><br />Mike, you've had trouble with every club you've ever had contact with. Good people have tried to help you in many many different ways. Maybe Dan can help <img src="images/smilies/icon_rolleyes.gif" alt=":roll:" title="Rolling Eyes" /></div>

			

		</div>

		
			<dl class="postprofile" id="profile2472">
			<dt>
				<a href="memberlist3887.html?mode=viewprofile&amp;u=590">Urs</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 32</dd><dd><strong>Joined:</strong> Wed Sep 06, 2006 10:16 am</dd><dd><strong>Location:</strong> Redwood City, CA</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2478" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postingf8f3.html?mode=quote&amp;f=5&amp;p=2478" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2478">Re: USHPA and Funston</a></h3>
			<p class="author"><a href="viewtopicbcfa.php?p=2478#p2478"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberliste69f.html?mode=viewprofile&amp;u=15" style="color: #AA0000;" class="username-coloured">Steve Rodrigues</a></strong> &raquo; Mon Mar 21, 2011 10:26 am </p>

			

			<div class="content">Hi Dan,<br /><br />You are overlooking a few facts that simplify this discussion.<br /><br />First, It is NPS policy to not require a waiver. It was the NPS Solicitor who ruled that the GGNRA was to stop using the GGNRA Hang Glider waiver.<br /><br />Second, Our Special Use Permit with the GGNRA requires the Fellow Feathers to maintain site and liability insurance. The USHPA has negotiated a group policy with the current carrier. Our members are required to sign the USHPA waiver to use this policy.<br /><br />My personal opinion is that we don't need any more waivers.<br /><br />Please feel free to find another &quot;A&quot; rated insurance carrier who can provide the same coverage for lower premiums.<br /><br />Regards,<br />Steve</div>

			<div id="sig2478" class="signature">USHPA # 30605<br />H-5, Mentor and Observer</div>

		</div>

		
			<dl class="postprofile" id="profile2478">
			<dt>
				<a href="memberliste69f.html?mode=viewprofile&amp;u=15"><img src="download/file9b05.php?avatar=15_1575056796.jpg" width="200" height="149" alt="User avatar" /></a><br />
				<a href="memberliste69f.html?mode=viewprofile&amp;u=15" style="color: #AA0000;" class="username-coloured">Steve Rodrigues</a>
			</dt>

			<dd>Site Admin</dd>

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 723</dd><dd><strong>Joined:</strong> Mon May 24, 2004 10:57 pm</dd><dd><strong>Location:</strong> Brisbane, California</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2489" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postingdab3-2.html?mode=quote&amp;f=5&amp;p=2489" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2489">Re: USHPA and Funston</a></h3>
			<p class="author"><a href="viewtopicb558.php?p=2489#p2489"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944">bobk</a></strong> &raquo; Tue Mar 22, 2011 9:13 pm </p>

			

			<div class="content"><blockquote><div><cite>Dan Brown wrote:</cite>Even if our landlord continues to require insurance, there is hope that a new organization may end our dependence upon USHPA. A former USHPA Director has established a national HANG GLIDING organization, <!-- m --><a class="postlink" href="http://www.ushawks.org/">http://www.ushawks.org/</a><!-- m --> . If it obtains insurance, USHPA will have competition and we no longer will forced to join it to fly at Funston.</div></blockquote><br />Hi Dan and Fellow Funston Feathers,<br /><br />First, thanks for the hospitality your club has shown me during my visits from San Diego. I've had some great flights at Funston including the first time I ever flew my Falcon <span style="font-style: italic"><span style="text-decoration: underline">in</span></span> <span style="font-style: italic"><span style="text-decoration: underline">reverse</span></span> while down near the dumps. The wind was howling from the southwest and I found that I could slow down enough to back up <span style="font-style: italic">and</span> climb at the same time!! In fact, my vario sounded like a truck's &quot;back up&quot; beeper as I was going backwards ... and climbing. It's a great site.<br /><br />With regard to the US Hawks, your comments are accurate, Dan. I would like to build a national organization that supports hang gliding. I am not against paragliding, and I've got an H4/P4 rating. But I can see the landscape changing, and I believe hang gliding will have less and less of a national voice at USHPA in the future. So I think it is prudent for us to form a national organization (or network?) to support the interests of hang gliding pilots in the United States. That's why I started the ill-fated HGAA, and I hope to do a better job with the US Hawks.<br /><br />At this point, we are just building our membership with both pilots and clubs. It costs nothing to join as either a Pilot Member or a Chapter Member. We provide a free forum for our chapters integrated with the national US Hawks forum. I like that kind of integration because it helps focus national attention on local issues when needed. It also encourages our members to support all clubs nationwide. I predict that USHPA will eventually adopt this kind of a model (the Oz Report has already started offering club sub-forums on a limited basis - following our lead  <img src="images/smilies/icon_biggrin.html" alt=":D" title="Very Happy" /> ).<br /><br />So what will the US Hawks be? I'm not sure yet. It might become a full-fledged flight organization offering insurance and ratings just as USHPA does. In fact, I'm hoping that we might share common ratings and even share an insurance pool to keep the costs down. As a minimum, I expect that the US Hawks will recognize all USHPA ratings as a show of reciprocity.<br /><br />But getting insurance will take some time. The HGAA failed because that's all they could see ... insurance. When they didn't have the membership, they collapsed. I'd like the US Hawks to be a national hang gliding organization representing hang gliding interests <span style="font-style: italic">regardless</span> of whether we can get insurance right away or not. In that sense, we can become the &quot;hang gliding party&quot; on the national level. It has always surprised me that USHPA has a <span style="font-weight: bold">towing committee</span> and a <span style="font-weight: bold">tandem committee</span>, but it doesn't have a <span style="font-weight: bold">hang gliding committee</span> or a <span style="font-weight: bold">paragliding committee</span> to represent those special interests. If nothing else, I believe the US Hawks will either become ... or inspire ... that kind of representation for our sport.<br /><br />If anyone is interested in joining us, please go to <a href="http://ushawks.org/" class="postlink">http://ushawks.org</a> and sign up for our forum. Also, please ask your club officers if your club would like to become a Chapter. Becoming a chapter is also free and there are at least 3 USHPA Chapters that are also US Hawks Chapters.<br /><br />If you have any questions, please feel free to call me directly at 858-204-7499 or write to me via email (<!-- e --><a href="mailto:bobkuczewski@gmail.com">bobkuczewski@gmail.com</a><!-- e -->). I'll be happy to answer any questions you have or hear any of your concerns.<br /><br />Thanks again for your hospitality during my visits.<br /><br />Bob Kuczewski</div>

			<div id="sig2489" class="signature"><span style="font-size: 130%; line-height: 116%;"><span style="color: #000080"><span style="font-style: italic">Join a National Hang Gliding Organization:</span></span> <span style="font-weight: bold"><span style="color: #000080"><a href="http://ushawks.org/" class="postlink">US Hawks at ushawks.org</a></span></span></span></div>

		</div>

		
			<dl class="postprofile" id="profile2489">
			<dt>
				<a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944"><img src="download/file3928.html?avatar=1944_1390380842.jpeg" width="200" height="150" alt="User avatar" /></a><br />
				<a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944">bobk</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 138</dd><dd><strong>Joined:</strong> Tue Mar 22, 2011 1:53 pm</dd>
			<dd>
				<ul class="profile-icons">
					<li class="web-icon"><a href="http://ushawks.org/" title="WWW: http://ushawks.org"><span>Website</span></a></li>
				</ul>
			</dd>
		

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2490" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postinga870.html?mode=quote&amp;f=5&amp;p=2490" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2490">Re: USHPA and Funston</a></h3>
			<p class="author"><a href="viewtopic77ce.php?p=2490#p2490"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944">bobk</a></strong> &raquo; Tue Mar 22, 2011 9:33 pm </p>

			

			<div class="content"><blockquote><div><cite>Urs wrote:</cite>Dan, just because you say it, doesn't make it true. ALL OF YOUR STATEMENTS ARE A LIE. I will not argue with a fool. Don't waste my time.<br /><br />I'll say it again, anyone that wants to know the truth can simply ask me.<br /><br />Mike, you've had trouble with every club you've ever had contact with. Good people have tried to help you in many many different ways. Maybe Dan can help <img src="images/smilies/icon_rolleyes.gif" alt=":roll:" title="Rolling Eyes" /></div></blockquote><br />Urs,<br /><br />Your comments here show a disrespect that is unbecoming of a Director (even a USHPA Director). I suspect you've forgotten who you work for.<br /><br />To say that &quot;ALL&quot; of anyone's statements are lies is clearly not accurate. I don't need to know anything about Dan's own statements to know that they can't <span style="text-decoration: underline">ALL</span> be lies. So you've shown your bias here ... along with your contempt for some of your own constituents. Why am I not surprised?<br /><br />Bob Kuczewski<br /><br /><span style="color: #000040"><span style="font-style: italic">[edit] P.S. Urs ... In the fall of 2009 I first proposed the &quot;Accountability Amendment&quot; which would provide more transparency for how Directors vote on the USHPA Board. Dave Wills refused to allow it through his Organization and Bylaws Committee in both the fall 2009 and spring 2010 meetings. So I put forth a motion for that amendment at the spring 2010 full Board session. You refused to second that motion, and you sat there silently as Lisa Tate violated Robert's Rules of Order by not allowing another Director's second. What do you have to say for yourself on that one? And how did you vote on the &quot;gag order&quot; fiasco levied on club officers in the fall of 2010? Were you in Dave Wills pocket on that one as well? [/edit]</span></span></div>

			<div id="sig2490" class="signature"><span style="font-size: 130%; line-height: 116%;"><span style="color: #000080"><span style="font-style: italic">Join a National Hang Gliding Organization:</span></span> <span style="font-weight: bold"><span style="color: #000080"><a href="http://ushawks.org/" class="postlink">US Hawks at ushawks.org</a></span></span></span></div>

		</div>

		
			<dl class="postprofile" id="profile2490">
			<dt>
				<a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944"><img src="download/file3928.html?avatar=1944_1390380842.jpeg" width="200" height="150" alt="User avatar" /></a><br />
				<a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944">bobk</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 138</dd><dd><strong>Joined:</strong> Tue Mar 22, 2011 1:53 pm</dd>
			<dd>
				<ul class="profile-icons">
					<li class="web-icon"><a href="http://ushawks.org/" title="WWW: http://ushawks.org"><span>Website</span></a></li>
				</ul>
			</dd>
		

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2496" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postingc3b1-2.html?mode=quote&amp;f=5&amp;p=2496" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2496">Re: USHPA and Funston</a></h3>
			<p class="author"><a href="viewtopic6700.html?p=2496#p2496"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944">bobk</a></strong> &raquo; Wed Mar 23, 2011 11:13 pm </p>

			

			<div class="content"><blockquote><div><cite>SlopeSkimmer wrote:</cite>Try to understand this, RDs are electected by the members to represent the members, not fight with them.</div></blockquote><br />USHPA has a problem with the election of Directors. The problem is that we have no track record of how Directors vote on the Board. Without a clear voting record of the Directors, our elections are little more than &quot;popularity contests&quot;. The Directors who smile best and tell the best jokes end up getting elected because there's no actual voting record for them to own up to.<br /><br />That's why I proposed the &quot;Accountability Amendment&quot; which would have helped create a voting record for Directors. Dave Wills refused to allow discussion of that proposed Amendment in the Organization and Bylaws Committee. Lisa Tate similarly refused to allow it to be discussed in the General Session.<br /><br />I've fought for lots of changes at USHPA during my time as Director, but in some ways, this was the <span style="font-style: italic">grand daddy</span> of them all. If the Directors can vote on issues and not let the members see how they've voted, then we've lost control of OUR association. We've been disconnected from the feedback loop that would help us pick good Directors over bad Directors. That's probably the MOST BROKEN part of USHPA, and much of the other garbage that flows from USHPA is rooted in the basic lack of accountability of the Directors to the members.<br /><br />For the record, here's the Accountability Amendment which I sent to Dave Wills and the entire USHPA Board on September 5th, 2009:<br /><br /><blockquote><div><cite>Bob's Proposed Accountability Amendment wrote:</cite>[Article VIII, Section 13.] Conduct of Meetings:<br /><br />All meetings (including Board of Director Meetings, Committee Meetings, General Membership Meetings, and others) shall be governed by Robert's Rules of Order Revised unless otherwise provided for in these By-Laws or listed specifically below:<br /><br />(a) In accordance with one of the practices discussed in Robert's Rules of Order Revised, a Roll Call vote (Yeas and Nays) shall be taken if requested by any Director. The names and votes of all Directors during any such Roll Call vote shall be included in the minutes of the meeting for distribution to the general membership.</div></blockquote><br />Here's part of what Robert's Rules says about Roll Call voting:<br /><br /><blockquote><div><cite>Robert's Rules Of Order - Revised wrote:</cite>In representative bodies this method of voting is very useful, especially where the proceedings are published, as it enables the people to know how their representatives voted on important measures.</div></blockquote><br />That's exactly what we need to be able to fix USHPA. We need to know how our representatives voted on important measures!!<br /><br />You can see from this proposal alone that I was fighting to make USHPA's processes more open and transparent to our members. Dave Wills didn't like that. Lisa Tate didn't like that. Most of the other Directors didn't like that either. That's another reason why they contorted the recall election process to not only get me out but to ensure that I couldn't be re-elected for another 2 years!!<br /><br />The bottom line is very simple. Until we can start to get a handle on how Directors vote on that Board, we (the members) are powerless to elect good Directors over bad Directors. We simply don't have sufficient information to make that determination, so our elections are largely meaningless.</div>

			<div id="sig2496" class="signature"><span style="font-size: 130%; line-height: 116%;"><span style="color: #000080"><span style="font-style: italic">Join a National Hang Gliding Organization:</span></span> <span style="font-weight: bold"><span style="color: #000080"><a href="http://ushawks.org/" class="postlink">US Hawks at ushawks.org</a></span></span></span></div>

		</div>

		
			<dl class="postprofile" id="profile2496">
			<dt>
				<a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944"><img src="download/file3928.html?avatar=1944_1390380842.jpeg" width="200" height="150" alt="User avatar" /></a><br />
				<a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944">bobk</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 138</dd><dd><strong>Joined:</strong> Tue Mar 22, 2011 1:53 pm</dd>
			<dd>
				<ul class="profile-icons">
					<li class="web-icon"><a href="http://ushawks.org/" title="WWW: http://ushawks.org"><span>Website</span></a></li>
				</ul>
			</dd>
		

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2499" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postinga809.html?mode=quote&amp;f=5&amp;p=2499" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2499">Re: USHPA and Funston</a></h3>
			<p class="author"><a href="viewtopic726a.html?p=2499#p2499"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist68ea.html?mode=viewprofile&amp;u=1947">Mark Lilledahl</a></strong> &raquo; Thu Mar 24, 2011 4:08 pm </p>

			

			<div class="content">I did not kill Tom Mayer. I spent several hours with Tom and liked him. He thought my glider was great. Urs was disrespectful of Tom’s family when he used his death to attack me. I don’t know why Urs makes false statements and personal attacks. Recently, he wrote that I was <span style="font-weight: bold">&quot;under psychological care and medication&quot;. </span>Urs should calm down and try yoga!</div>

			

		</div>

		
			<dl class="postprofile" id="profile2499">
			<dt>
				<a href="memberlist68ea.html?mode=viewprofile&amp;u=1947">Mark Lilledahl</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 4</dd><dd><strong>Joined:</strong> Thu Mar 24, 2011 1:54 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2500" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting5b59.html?mode=quote&amp;f=5&amp;p=2500" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2500">Re: USHPA and Funston</a></h3>
			<p class="author"><a href="viewtopic118f.php?p=2500#p2500"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist3887.html?mode=viewprofile&amp;u=590">Urs</a></strong> &raquo; Thu Mar 24, 2011 5:22 pm </p>

			

			<div class="content">All right Mark, maybe you're hanging out a bit too close to the bush when you hear things second or even third hand. My concern was that 3 of your last 4 gliders you sold have tumbled. You tune your gliders to fly fast specifically only at the Fort. Could these 3 gliders have possibly recovered if their settings were stock? Knowing about the 3 tumbles and that a friend was flying your glider in the Canadian Rockies, I felt it was my responsibility to give him a heads up.<br /><br />It's the buyers responsibility to make sure the glider is airworthy. Never did I ever say that you killed Tom. <br /><br />My recommendation is that you have a reliable third party confirm that the next glider you sell has all the settings returned to stock positions. Here is an easy way (Version 2).<!-- m --><a class="postlink" href="http://www.youtube.com/watch?v=S_WCnVMLiH4">http://www.youtube.com/watch?v=S_WCnVMLiH4</a><!-- m --> I'll even do this for you at no charge.<br /><br />What is &quot;recent&quot; for you? Wasn't that at least 3 years ago or much more?<br /><br />How about next time you or Dan Brown have a problem with me, MAN UP and ask me personally or send me an email. You could save yourselves lots of time.</div>

			

		</div>

		
			<dl class="postprofile" id="profile2500">
			<dt>
				<a href="memberlist3887.html?mode=viewprofile&amp;u=590">Urs</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 32</dd><dd><strong>Joined:</strong> Wed Sep 06, 2006 10:16 am</dd><dd><strong>Location:</strong> Redwood City, CA</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2501" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting7406.html?mode=quote&amp;f=5&amp;p=2501" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2501">Re: USHPA and Funston</a></h3>
			<p class="author"><a href="viewtopicab7f.php?p=2501#p2501"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944">bobk</a></strong> &raquo; Thu Mar 24, 2011 7:25 pm </p>

			

			<div class="content"><blockquote><div><cite>Urs wrote:</cite>How about next time you or Dan Brown have a problem with me, MAN UP and ask me personally or send me an email. You could save yourselves lots of time.</div></blockquote><br />Hey Urs,<br /><br />How about if <span style="font-style: italic"><span style="text-decoration: underline">you</span></span> &quot;man up&quot; and answer the questions that I asked...<br /><br />Why didn't <span style="text-decoration: underline">you</span> second a motion to discuss open voting by the Board at the Spring 2010 meeting?<br />How did <span style="text-decoration: underline">you</span> vote on the &quot;gag order&quot; fiasco last fall?<br />What is <span style="text-decoration: underline">your</span> voting record on all USHPA issues?<br /><br />You could save yourself a lot of time if <span style="text-decoration: underline">you</span> would publish <span style="text-decoration: underline">your</span> voting record rather than requiring everyone to make personal requests - which you may or may not answer honestly ... or consistently.<br /><br />Or just pretend that you were never asked ... business as usual.</div>

			<div id="sig2501" class="signature"><span style="font-size: 130%; line-height: 116%;"><span style="color: #000080"><span style="font-style: italic">Join a National Hang Gliding Organization:</span></span> <span style="font-weight: bold"><span style="color: #000080"><a href="http://ushawks.org/" class="postlink">US Hawks at ushawks.org</a></span></span></span></div>

		</div>

		
			<dl class="postprofile" id="profile2501">
			<dt>
				<a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944"><img src="download/file3928.html?avatar=1944_1390380842.jpeg" width="200" height="150" alt="User avatar" /></a><br />
				<a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944">bobk</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 138</dd><dd><strong>Joined:</strong> Tue Mar 22, 2011 1:53 pm</dd>
			<dd>
				<ul class="profile-icons">
					<li class="web-icon"><a href="http://ushawks.org/" title="WWW: http://ushawks.org"><span>Website</span></a></li>
				</ul>
			</dd>
		

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2502" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting530c.html?mode=quote&amp;f=5&amp;p=2502" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2502">Re: USHPA and Funston</a></h3>
			<p class="author"><a href="viewtopic521a.html?p=2502#p2502"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist3887.html?mode=viewprofile&amp;u=590">Urs</a></strong> &raquo; Thu Mar 24, 2011 7:45 pm </p>

			

			<div class="content">Bob, you and I have been through this. If you like, I can give this group a rundown of why you were removed as an RD, from the hanggliding.org, ozreport forum and from your own hang gliding club the Torrey Hawks. Please seek other ways to spend your energy, you'll be very successful if its a positive endeavour. <br /><br />I will not respond to Bob K. again. He has my phone number.<br /><br />Urs</div>

			

		</div>

		
			<dl class="postprofile" id="profile2502">
			<dt>
				<a href="memberlist3887.html?mode=viewprofile&amp;u=590">Urs</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 32</dd><dd><strong>Joined:</strong> Wed Sep 06, 2006 10:16 am</dd><dd><strong>Location:</strong> Redwood City, CA</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2503" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting5341.html?mode=quote&amp;f=5&amp;p=2503" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2503">Re: USHPA and Funston</a></h3>
			<p class="author"><a href="viewtopic6967.html?p=2503#p2503"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944">bobk</a></strong> &raquo; Thu Mar 24, 2011 8:24 pm </p>

			

			<div class="content"><blockquote><div><cite>Urs wrote:</cite>Bob, you and I have been through this.</div></blockquote><br />No, we have not &quot;been through this&quot;. I've asked you three straight questions, and you have yet to provide a public - or private - answer. You're lying to say otherwise.<br /><br /><blockquote><div><cite>Urs wrote:</cite>If you like, I can give this group a rundown of why you were removed as an RD, from the hanggliding.org, ozreport forum and from your own hang gliding club the Torrey Hawks.</div></blockquote><br />Yes. I would like that. Please give us a rundown Urs. Tell us all a story or two. I dare you. I double dare you.<br /><br />If you look into the facts, you'll find that I was &quot;removed&quot; as an RD because I lost an election ... an election where I got more votes (188) than most directors ever get (maybe more than you've ever gotten?). In fact, I got more votes (188) in that &quot;recall&quot; than I did in my original victory over David Jebb (where I won with only 122 votes - more than any other Director in USHPA during that election). But the biggest reason I lost the recall election was because of strong lobbying by the Torrey Pines paragliding school and other Directors (like Rob Sporrer and possibly yourself). In fact, I have a photo of the poster endorsing Bill Helliwell sitting right on the sign-in desk at Torrey!! The Torrey concession wanted a &quot;yes&quot; man for their policies, and smiling Bill did the deed. The results of that election foreshadow the future of hang gliding in an HG/PG organization. Eventually hang gliding will be outnumbered and lose all votes and all effective representation. The handwriting was right there on the wall. That's why I'm working to build the <span style="font-weight: bold"><a href="http://ushawks.org/" class="postlink">US Hawks</a></span> as a national organization to ensure that hang gliding interests are represented by an organization that cares specifically about hang gliding.<br /><br />As for hanggliding.org and the Oz Report, go ahead and discuss those right here as well. You'll see that Jack and Davis were both wrong. In fact, you'll see that I was trying to ask Bill Helliwell a straight question about his support for the Accountability Amendment (open voting on the Board) when Davis did USHPA's bidding by removing my questions from that topic ... during an election!!! When I challenged Davis, he threatened to ban me. So I said that he should either provide a fair forum or ban me. He chose the ban. If you look into the facts, you'll also see that Jack's ban was completely unjustified. I simply said that the HGAA should be called the SGAA, and he couldn't take it. He even changed the post where he banned me to cover his tracks. Go ahead and check the facts Urs.<br /><br />But mostly, you are lying(*) to say that I was removed from the Torrey Hawks. I was club president for over 3 years, and I'm <span style="text-decoration: underline">STILL ON THE BOARD</span> as the current club Secretary. So you are a liar(*) for saying that I was &quot;removed ... from your own hang gliding club the Torrey Hawks&quot;. Go check the recent 2011 USHPA renewal package for the Torrey Hawks and you'll see that I'm <span style="font-style: italic">still</span> the club Secretary. <span style="font-weight: bold"><span style="font-size: 130%; line-height: 116%;">Go ahead, check on it Urs and report back to this forum when you get your facts straight. I challenge you to back up what you say or to apologize for misleading these pilots!!</span></span><br /><br /><blockquote><div><cite>Urs wrote:</cite>I will not respond to Bob K. again. He has my phone number.</div></blockquote><br />Yes, I'm sure you'd like to wiggle out of any response. You have a lot of nerve spreading lies and then ducking for cover. That's exactly why USHPA needs new leadership.<br /><br />Bob Kuczewski<br /><br /><span style="font-style: italic">(*) Footnote: I want to be clear that when I say that Urs is lying here, I am saying that he is not speaking the truth. I cannot say whether his untruths were generated through malice ... or incompetence. I can only say that he's saying things that aren't true. So Urs, if you've simply gotten any of your facts wrong, then an admission on your part will clear up the malice/incompetence issue for us. Or you can remain silent and leave it up to the reader to decide.</span></div>

			<div id="sig2503" class="signature"><span style="font-size: 130%; line-height: 116%;"><span style="color: #000080"><span style="font-style: italic">Join a National Hang Gliding Organization:</span></span> <span style="font-weight: bold"><span style="color: #000080"><a href="http://ushawks.org/" class="postlink">US Hawks at ushawks.org</a></span></span></span></div>

		</div>

		
			<dl class="postprofile" id="profile2503">
			<dt>
				<a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944"><img src="download/file3928.html?avatar=1944_1390380842.jpeg" width="200" height="150" alt="User avatar" /></a><br />
				<a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944">bobk</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 138</dd><dd><strong>Joined:</strong> Tue Mar 22, 2011 1:53 pm</dd>
			<dd>
				<ul class="profile-icons">
					<li class="web-icon"><a href="http://ushawks.org/" title="WWW: http://ushawks.org"><span>Website</span></a></li>
				</ul>
			</dd>
		

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2515" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting2774.html?mode=quote&amp;f=5&amp;p=2515" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2515">Re: USHPA and Funston</a></h3>
			<p class="author"><a href="viewtopic2b32.html?p=2515#p2515"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist68ea.html?mode=viewprofile&amp;u=1947">Mark Lilledahl</a></strong> &raquo; Mon Mar 28, 2011 8:28 pm </p>

			

			<div class="content"><blockquote class="uncited"><div>Urs wrote: All right Mark, maybe you're hanging out a bit too close to the bush when you hear things second or even third hand. My concern was that 3 of your last 4 gliders you sold have tumbled.<br /></div></blockquote>　<br />Urs is not being factual when he claimed he did not tell pilots that I was responsible for Tom's death. He told John Simpson that &quot;Mark is going to kill more than one [pilot]&quot; and &quot;Mark’s glider killed another pilot because of tuning.&quot; I do tune my gliders to go fast at Funston but I always de-tune them before selling. I have no knowledge of the gliders tumbling. What happens to them after they are sold and resold, I don't know. Tom's death had nothing to do with tuning. See USHPA accident report, eyewitness accounts, meet director, manufacturer's statement, etc. Urs may be correct about one thing. It could have been several years ago and not recently when he falsely wrote that I was was &quot;under psychological care and medication&quot;.</div>

			

		</div>

		
			<dl class="postprofile" id="profile2515">
			<dt>
				<a href="memberlist68ea.html?mode=viewprofile&amp;u=1947">Mark Lilledahl</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 4</dd><dd><strong>Joined:</strong> Thu Mar 24, 2011 1:54 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2517" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting81d8.html?mode=quote&amp;f=5&amp;p=2517" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2517">Re: USHPA and Funston</a></h3>
			<p class="author"><a href="viewtopic2dff.php?p=2517#p2517"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944">bobk</a></strong> &raquo; Tue Mar 29, 2011 6:05 am </p>

			

			<div class="content"><span style="font-weight: bold"><span style="font-size: 150%; line-height: 116%;"><span style="color: #000080">Members of the Club</span></span></span>,<br /><br />I cannot say what Urs said about Mark's glider. But I can <span style="text-decoration: underline">prove</span> that Urs is lying when he said that I was &quot;removed ... from your own hang gliding club the Torrey Hawks&quot;. You can <span style="font-style: italic">do the math</span> on how that applies to his credibility in Mark's case.<br /><br /><span style="font-weight: bold"><span style="font-size: 150%; line-height: 116%;"><span style="color: #800000">Urs Kellenberger</span></span></span>,<br /><br />You have stated on this forum that I was removed from the Torrey Hawks hang gliding club. That is provably not true. I want to know if you made that up on your own or if you were simply passing along gossip that you heard from someone else. If it was from someone else, then I want to know who.<br /><br /><span style="font-weight: bold"><span style="font-size: 130%; line-height: 116%;">Urs, you used the phrase &quot;MAN UP&quot; to Mark and Dan. How about if you try it yourself?</span></span></div>

			<div id="sig2517" class="signature"><span style="font-size: 130%; line-height: 116%;"><span style="color: #000080"><span style="font-style: italic">Join a National Hang Gliding Organization:</span></span> <span style="font-weight: bold"><span style="color: #000080"><a href="http://ushawks.org/" class="postlink">US Hawks at ushawks.org</a></span></span></span></div>

		</div>

		
			<dl class="postprofile" id="profile2517">
			<dt>
				<a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944"><img src="download/file3928.html?avatar=1944_1390380842.jpeg" width="200" height="150" alt="User avatar" /></a><br />
				<a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944">bobk</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 138</dd><dd><strong>Joined:</strong> Tue Mar 22, 2011 1:53 pm</dd>
			<dd>
				<ul class="profile-icons">
					<li class="web-icon"><a href="http://ushawks.org/" title="WWW: http://ushawks.org"><span>Website</span></a></li>
				</ul>
			</dd>
		

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2518" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting25dd.html?mode=quote&amp;f=5&amp;p=2518" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2518">Re: USHPA and Funston</a></h3>
			<p class="author"><a href="viewtopic5eea.php?p=2518#p2518"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944">bobk</a></strong> &raquo; Tue Mar 29, 2011 7:05 am </p>

			

			<div class="content">Oops, here's one more bit of evidence to consider when evaluating Urs's credibility ....<br /><br />Urs wrote (March 24th, 2011 at 6:45 pm):<br /><br /><blockquote class="uncited"><div>If you like, I can give this group a rundown of why you were removed as an RD, from the hanggliding.org, ozreport forum and from your own hang gliding club the Torrey Hawks.</div></blockquote><br />That same day - less than an hour later (7:24 pm) - Bob replied:<br /><br /><blockquote class="uncited"><div>Yes. I would like that. Please give us a rundown Urs. Tell us all a story or two. I dare you. I double dare you.</div></blockquote><br />As of March 29th (5 days later), here's what Urs has said in response:<br /><br /><blockquote class="uncited"><div><br /><span style="color: #EBEADE"> . . . . . . . . . . . . . . . . </span><span style="color: #808080">(nothing, silence, .... &quot;crickets&quot;)</span></div></blockquote><br /><span style="font-weight: bold"><span style="font-size: 130%; line-height: 116%;">Urs, maybe you should just refrain from saying things you can't back up.</span></span></div>

			<div id="sig2518" class="signature"><span style="font-size: 130%; line-height: 116%;"><span style="color: #000080"><span style="font-style: italic">Join a National Hang Gliding Organization:</span></span> <span style="font-weight: bold"><span style="color: #000080"><a href="http://ushawks.org/" class="postlink">US Hawks at ushawks.org</a></span></span></span></div>

		</div>

		
			<dl class="postprofile" id="profile2518">
			<dt>
				<a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944"><img src="download/file3928.html?avatar=1944_1390380842.jpeg" width="200" height="150" alt="User avatar" /></a><br />
				<a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944">bobk</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 138</dd><dd><strong>Joined:</strong> Tue Mar 22, 2011 1:53 pm</dd>
			<dd>
				<ul class="profile-icons">
					<li class="web-icon"><a href="http://ushawks.org/" title="WWW: http://ushawks.org"><span>Website</span></a></li>
				</ul>
			</dd>
		

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2521" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting8347.html?mode=quote&amp;f=5&amp;p=2521" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2521">Re: USHPA and Funston</a></h3>
			<p class="author"><a href="viewtopiccf3e.php?p=2521#p2521"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist3887.html?mode=viewprofile&amp;u=590">Urs</a></strong> &raquo; Tue Mar 29, 2011 9:33 am </p>

			

			<div class="content">Mark, you don't remember selling your HP AT to Kemo? He tumbled at Hull in conditions considered to be average. Your Predator, a 145 I think, you sold to your buddy Tim West. He also blew up at Hull. Yes, he was doing a stupid pet trick in thermic conditions.<br /><br />I didn't tell John that you killed him, nor did I say &quot;another&quot;. Why would I say another? I've spoken to John many times more regarding the tumble and he agreed that I didn't say you killed him. Maybe it's your conscience, maybe your mistaking Pat Denaven's comments regarding how you teach launching.<br /><br />3 out of your last 4 gliders have tumbled. All I ask is that you have a 3rd party confirm everything is set back to stock.</div>

			

		</div>

		
			<dl class="postprofile" id="profile2521">
			<dt>
				<a href="memberlist3887.html?mode=viewprofile&amp;u=590">Urs</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 32</dd><dd><strong>Joined:</strong> Wed Sep 06, 2006 10:16 am</dd><dd><strong>Location:</strong> Redwood City, CA</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2522" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting48a3.html?mode=quote&amp;f=5&amp;p=2522" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2522">Re: USHPA and Funston</a></h3>
			<p class="author"><a href="viewtopice897.html?p=2522#p2522"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist9acc.html?mode=viewprofile&amp;u=126">Dan Brown</a></strong> &raquo; Tue Mar 29, 2011 11:23 am </p>

			

			<div class="content">“Oh what a tangled web we weave, when first we practice to deceive.”<br /><br />Liable and slander are defined by Sections 44 and 45 of the California Civil Code. Liable is written defamation. Slander is oral defamation. There are two types of defamation, per quod and per se. Per quod requires the injured party to show financial loss. Per se does not require the injured party to show financial loss.<br /><br />A per quod statement would be Urs claiming Mark’s gliders are dangerous. To recover damages Mark would have to show that his gliders are not dangerous and that he was injured by the claim by having a buyer testify that after hearing Urs’ statement, he decided not to buy a glider from Mark. Mark’s financial recovery would be limited to the loss of sale.<br /><br />A per se statement is more offensive and has a defamatory meaning appearing in itself. It is subject to greater penalty. Historically impugning a woman’s chastity was considered defamation per se. If Urs impugned Emily’s chastity, Emily would be entitled to punitive damages.<br /><br />If Urs stated “Mark is going to kill more than one [pilot]” and “Mark killed another pilot because of tuning”, it would be defamation per se. Mark need not show that a buyer cancelled a purchase. If Urs denied making the statements when witnesses heard them and if Urs contacted a Canadian pilot warning him that Mark’s gliders are “dangerous”, Mark’s recovery would be greater.  If Urs wrote that “Mark was under physiological care and taking medication”, Mark could show a pattern of defamation increasing the recovery.<br /><br />Urs’ creditability with local pilots would further tumble if Mark could show that at the last USHPA Director meeting, Urs voted to end local control at Funston and at other hang gliding sites, to impose a gag rule on pilots, to force Fellow Feathers to allow non-hang gliding pilots to vote in its meetings and to prohibit hang gliding only sites.<br /><br />The next glider Mark sells may be a Laminar.</div>

			

		</div>

		
			<dl class="postprofile" id="profile2522">
			<dt>
				<a href="memberlist9acc.html?mode=viewprofile&amp;u=126">Dan Brown</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 88</dd><dd><strong>Joined:</strong> Fri Apr 01, 2005 2:01 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2524" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting61c9.html?mode=quote&amp;f=5&amp;p=2524" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2524">Re: USHPA and Funston</a></h3>
			<p class="author"><a href="viewtopic621e.html?p=2524#p2524"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist9c48.php?mode=viewprofile&amp;u=1873">e j</a></strong> &raquo; Tue Mar 29, 2011 7:43 pm </p>

			

			<div class="content">In December 2010, I noticed that the &quot;Fellow Feather Application for hang gliding permit&quot; had been changed without a record of any discussion in the club minutes.  I asked how this change had come to be and was brushed off repeatedly.  I was told that Steve Rodrigues, &quot;who was not an elected club officer&quot;,  knew how this change had come to be and I should ask him in private.  My question was never answered. <!-- l --><a class="postlink-local" href="viewtopicf918.html?f=5&amp;t=1079">viewtopic.php?f=5&amp;t=1079</a><!-- l --><br /><br />Then in late February 2011, Steve Rodrigues posted that we no longer needed our waver and would now use the USHPA waver. <!-- l --><a class="postlink-local" href="../../www.flyfunston.org/bbs/viewtopicf4a0.html?f=5&amp;t=1103&amp;sid=fd941bcbc57c0511ec8fcb3f6ebf3500#p2446">viewtopic.php?f=5&amp;t=1103&amp;sid=fd941bcbc57c0511ec8fcb3f6ebf3500#p2446</a><!-- l --><br /><br />I am concerned.  Do our local politicians who represent our club and our regional representatives who represent us at the USHPA level have the best intentions with respect to &quot;hang gliding&quot; at our site.<br /><br />Why doesn't Urs answer Bob Kuczewski's questions?  I would like to know the answers.  I would bet that other club members would like to know the answers as well.  <br /><br />Thank you Bob</div>

			

		</div>

		
			<dl class="postprofile" id="profile2524">
			<dt>
				<a href="memberlist9c48.php?mode=viewprofile&amp;u=1873">e j</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 11</dd><dd><strong>Joined:</strong> Tue Dec 28, 2010 7:16 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2525" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting6ae2-2.html?mode=quote&amp;f=5&amp;p=2525" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2525">Re: USHPA and Funston</a></h3>
			<p class="author"><a href="viewtopic66a5.php?p=2525#p2525"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlistfe9c.html?mode=viewprofile&amp;u=3">Daniel Pifko</a></strong> &raquo; Wed Mar 30, 2011 10:54 am </p>

			

			<div class="content">Personally, as a pilot and another club member, I'd like to see many of these issues handled offline, in person.  I'm glad to see some threads just plain fade away online.  Forums like this tend to bring out the worst in people's conversations.<br /><br />So thanks to those who are sitting on their hands, not ratcheting up the rhetoric.  Go grab a beer together and hash it out, and tell us what happened at one of the club meetings after you do.</div>

			

		</div>

		
			<dl class="postprofile" id="profile2525">
			<dt>
				<a href="memberlistfe9c.html?mode=viewprofile&amp;u=3"><img src="http://www.pifko.com/fly/images/avatar.jpg" width="60" height="80" alt="User avatar" /></a><br />
				<a href="memberlistfe9c.html?mode=viewprofile&amp;u=3">Daniel Pifko</a>
			</dt>

			<dd>Site Admin</dd>

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 249</dd><dd><strong>Joined:</strong> Tue Jan 13, 2004 5:23 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p2527" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting8051.html?mode=quote&amp;f=5&amp;p=2527" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p2527">Re: USHPA and Funston</a></h3>
			<p class="author"><a href="viewtopic31b1.php?p=2527#p2527"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944">bobk</a></strong> &raquo; Thu Mar 31, 2011 7:46 am </p>

			

			<div class="content"><blockquote><div><cite>Daniel Pifko wrote:</cite>Personally, as a pilot and another club member, I'd like to see many of these issues handled offline, in person.<br />...<br />So thanks to those who are sitting on their hands</div></blockquote><br />I generally agree with this as a first attempt. But when private discussions fail - or are refused - what's the next step? When does it finally become necessary to seek the support of the greater hang gliding community?<br /><br />You probably don't know of the efforts made to contact Urs privately or hold off-line discussions, because they were private ... and off-line. You don't know that in one of my last attempts to discuss an issue with Urs, he sent this as his reply:<br /><br /><blockquote><div><cite>Urs Kellenberger wrote:</cite>Bob, please do not send me email anymore. Contact your local RD.<br />Urs</div></blockquote><br />That was it. I was asking about a matter passed by the entire Board - including Urs - and that was his full response. I got similar responses (or no responses) from my own RDs. So where do we - as members - go from there? The only place left to go is to our fellow pilots. Thankfully, some of them are listening and they want to know what their Directors are doing and how they are voting. I hope you'll join us in asking Directors to be more transparent ... or take your own advice and sit on your own hands. (Sorry Daniel, that last line was just too easy to pass up.  <img src="images/smilies/icon_wink.html" alt=":wink:" title="Wink" /> )<br /><br />People who seek power thrive on the apathy of the masses.</div>

			<div id="sig2527" class="signature"><span style="font-size: 130%; line-height: 116%;"><span style="color: #000080"><span style="font-style: italic">Join a National Hang Gliding Organization:</span></span> <span style="font-weight: bold"><span style="color: #000080"><a href="http://ushawks.org/" class="postlink">US Hawks at ushawks.org</a></span></span></span></div>

		</div>

		
			<dl class="postprofile" id="profile2527">
			<dt>
				<a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944"><img src="download/file3928.html?avatar=1944_1390380842.jpeg" width="200" height="150" alt="User avatar" /></a><br />
				<a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944">bobk</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 138</dd><dd><strong>Joined:</strong> Tue Mar 22, 2011 1:53 pm</dd>
			<dd>
				<ul class="profile-icons">
					<li class="web-icon"><a href="http://ushawks.org/" title="WWW: http://ushawks.org"><span>Website</span></a></li>
				</ul>
			</dd>
		

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<form id="viewtopic" method="post" action="http://flyfunston.org/bbs/viewtopic.php?f=5&amp;t=1106">

	<fieldset class="display-options" style="margin-top: 0; ">
		<a href="viewtopicafa7.html?f=5&amp;t=1106&amp;start=25" class="right-box right">Next</a>
		<label>Display posts from previous: <select name="st" id="st"><option value="0" selected="selected">All posts</option><option value="1">1 day</option><option value="7">7 days</option><option value="14">2 weeks</option><option value="30">1 month</option><option value="90">3 months</option><option value="180">6 months</option><option value="365">1 year</option></select></label>
		<label>Sort by <select name="sk" id="sk"><option value="a">Author</option><option value="t" selected="selected">Post time</option><option value="s">Subject</option></select></label> <label><select name="sd" id="sd"><option value="a" selected="selected">Ascending</option><option value="d">Descending</option></select> <input type="submit" name="sort" value="Go" class="button2" /></label>
		
	</fieldset>

	</form>
	<hr />


<div class="topic-actions">
	<div class="buttons">
	
		<div class="reply-icon"><a href="postinge4b2.html?mode=reply&amp;f=5&amp;t=1106" title="Post a reply"><span></span>Post a reply</a></div>
	
	</div>

	
		<div class="pagination">
			31 posts
			 &bull; <a href="#" onclick="jumpto(); return false;" title="Click to jump to page…">Page <strong>1</strong> of <strong>2</strong></a> &bull; <span><strong>1</strong><span class="page-sep">, </span><a href="viewtopicafa7.html?f=5&amp;t=1106&amp;start=25">2</a></span>
		</div>
	
</div>


	<p></p><p><a href="viewforume774.html?f=5" class="left-box left" accesskey="r">Return to General Discussion</a></p>

	<form method="post" id="jumpbox" action="http://flyfunston.org/bbs/viewforum.php" onsubmit="if(this.f.value == -1){return false;}">

	
		<fieldset class="jumpbox">
	
			<label for="f" accesskey="j">Jump to:</label>
			<select name="f" id="f" onchange="if(this.options[this.selectedIndex].value != -1){ document.forms['jumpbox'].submit() }">
			
				<option value="-1">Select a forum</option>
			<option value="-1">------------------</option>
				<option value="9">Discussion Groups</option>
			
				<option value="5" selected="selected">&nbsp; &nbsp;General Discussion</option>
			
				<option value="8">&nbsp; &nbsp;Announcements</option>
			
				<option value="7">&nbsp; &nbsp;For Sale/Wanted</option>
			
				<option value="6">&nbsp; &nbsp;Road Trips</option>
			
				<option value="2">&nbsp; &nbsp;Meeting Minutes and Treasurer Reports</option>
			
				<option value="11">&nbsp; &nbsp;Off Topic</option>
			
			</select>
			<input type="submit" value="Go" class="button2" />
		</fieldset>
	</form>


	<h3>Who is online</h3>
	<p>Users browsing this forum: No registered users and 8 guests</p>
</div>

<div id="page-footer">

	<div class="navbar">
		<div class="inner"><span class="corners-top"><span></span></span>

		<ul class="linklist">
			<li class="icon-home"><a href="index.html">Board index</a></li>
				
			<li class="rightside"><a href="memberlista2f5.html?mode=leaders">The team</a> &bull; <a href="ucp033a.html?mode=delete_cookies">Delete all board cookies</a> &bull; All times are UTC - 8 hours [ <abbr title="Daylight Saving Time">DST</abbr> ]</li>
		</ul>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<div class="copyright">Powered by <a href="https://www.phpbb.com/">phpBB</a>&reg; Forum Software &copy; phpBB Group
		
	</div>
</div>

</div>

<div>
	<a id="bottom" name="bottom" accesskey="z"></a>
	<img src="cronb999.gif?cron_type=tidy_search" width="1" height="1" alt="cron" />
</div>

</body>

<!-- Mirrored from flyfunston.org/bbs/viewtopic.php?p=2527 by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 08 Aug 2021 20:18:26 GMT -->
</html>