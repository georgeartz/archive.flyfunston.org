<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en-us" xml:lang="en-us">

<!-- Mirrored from flyfunston.org/bbs/viewtopic.php?p=3509 by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 08 Aug 2021 20:16:49 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>

<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<meta http-equiv="content-style-type" content="text/css" />
<meta http-equiv="content-language" content="en-us" />
<meta http-equiv="imagetoolbar" content="no" />
<meta name="resource-type" content="document" />
<meta name="distribution" content="global" />
<meta name="keywords" content="" />
<meta name="description" content="" />

<title>Flyfunston &bull; View topic - Last night's meeting</title>



<!--
	phpBB style name: prosilver
	Based on style:   prosilver (this is the default phpBB3 style)
	Original author:  Tom Beddard ( http://www.subBlue.com/ )
	Modified by:
-->

<script type="text/javascript">
// <![CDATA[
	var jump_page = 'Enter the page number you wish to go to:';
	var on_page = '1';
	var per_page = '25';
	var base_url = 'viewtopic5757.php?f=5&amp;t=1443';
	var style_cookie = 'phpBBstyle';
	var style_cookie_settings = '; path=/; domain=flyfunston.org; secure';
	var onload_functions = new Array();
	var onunload_functions = new Array();

	

	/**
	* Find a member
	*/
	function find_username(url)
	{
		popup(url, 760, 570, '_usersearch');
		return false;
	}

	/**
	* New function for handling multiple calls to window.onload and window.unload by pentapenguin
	*/
	window.onload = function()
	{
		for (var i = 0; i < onload_functions.length; i++)
		{
			eval(onload_functions[i]);
		}
	};

	window.onunload = function()
	{
		for (var i = 0; i < onunload_functions.length; i++)
		{
			eval(onunload_functions[i]);
		}
	};

// ]]>
</script>
<script type="text/javascript" src="styles/prosilver/template/styleswitcher.js"></script>
<script type="text/javascript" src="styles/prosilver/template/forum_fn.js"></script>

<link href="styles/prosilver/theme/print.css" rel="stylesheet" type="text/css" media="print" title="printonly" />
<link href="style7a95.css?id=1&amp;lang=en_us" rel="stylesheet" type="text/css" media="screen, projection" />

<link href="styles/prosilver/theme/normal.css" rel="stylesheet" type="text/css" title="A" />
<link href="styles/prosilver/theme/medium.css" rel="alternate stylesheet" type="text/css" title="A+" />
<link href="styles/prosilver/theme/large.css" rel="alternate stylesheet" type="text/css" title="A++" />



</head>

<body id="phpbb" class="section-viewtopic ltr">

<div id="wrap">
	<a id="top" name="top" accesskey="t"></a>
	<div id="page-header">
		<div class="headerbar">
			<div class="inner"><span class="corners-top"><span></span></span>

			<div id="site-description">
				<a href="index.html" title="Board index" id="logo"><img src="styles/prosilver/imageset/site_logo.gif" width="149" height="52" alt="" title="" /></a>
				<h1>Flyfunston</h1>
				<p>Hang Gliding at Fort Funston</p>
				<p class="skiplink"><a href="#start_here">Skip to content</a></p>
			</div>

		
			<div id="search-box">
				<form action="http://flyfunston.org/bbs/search.php" method="get" id="search">
				<fieldset>
					<input name="keywords" id="keywords" type="text" maxlength="128" title="Search for keywords" class="inputbox search" value="Search…" onclick="if(this.value=='Search…')this.value='';" onblur="if(this.value=='')this.value='Search…';" />
					<input class="button2" value="Search" type="submit" /><br />
					<a href="search.html" title="View the advanced search options">Advanced search</a> 
				</fieldset>
				</form>
			</div>
		

			<span class="corners-bottom"><span></span></span></div>
		</div>

		<div class="navbar">
			<div class="inner"><span class="corners-top"><span></span></span>

			<ul class="linklist navlinks">
				<li class="icon-home"><a href="index.html" accesskey="h">Board index</a>  <strong>&#8249;</strong> <a href="viewforumfdc5.html?f=9">Discussion Groups</a> <strong>&#8249;</strong> <a href="viewforume774.html?f=5">General Discussion</a></li>

				<li class="rightside"><a href="#" onclick="fontsizeup(); return false;" onkeypress="return fontsizeup(event);" class="fontsize" title="Change font size">Change font size</a></li>

				<li class="rightside"><a href="viewtopic3cf8.html?f=5&amp;t=1443&amp;view=print" title="Print view" accesskey="p" class="print">Print view</a></li>
			</ul>

			

			<ul class="linklist rightside">
				<li class="icon-faq"><a href="faq.html" title="Frequently Asked Questions">FAQ</a></li>
				
					<li class="icon-logout"><a href="ucp26c3.php?mode=login" title="Login" accesskey="x">Login</a></li>
				
			</ul>

			<span class="corners-bottom"><span></span></span></div>
		</div>

	</div>

	<a name="start_here"></a>
	<div id="page-body">
		
<h2><a href="viewtopic5757.php?f=5&amp;t=1443">Last night's meeting</a></h2>
<!-- NOTE: remove the style="display: none" when you want to have the forum description on the topic body --><div style="display: none !important;">Talk about Hang Gliding at Ft Funston and the Fellow Feathers Club.<br /></div>

<div class="topic-actions">

	<div class="buttons">
	
		<div class="reply-icon"><a href="posting28ea.html?mode=reply&amp;f=5&amp;t=1443" title="Post a reply"><span></span>Post a reply</a></div>
	
	</div>

	
		<div class="search-box">
			<form method="get" id="topic-search" action="http://flyfunston.org/bbs/search.php">
			<fieldset>
				<input class="inputbox search tiny"  type="text" name="keywords" id="search_keywords" size="20" value="Search this topic…" onclick="if(this.value=='Search this topic…')this.value='';" onblur="if(this.value=='')this.value='Search this topic…';" />
				<input class="button2" type="submit" value="Search" />
				<input type="hidden" name="t" value="1443" />
<input type="hidden" name="sf" value="msgonly" />

			</fieldset>
			</form>
		</div>
	
		<div class="pagination">
			31 posts
			 &bull; <a href="#" onclick="jumpto(); return false;" title="Click to jump to page…">Page <strong>1</strong> of <strong>2</strong></a> &bull; <span><strong>1</strong><span class="page-sep">, </span><a href="viewtopicf35b.html?f=5&amp;t=1443&amp;start=25">2</a></span>
		</div>
	

</div>
<div class="clear"></div>


	<div id="p3504" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postinga7ea.php?mode=quote&amp;f=5&amp;p=3504" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 class="first"><a href="#p3504">Last night's meeting</a></h3>
			<p class="author"><a href="viewtopic9036.html?p=3504#p3504"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a></strong> &raquo; Wed Apr 10, 2013 2:21 am </p>

			

			<div class="content">Tracey said: &quot;I'm hoping we can debate the issues that will be discussed at tomorrow's meeting in a mutually respectful manner so we can represent our club well to the park's department. &quot;<br /><br />Sadly, that was not to be.  Far from it in fact.  Unfortunately, I was not given the opportunity to make a few brief statements, but to be fair, there was no chance at all I was going to get through to the angry mob. <br /><br />The Funston hang glider pilots have long asked a favor of the local paragliding community - namely &quot;how about if you guys let this space be ours&quot;.  In return for that favor request, the Fellow Feathers are willing to offer only blind rage, hate, intimidation, and threats.    I for one am more than happy to grant the favor that's asked - but not in return for the astonishing level of hate that is offered.  Instead, I requested a trivial accommodation.  And was treated spectacularly poorly for that proposal.<br /><br />I understand that Tracey has not succeeded in conveying to the membership that any intimidation in the air, regardless of location or wing type, will be met with club suspensions.  And failing that, the issue will be addressed to the rangers, USHPA, the FAA, and local authorities.    I fear that Funston pilots won't understand the nature of the situation until they are suspended (or worse) for their actions, or until they injure or kill (or get injured or killed) by their own actions.   Very sad indeed.<br /><br />There are now more PG pilots than HG pilots in the U.S. and the imbalance is growing rapidly.  Going this far out of your way to make enemies with that group may not be in your best interest.</div>

			

		</div>

		
			<dl class="postprofile" id="profile3504">
			<dt>
				<a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 93</dd><dd><strong>Joined:</strong> Wed Apr 20, 2011 11:40 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3505" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postingd915.php?mode=quote&amp;f=5&amp;p=3505" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3505">Re: Last night's meeting</a></h3>
			<p class="author"><a href="viewtopicc519.html?p=3505#p3505"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist2501.html?mode=viewprofile&amp;u=41">diev</a></strong> &raquo; Wed Apr 10, 2013 7:29 am </p>

			

			<div class="content">&quot;Trivial accommodation......with the imbalance growing rapidly&quot;....scratching my head trying to figure this out.<br />Last night's meeting will not be last night's meeting tomorrow(4/11).<br />Diev</div>

			<div id="sig3505" class="signature">Diev Hart<br />KG6UST<br /><!-- m --><a class="postlink" href="http://www.dievhart.com/hangglide.html">http://www.dievhart.com/hangglide.html</a><!-- m --></div>

		</div>

		
			<dl class="postprofile" id="profile3505">
			<dt>
				<a href="memberlist2501.html?mode=viewprofile&amp;u=41">diev</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 253</dd><dd><strong>Joined:</strong> Tue Sep 28, 2004 1:40 pm</dd><dd><strong>Location:</strong> Santa Cruz, CA</dd>
			<dd>
				<ul class="profile-icons">
					<li class="web-icon"><a href="http://www.dievhart.com/hangglide.html" title="WWW: http://www.dievhart.com/hangglide.html"><span>Website</span></a></li><li class="yahoo-icon"><a href="http://edit.yahoo.com/config/send_webmesg?.target=dievhart&amp;.src=pg" onclick="popup(this.href, 780, 550); return false;" title="YIM"><span>YIM</span></a></li>
				</ul>
			</dd>
		

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3506" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postingf581.html?mode=quote&amp;f=5&amp;p=3506" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3506">Re: Last night's meeting</a></h3>
			<p class="author"><a href="viewtopic858f.html?p=3506#p3506"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a></strong> &raquo; Wed Apr 10, 2013 12:25 pm </p>

			

			<div class="content">&gt;&gt; &quot;Trivial accommodation......with the imbalance growing rapidly&quot;....scratching my head trying to figure this out.<br /><br />It wasn't intended to be in code.  Currently (and for many years) the Funston hang gliding community has claimed a region of airspace for their own - contrary to federal law.  There is in fact a long ridge, and I'm willing to grant the favor the Funston pilots ask - but not if the only thing on offer is threat, insult, and intimidation.    The imbalance growing rapidly refers to the number of people paragliding to the number of people hang gliding.  PG outnumbers HG and that imbalance continues to grow.  I predict there will be a time when Funston pilots will wish they had taken an approach other than intimidation.  I think that time may not be so far off.  In an environment of friendly negotiation I'd be quite happy to grant your request for only the smallest accommodation.  Under the current and long standing arrangement in which Funston pilots have declared war on all paragliding everywhere, I think you can expect a change to a fully biwingual site - or worse.<br /><br />&gt;&gt; Last night's meeting will not be last night's meeting tomorrow(4/11).<br /><br />Yes, and today won't be yesterday the day after tomorrow.  What's your point?</div>

			

		</div>

		
			<dl class="postprofile" id="profile3506">
			<dt>
				<a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 93</dd><dd><strong>Joined:</strong> Wed Apr 20, 2011 11:40 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3507" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postingede9.php?mode=quote&amp;f=5&amp;p=3507" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3507">Re: Last night's meeting</a></h3>
			<p class="author"><a href="viewtopic60a4.html?p=3507#p3507"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist2501.html?mode=viewprofile&amp;u=41">diev</a></strong> &raquo; Wed Apr 10, 2013 12:55 pm </p>

			

			<div class="content">My point was that next month when we have another meeting...people might think you are talking about it....the next day.<br />Some Funston pilots don't hate ALL PGs, they just see their numbers increasing (along with carnage?) and are scared of loosing our small liftban.... forcing them on the ground. <br />I see both sides. What I don't understand is why would you, or any PG pilot, want to make someone else not be able to fly by sitting in that small liftban?<br />Diev</div>

			<div id="sig3507" class="signature">Diev Hart<br />KG6UST<br /><!-- m --><a class="postlink" href="http://www.dievhart.com/hangglide.html">http://www.dievhart.com/hangglide.html</a><!-- m --></div>

		</div>

		
			<dl class="postprofile" id="profile3507">
			<dt>
				<a href="memberlist2501.html?mode=viewprofile&amp;u=41">diev</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 253</dd><dd><strong>Joined:</strong> Tue Sep 28, 2004 1:40 pm</dd><dd><strong>Location:</strong> Santa Cruz, CA</dd>
			<dd>
				<ul class="profile-icons">
					<li class="web-icon"><a href="http://www.dievhart.com/hangglide.html" title="WWW: http://www.dievhart.com/hangglide.html"><span>Website</span></a></li><li class="yahoo-icon"><a href="http://edit.yahoo.com/config/send_webmesg?.target=dievhart&amp;.src=pg" onclick="popup(this.href, 780, 550); return false;" title="YIM"><span>YIM</span></a></li>
				</ul>
			</dd>
		

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3508" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting9044.php?mode=quote&amp;f=5&amp;p=3508" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3508">Re: Last night's meeting</a></h3>
			<p class="author"><a href="viewtopic1f6f.html?p=3508#p3508"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a></strong> &raquo; Wed Apr 10, 2013 1:06 pm </p>

			

			<div class="content">&gt;&gt; My point was that next month when we have another meeting...people might think you are talking about it....the next day.<br /><br />Fair point.  If it's possible to change the subject, I'll be happy to.<br /><br />&gt;&gt; Some Funston pilots don't hate ALL PGs, they just see their numbers increasing (along with carnage?) and are scared of loosing our small liftban....<br /><br />That's precisely why they should come to a genuine arrangement in which we agree NOT to fly the Funston ridge.  That was what my proposal was all about.  The Funston pilots can have exactly what they want (i.e. a completely PG-free ridge) in exchange for something they don't actually give a shit about (a tiny corner of the property between the bushes, the fence, and the ridge) for a tiny number of HG/PG pilots, on rare occasion.<br /><br />&gt;&gt;  What I don't understand is why would you, or any PG pilot, want to make someone else not be able to fly by sitting in that small liftban?<br /><br />I do not want to do that.  The Funston pilots (every single one at the meeting) want to continue to keep control over that airspace through intimidation of one type or another.  Aside from exercising my rights to that airspace (which are exactly the same as everyone else's) how do you propose I proceed?<br /><br />What I don't understand is why the HG pilots would force such a ridiculous result over a tiny piece of property that means nothing to them.<br /><br />And before offering me the tired and faulty &quot;camel's nose&quot; argument, keep in mind that the thing the HG pilots are afraid of is being crowded out of the lift ban.  That camel is already fully in the tent.  It's time to think about how to get the camel out of the tent - and I offered a proposal that would do that.</div>

			

		</div>

		
			<dl class="postprofile" id="profile3508">
			<dt>
				<a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 93</dd><dd><strong>Joined:</strong> Wed Apr 20, 2011 11:40 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3509" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting369e.html?mode=quote&amp;f=5&amp;p=3509" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3509">Re: Last night's meeting</a></h3>
			<p class="author"><a href="viewtopic5ed4.php?p=3509#p3509"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist2501.html?mode=viewprofile&amp;u=41">diev</a></strong> &raquo; Wed Apr 10, 2013 2:34 pm </p>

			

			<div class="content">Your forgetting Steve M (who read your idea and was the only pilot I saw voting for it)<br />I didn't feel the need to vote as I could see where it was going....so that is two right off the top of my head.<br />My issue is...(and I feel a lot of others is).... say we allow just these special PG pilots to land. Why wouldn't some other PG pilot all ready in the air not think they could land there also?  Seems logicle does it not?<br />Could you proceed by flying a HG from that spot (in that air)?<br />I don't see a camel but I feel others see you as the nose of one and why this is such a heated topic....(and boy is it a fat camel they see that would fill every space in the tent pushing them outside in the cold)<br />Diev</div>

			<div id="sig3509" class="signature">Diev Hart<br />KG6UST<br /><!-- m --><a class="postlink" href="http://www.dievhart.com/hangglide.html">http://www.dievhart.com/hangglide.html</a><!-- m --></div>

		</div>

		
			<dl class="postprofile" id="profile3509">
			<dt>
				<a href="memberlist2501.html?mode=viewprofile&amp;u=41">diev</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 253</dd><dd><strong>Joined:</strong> Tue Sep 28, 2004 1:40 pm</dd><dd><strong>Location:</strong> Santa Cruz, CA</dd>
			<dd>
				<ul class="profile-icons">
					<li class="web-icon"><a href="http://www.dievhart.com/hangglide.html" title="WWW: http://www.dievhart.com/hangglide.html"><span>Website</span></a></li><li class="yahoo-icon"><a href="http://edit.yahoo.com/config/send_webmesg?.target=dievhart&amp;.src=pg" onclick="popup(this.href, 780, 550); return false;" title="YIM"><span>YIM</span></a></li>
				</ul>
			</dd>
		

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3510" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting9586.html?mode=quote&amp;f=5&amp;p=3510" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3510">Re: Last night's meeting</a></h3>
			<p class="author"><a href="viewtopic3673.php?p=3510#p3510"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a></strong> &raquo; Wed Apr 10, 2013 2:46 pm </p>

			

			<div class="content"><blockquote><div><cite>diev wrote:</cite>Your forgetting Steve M (who read your idea and was the only pilot I saw voting for it)</div></blockquote><br /><br />Good point.  You're right that there was one pilot that voted for it.  Now technically, Steve can't vote since he's not a paid member - but that's another kettle of fish.  <br /><br />&gt;&gt;I didn't feel the need to vote as I could see where it was going....so that is two right off the top of my head.<br /><br />That's only two if you're suggesting that you would vote for it.  Is that what you're saying?<br /><br />&gt;&gt; My issue is...(and I feel a lot of others is).... say we allow just these special PG pilots to land. Why wouldn't some other PG pilot all ready in the air not think they could land there also? <br /><br />Rules.  Same thing that keeps hang II's from launching and landing at the Ft.  We have always self policed.  Every pilot launching and landing at the Ft. would have a helmet sticker.  We would make it perfectly clear this is a requirement.  Anyone landing their illegally would be ticketed and fined - or simply given a one-time warning if that's what the club decides.  <br /><br />&gt;&gt; Could you proceed by flying a HG from that spot (in that air)?<br /><br />I'm sorry - I don't understand.<br /><br />&gt;&gt; I don't see a camel but I feel others see you as the nose of one and why this is such a heated topic....(and boy is it a fat camel they see that would fill every space in the tent pushing them outside in the cold)<br /><br />But do you also see that what they're worried about is specifically what we're already allowed to do.  If I stop honoring the request to keep clear of that airspace - the whole camel is in the tent.<br /><br />Incidentally, I feel as strongly about this as Emily and Larry.  I just don't have the &quot;flair&quot; to convey it as they do.</div>

			

		</div>

		
			<dl class="postprofile" id="profile3510">
			<dt>
				<a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 93</dd><dd><strong>Joined:</strong> Wed Apr 20, 2011 11:40 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3511" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting6466.html?mode=quote&amp;f=5&amp;p=3511" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3511">Re: Last night's meeting</a></h3>
			<p class="author"><a href="viewtopic8bf7.php?p=3511#p3511"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist2501.html?mode=viewprofile&amp;u=41">diev</a></strong> &raquo; Wed Apr 10, 2013 4:08 pm </p>

			

			<div class="content">No, not what I was saying...just that it was not &quot;every pilot at the meeting&quot; as you stated.<br /><br />That is why a lot of pilots don't want to change the &quot;Rules&quot;, they seem to be working fine with no PGs in our small liftban.<br />How would it be made clear to some stranger from out of town who is in the air (flying the unregulated dumps) when they see you land it that spot and want to copy?<br /><br />No I can't see it, as PGs are not allowed to. As per the deal with the GGNRA, PGs can launch the stables and in return only fly south of the bowl and not launch or land at the fort.<br />If you stop honoring the GGNRAs agreement and fly north of the bowl (or launch/kite/land at the fort) I would hope and prey that pilots did not take the matter upon themselves but rather just reported the incident to the propper authorities.<br /><br />Diev</div>

			<div id="sig3511" class="signature">Diev Hart<br />KG6UST<br /><!-- m --><a class="postlink" href="http://www.dievhart.com/hangglide.html">http://www.dievhart.com/hangglide.html</a><!-- m --></div>

		</div>

		
			<dl class="postprofile" id="profile3511">
			<dt>
				<a href="memberlist2501.html?mode=viewprofile&amp;u=41">diev</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 253</dd><dd><strong>Joined:</strong> Tue Sep 28, 2004 1:40 pm</dd><dd><strong>Location:</strong> Santa Cruz, CA</dd>
			<dd>
				<ul class="profile-icons">
					<li class="web-icon"><a href="http://www.dievhart.com/hangglide.html" title="WWW: http://www.dievhart.com/hangglide.html"><span>Website</span></a></li><li class="yahoo-icon"><a href="http://edit.yahoo.com/config/send_webmesg?.target=dievhart&amp;.src=pg" onclick="popup(this.href, 780, 550); return false;" title="YIM"><span>YIM</span></a></li>
				</ul>
			</dd>
		

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3512" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting0f66.html?mode=quote&amp;f=5&amp;p=3512" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3512">Re: Last night's meeting</a></h3>
			<p class="author"><a href="viewtopic354f.html?p=3512#p3512"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a></strong> &raquo; Wed Apr 10, 2013 4:34 pm </p>

			

			<div class="content"><blockquote><div><cite>diev wrote:</cite>No, not what I was saying...just that it was not &quot;every pilot at the meeting&quot; as you stated.</div></blockquote><br /><br />That's why I said &quot;good point&quot;.  You're right that ONE pilot voted for it - the pilot that proposed it.<br /><br />&gt;&gt; That is why a lot of pilots don't want to change the &quot;Rules&quot;, they seem to be working fine with no PGs in our small liftban.<br /><br />Yes, I understand that they want to simply continue to keep PG's out of that airspace through intimidation.  Do you understand that that's not an option.  They clearly don't.<br /><br />&gt;&gt; As per the deal with the GGNRA, PGs can launch the stables and in return only fly south of the bowl and not launch or land at the fort.<br /><br />I have no such agreement with the GGNRA.  That is apparently a deal they made with BAPA.  I'm not a BAPA member.  BAPA doesn't administer the site.  BAPA can't kick me out of BAPA.<br /><br />The LAW says that only the FAA has jurisdiction over the airspace.<br /><br />&gt;&gt; If you stop honoring the GGNRAs agreement and fly north of the bowl (or launch/kite/land at the fort) I would hope and prey that pilots did not take the matter upon themselves but rather just reported the incident to the propper authorities.<br /><br />Me too.  The proper authorities are the FAA.  They can give you the bad news.<br /><br />The solution of course is perfectly simple... go with the proposal Steve made on my behalf (or ANY fair proposal) and no one gets in anyone's way.  On the other hand, the FF can continue to operate out of fear, intimidation, and hatred, and really fuck up the whole deal.</div>

			

		</div>

		
			<dl class="postprofile" id="profile3512">
			<dt>
				<a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 93</dd><dd><strong>Joined:</strong> Wed Apr 20, 2011 11:40 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3513" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting9eae.html?mode=quote&amp;f=5&amp;p=3513" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3513">Re: Last night's meeting</a></h3>
			<p class="author"><a href="viewtopic580b.html?p=3513#p3513"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist2501.html?mode=viewprofile&amp;u=41">diev</a></strong> &raquo; Wed Apr 10, 2013 5:08 pm </p>

			

			<div class="content">Not through intimidation but through Rules and agreements with self coverning members who care about the freedom of freeflight.<br />I understand the desire for intimidation when that freedom is threatened.<br />Diev</div>

			<div id="sig3513" class="signature">Diev Hart<br />KG6UST<br /><!-- m --><a class="postlink" href="http://www.dievhart.com/hangglide.html">http://www.dievhart.com/hangglide.html</a><!-- m --></div>

		</div>

		
			<dl class="postprofile" id="profile3513">
			<dt>
				<a href="memberlist2501.html?mode=viewprofile&amp;u=41">diev</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 253</dd><dd><strong>Joined:</strong> Tue Sep 28, 2004 1:40 pm</dd><dd><strong>Location:</strong> Santa Cruz, CA</dd>
			<dd>
				<ul class="profile-icons">
					<li class="web-icon"><a href="http://www.dievhart.com/hangglide.html" title="WWW: http://www.dievhart.com/hangglide.html"><span>Website</span></a></li><li class="yahoo-icon"><a href="http://edit.yahoo.com/config/send_webmesg?.target=dievhart&amp;.src=pg" onclick="popup(this.href, 780, 550); return false;" title="YIM"><span>YIM</span></a></li>
				</ul>
			</dd>
		

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3514" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting45b3.html?mode=quote&amp;f=5&amp;p=3514" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3514">Re: Last night's meeting</a></h3>
			<p class="author"><a href="viewtopic5191.html?p=3514#p3514"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a></strong> &raquo; Wed Apr 10, 2013 5:33 pm </p>

			

			<div class="content"><blockquote><div><cite>diev wrote:</cite>I understand the desire for intimidation when that freedom is threatened.<br />Diev</div></blockquote><br /><br />My rights to that airspace are *exactly* the same as your rights.  But I understand that the gang that claims a corner feels threatened when law abiding citizen refuse to recognize the gang's authority to take their corner.  Your freedom is being threatened in exactly the same way that whites' freedoms were threatened when black folks refused to sit in the back of the bus.  It must feel really scary to have such freedoms threatened.<br /><br /><br />Fellow Feathers members strafe and attack PG's and PG launches just for the hell of it - nowhere near the airspace that they claim for their own.  They were still doing it this Sunday.  When Brad attacked me I was south of the Stables launch and had not been north of it.<br /><br />You claim to care very much about the rules, but you have a member and instructor that launched his hang glider from a GGNRA PG-ONLY launch a few days ago.  JUST FUCKING IMAGINE  what would have happened had I tried to launch a PG from Funston.<br /><br />If you want to know who's at fault for the frictions between hang gliders and paragliders, it is 100% hang gliders.   <br /><br />The Fellow Feathers are quite simply a club that cannot and will not follow the laws or enforce their own rules.  How much evidence would you like.  I'll be happy to provide it.</div>

			

		</div>

		
			<dl class="postprofile" id="profile3514">
			<dt>
				<a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 93</dd><dd><strong>Joined:</strong> Wed Apr 20, 2011 11:40 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3515" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting540a.php?mode=quote&amp;f=5&amp;p=3515" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3515">Re: Last night's meeting</a></h3>
			<p class="author"><a href="viewtopicb984.html?p=3515#p3515"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a></strong> &raquo; Wed Apr 10, 2013 11:27 pm </p>

			

			<div class="content">So the club wants to claim it's all fair and balanced because the GGNRA gave PG pilots a PG only launch.  But no problem for a Funston pilot and instructor to launch there in the midst of all the current tension.  Of course, to be fair, no one at Funston ever claimed there was a need to for any sort of symmetry or fairness.<br /><br />Let's just imagine that was a picture of me launching a PG at Funston.<br /><br />I know &quot;Funston is sacred&quot; according to Emily - and I should be ashamed for bringing a proposal to reach a mutual and peaceful agreement between HG and PG pilots at the coast - but you folks sure don't act like there's much there worth saving.<br /><br />I'd like to remind folks of this rule:<br />Pilots must fly safely and courteously, clearing all turns and maneuvers, observing International <br />Ridge Soaring Rules and avoiding any conduct that could reasonably be expected to create <br />conflicts with other pilots. Harassment and intimidation are prohibited. <br /><br />That applies to ANY pilot harassing ANY other pilot in ANY type of craft in ANY airspace.<br /><br />And the Feds add:<br /><br />FAR 103.9: &quot;No person may operate any ultralight vehicle in a manner that creates a hazard to other persons or property.&quot;<br /><br />FAR 103.13 (A) &quot;Each person operating an ultralight vehicle shall maintain vigilance so as to see and avoid aircraft and shall yield the right-of-way to all aircraft.&quot;<br />FAR 103.13: (B) &quot;No person may operate an ultralight vehicle in a manner that creates a collision hazard with respect to any aircraft.&quot;<br /><br />These apply to ANY pilot harassing ANY other pilot in ANY type of craft in ANY airspace.<br /><br />And the civil code covers this under gross negligence.</div>

			
				<dl class="attachbox">
					<dt>Attachments</dt>
					
						<dd>
		<dl class="file">
			<dt class="attach-image"><img src="download/file619c.php?id=62" alt="Simpson on PG launch.gif" onclick="viewableArea(this);" /></dt>
			
			<dd>Simpson on PG launch.gif (121.61 KiB) Viewed 75159 times</dd>
		</dl>
		</dd>
					
				</dl>
			

		</div>

		
			<dl class="postprofile" id="profile3515">
			<dt>
				<a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 93</dd><dd><strong>Joined:</strong> Wed Apr 20, 2011 11:40 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3516" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting47d9.html?mode=quote&amp;f=5&amp;p=3516" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3516">Re: Last night's meeting</a></h3>
			<p class="author"><a href="viewtopic99c1.html?p=3516#p3516"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist2501.html?mode=viewprofile&amp;u=41">diev</a></strong> &raquo; Thu Apr 11, 2013 9:05 am </p>

			

			<div class="content">I can't seem to find the wording about the stables launch, weather it is a PG ONLY launch or PGs are just allowed to launch from this location along with everyone else....can anyone point me to where this would be found on-line?<br />Is there some wording about re-launching along any of the lower clifts anywhere on-line?<br />Diev</div>

			<div id="sig3516" class="signature">Diev Hart<br />KG6UST<br /><!-- m --><a class="postlink" href="http://www.dievhart.com/hangglide.html">http://www.dievhart.com/hangglide.html</a><!-- m --></div>

		</div>

		
			<dl class="postprofile" id="profile3516">
			<dt>
				<a href="memberlist2501.html?mode=viewprofile&amp;u=41">diev</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 253</dd><dd><strong>Joined:</strong> Tue Sep 28, 2004 1:40 pm</dd><dd><strong>Location:</strong> Santa Cruz, CA</dd>
			<dd>
				<ul class="profile-icons">
					<li class="web-icon"><a href="http://www.dievhart.com/hangglide.html" title="WWW: http://www.dievhart.com/hangglide.html"><span>Website</span></a></li><li class="yahoo-icon"><a href="http://edit.yahoo.com/config/send_webmesg?.target=dievhart&amp;.src=pg" onclick="popup(this.href, 780, 550); return false;" title="YIM"><span>YIM</span></a></li>
				</ul>
			</dd>
		

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3517" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postingde79.php?mode=quote&amp;f=5&amp;p=3517" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3517">Re: Last night's meeting</a></h3>
			<p class="author"><a href="viewtopice9f8.php?p=3517#p3517"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a></strong> &raquo; Thu Apr 11, 2013 4:23 pm </p>

			

			<div class="content">The Stables launch was provided for PG's.  The folks at the meeting were perfectly happy to scream repeatedly that I should STFU because I was given a PG launch (I was not in fact - as I'm not a member of BAPA).<br /><br />The FF rules describe only one HG launch.  That's the designated HG launch. <br /><br />From the rules:<br /><br />4. Pilots must fly straight and level in the launch window, speed not to exceed 30 MPH. The <br />launch window is from the sand trail just south of launch, to the north end of the observation deck, <br />100' up, 100' out, and 25’ below launch.  <br /><br />6. Pilots must launch from the designated launch area on the south side of the observation deck. <br />The designated landing zone is the field south of the parking lot and should be used whenever <br />possible. <br /><br />But no worries. The rules that apply to me do not apply to others.</div>

			

		</div>

		
			<dl class="postprofile" id="profile3517">
			<dt>
				<a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 93</dd><dd><strong>Joined:</strong> Wed Apr 20, 2011 11:40 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3518" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting3af7.php?mode=quote&amp;f=5&amp;p=3518" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3518">Re: Last night's meeting</a></h3>
			<p class="author"><a href="viewtopicb1df.html?p=3518#p3518"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist2501.html?mode=viewprofile&amp;u=41">diev</a></strong> &raquo; Thu Apr 11, 2013 6:02 pm </p>

			

			<div class="content">Yeah I found all that but I can't find the wording about the Stables being a PG ONLY launch.....or even the wording for the Stables launch...<br />Diev</div>

			<div id="sig3518" class="signature">Diev Hart<br />KG6UST<br /><!-- m --><a class="postlink" href="http://www.dievhart.com/hangglide.html">http://www.dievhart.com/hangglide.html</a><!-- m --></div>

		</div>

		
			<dl class="postprofile" id="profile3518">
			<dt>
				<a href="memberlist2501.html?mode=viewprofile&amp;u=41">diev</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 253</dd><dd><strong>Joined:</strong> Tue Sep 28, 2004 1:40 pm</dd><dd><strong>Location:</strong> Santa Cruz, CA</dd>
			<dd>
				<ul class="profile-icons">
					<li class="web-icon"><a href="http://www.dievhart.com/hangglide.html" title="WWW: http://www.dievhart.com/hangglide.html"><span>Website</span></a></li><li class="yahoo-icon"><a href="http://edit.yahoo.com/config/send_webmesg?.target=dievhart&amp;.src=pg" onclick="popup(this.href, 780, 550); return false;" title="YIM"><span>YIM</span></a></li>
				</ul>
			</dd>
		

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3519" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting2f6f.html?mode=quote&amp;f=5&amp;p=3519" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3519">Re: Last night's meeting</a></h3>
			<p class="author"><a href="viewtopic3e0b.php?p=3519#p3519"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a></strong> &raquo; Thu Apr 11, 2013 6:30 pm </p>

			

			<div class="content"><blockquote><div><cite>diev wrote:</cite>Yeah I found all that but I can't find the wording about the Stables being a PG ONLY launch.....or even the wording for the Stables launch...<br />Diev</div></blockquote><br /><br />The rules say:<br /><br />A) You must launch only at the designated launch.<br />B) The designated launch is the area immediately south of the observation deck.<br /><br />That means he was not at a legal launch.</div>

			

		</div>

		
			<dl class="postprofile" id="profile3519">
			<dt>
				<a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 93</dd><dd><strong>Joined:</strong> Wed Apr 20, 2011 11:40 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3520" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting1695.html?mode=quote&amp;f=5&amp;p=3520" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3520">Re: Last night's meeting</a></h3>
			<p class="author"><a href="viewtopicb0ec.html?p=3520#p3520"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist9acc.html?mode=viewprofile&amp;u=126">Dan Brown</a></strong> &raquo; Thu Apr 11, 2013 8:34 pm </p>

			

			<div class="content">A number of years ago I helped write the permit for the Stables Launch. The Launch is separate and apart from Funston. Funston rules do not apply to the Launch. In those days paragliding was relatively new and some paraglider pilots wanted a launch site on the lower cliff. Hang glider pilots occasionally launched from the area but mostly flew back and forth. <br /><br />Fellow Feathers supported the paraglider launch application on the condition that paragliders remain south of the Bowl and the permit was written accordingly. As I recall there was no discussion about the launch being exclusively paragliding and hang glider pilots sometimes used it when they landed on the beach.<br /><br />The launch was called the Stables because paraglider pilots parked their vehicles by the Stables and walked in. Initially the launch was heavily used but over the years at least when I flew at Funston was almost abandoned probably because of the popularity and easy access of the Dumps. Also the typography of the area was altered when the Olympic Club again rebuilt another soon to be washed away ocean course.</div>

			

		</div>

		
			<dl class="postprofile" id="profile3520">
			<dt>
				<a href="memberlist9acc.html?mode=viewprofile&amp;u=126">Dan Brown</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 88</dd><dd><strong>Joined:</strong> Fri Apr 01, 2005 2:01 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3521" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting795a.php?mode=quote&amp;f=5&amp;p=3521" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3521">Re: Last night's meeting</a></h3>
			<p class="author"><a href="viewtopicd4fd.html?p=3521#p3521"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a></strong> &raquo; Thu Apr 11, 2013 10:26 pm </p>

			

			<div class="content"><blockquote><div><cite>Dan Brown wrote:</cite>Funston rules do not apply to the Launch.</div></blockquote><br /><br />Funston rules don't apply to Funston regulars.  If they did we wouldn't have people charging for tandems, landing on launch, doing aerobatics in the launch window, voting without paying club dues, etc.  I'd think club rules would preclude pilots from flying stoned, but I guess they figure that that's also a sacred Funston tradition. Maybe they figure that's the FAA's problem and that they don't have to enforce FAA rules.<br /><br />Safety first!</div>

			

		</div>

		
			<dl class="postprofile" id="profile3521">
			<dt>
				<a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 93</dd><dd><strong>Joined:</strong> Wed Apr 20, 2011 11:40 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3524" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postingaa57.html?mode=quote&amp;f=5&amp;p=3524" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3524">Re: Last night's meeting</a></h3>
			<p class="author"><a href="viewtopic1de4.html?p=3524#p3524"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a></strong> &raquo; Fri Apr 12, 2013 9:54 pm </p>

			

			<div class="content">Wow - things got pretty quiet with respect to all the rules the FF's don't even pretend to enforce.    Basically the only ones enforced are the ones you have no legal right to - like keeping unwanted aircraft out of the airspace that you deem your own.</div>

			

		</div>

		
			<dl class="postprofile" id="profile3524">
			<dt>
				<a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 93</dd><dd><strong>Joined:</strong> Wed Apr 20, 2011 11:40 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3526" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting64de.php?mode=quote&amp;f=5&amp;p=3526" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3526">Re: Last night's meeting</a></h3>
			<p class="author"><a href="viewtopicb127.html?p=3526#p3526"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberliste69f.html?mode=viewprofile&amp;u=15" style="color: #AA0000;" class="username-coloured">Steve Rodrigues</a></strong> &raquo; Sat Apr 13, 2013 9:49 am </p>

			

			<div class="content">Rick,<br /><br />You are a man of principle and I can appreciate that. But, a wise man will balance one principle with another to determine the best course of action. It is my opinion that you are so focused on one principle that you are ignoring other principles of equal or greater value.<br /><br />The basic principle that we are concerned with is the right for a pilot to fly their aircraft anywhere they please in FAA controlled airspace. (Observing FAA regulations of course)<br /><br />Here are some parameters I would like us to consider: There is 2.8 +- miles of coast between the Tomcat PG launch and the south end of the Training Bowl. There is 0.94 +- miles of coast between the south end of the Training Bowl and the gap at the north end of Fort Funston.  The reality is that in light wind conditions, which are very common many days of the year, paraglider pilots are able to fly about three times as much coastline compared to hang glider pilots.<br /><br />If, on a light wind day, paraglider pilots were to use the entire 3.74 +- miles of available coastline, hang glider pilots would have ZERO coastline to fly. In essence, this means that paraglider pilots exercising their right to FAA airspace would be depriving hang glider pilots of that very same right.<br /><br />Here is the question I respectfully request you ask yourself:<br />Given that paraglider pilots have 3 times as much coastline to fly as hang glider pilots, is it morally right for them to take the last quarter of coastline and deprive hang glider pilots of their ability to fly at all?</div>

			<div id="sig3526" class="signature">USHPA # 30605<br />H-5, Mentor and Observer</div>

		</div>

		
			<dl class="postprofile" id="profile3526">
			<dt>
				<a href="memberliste69f.html?mode=viewprofile&amp;u=15"><img src="download/file9b05.php?avatar=15_1575056796.jpg" width="200" height="149" alt="User avatar" /></a><br />
				<a href="memberliste69f.html?mode=viewprofile&amp;u=15" style="color: #AA0000;" class="username-coloured">Steve Rodrigues</a>
			</dt>

			<dd>Site Admin</dd>

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 723</dd><dd><strong>Joined:</strong> Mon May 24, 2004 10:57 pm</dd><dd><strong>Location:</strong> Brisbane, California</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3527" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting948c.php?mode=quote&amp;f=5&amp;p=3527" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3527">Re: Last night's meeting</a></h3>
			<p class="author"><a href="viewtopiccaf8.html?p=3527#p3527"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a></strong> &raquo; Sat Apr 13, 2013 1:21 pm </p>

			

			<div class="content"><blockquote><div><cite>Steve Rodrigues wrote:</cite>You are a man of principle and I can appreciate that.</div></blockquote><br /><br />Thank you.<br /><br /><blockquote class="uncited"><div>But, a wise man will balance one principle with another to determine the best course of action.</div></blockquote><br /><br />I assure you I'm doing just that.<br /><br /><blockquote class="uncited"><div>It is my opinion that you are so focused on one principle that you are ignoring other principles of equal or greater value.</div></blockquote><br /><br />We'll have to agree to disagree here.  The Fellow Feathers have been an aggressive, lawless, PG hating mob for too long.  I intend to change that.<br /><br /><blockquote class="uncited"><div>Here are some parameters I would like us to consider: There is 2.8 +- miles of coast between the Tomcat PG launch and the south end of the Training Bowl. There is 0.94 +- miles of coast between the south end of the Training Bowl and the gap at the north end of Fort Funston.  The reality is that in light wind conditions, which are very common many days of the year, paraglider pilots are able to fly about three times as much coastline compared to hang glider pilots.</div></blockquote><br /><br />Bullshit!  If we assume the rule that you wish to assume, PG can fly most of the coast, and HG can fly all of it.  But the reality, as you very well know, is that we can all fly all of it.  You chose recently that I exercise that option rather than opt for a solution that has me respecting your wish for some HG-only airspace.<br /><br /><blockquote class="uncited"><div>If, on a light wind day, paraglider pilots were to use the entire 3.74 +- miles of available coastline, hang glider pilots would have ZERO coastline to fly.</div></blockquote><br /><br />You should probably see if you can come to some sort of arrangement that would entice PG pilots to grant you that airspace.<br /><br /><blockquote class="uncited"><div>Here is the question I respectfully request you ask yourself:<br />Given that paraglider pilots have 3 times as much coastline to fly as hang glider pilots, is it morally right for them to take the last quarter of coastline and deprive hang gliderpilots of their ability to fly at all?</div></blockquote><br /><br />I don't accept your premise.  And here is the question I respectfully request you ask yourself:<br />Is it right for a group of pilots to claim ownership of a portion of airspace they have no legal right to, and try and keep others out through intimidation and just plain dangerous and aggressive flying?  Do we have to have a fatality like they did at Point of the Mountain?<br /><br />You think it's dangerous for PG and HG to mix - but not on the low ridge between Funston and Westlake.  Not on the high ridge at Westlake.  Not at the Dunes in Pacifica.  The laws of physics simply change at the fence on the south side of the Funston LZ.<br /><br />Do you think it's right to enforce rules for some and not others?<br /><br />Do you think it's right to claim the problem with PG's and HG's mixing is one of safety while half of the HG pilots are stoned while they fly (violating federal law)?<br /><br />Do you think it's right that FF pilots don't even feel that a fair arrangement is appropriate - no matter what fair means?<br /><br />You guys more or less unanimously voted to suspend me for a year for exercising exactly the same rights you exercise every soarable day, and now want to appeal to my sense of morality!?  I'm embarrassed for you.  <br /><br />You make your decisions and you live with them - same as me.</div>

			

		</div>

		
			<dl class="postprofile" id="profile3527">
			<dt>
				<a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 93</dd><dd><strong>Joined:</strong> Wed Apr 20, 2011 11:40 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3542" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting0380.html?mode=quote&amp;f=5&amp;p=3542" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3542">Re: Last night's meeting</a></h3>
			<p class="author"><a href="viewtopicf719.php?p=3542#p3542"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944">bobk</a></strong> &raquo; Sun Apr 28, 2013 12:50 am </p>

			

			<div class="content">Steve and I have butted heads on many issues, so I'm not a member of his fan club. But Steve's point here is exactly right.<br /><br /><blockquote><div><cite>Steve Rodrigues wrote:</cite>If, on a light wind day, paraglider pilots were to use the entire 3.74 +- miles of available coastline, hang glider pilots would have ZERO coastline to fly. In essence, this means that paraglider pilots exercising their right to FAA airspace would be depriving hang glider pilots of that very same right.</div></blockquote><br /><br />When you have a situation where one group's rights would completely eclipse another group's rights, you should make a reasonable accommodation to keep that from happening. The small stretch of cliff currently restricted to hang gliding is reasonable to ensure that hang glider pilots are not grounded by high paraglider traffic.<br /><br />As a side note, there are many public beaches where surfing and swimming are separated for similar reasons. I'm sorry Rick, but it's not an unreasonable request.</div>

			<div id="sig3542" class="signature"><span style="font-size: 130%; line-height: 116%;"><span style="color: #000080"><span style="font-style: italic">Join a National Hang Gliding Organization:</span></span> <span style="font-weight: bold"><span style="color: #000080"><a href="http://ushawks.org/" class="postlink">US Hawks at ushawks.org</a></span></span></span></div>

		</div>

		
			<dl class="postprofile" id="profile3542">
			<dt>
				<a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944"><img src="download/file3928.html?avatar=1944_1390380842.jpeg" width="200" height="150" alt="User avatar" /></a><br />
				<a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944">bobk</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 138</dd><dd><strong>Joined:</strong> Tue Mar 22, 2011 1:53 pm</dd>
			<dd>
				<ul class="profile-icons">
					<li class="web-icon"><a href="http://ushawks.org/" title="WWW: http://ushawks.org"><span>Website</span></a></li>
				</ul>
			</dd>
		

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3550" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postingeb6b.html?mode=quote&amp;f=5&amp;p=3550" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3550">Re: Last night's meeting</a></h3>
			<p class="author"><a href="viewtopicc78b.html?p=3550#p3550"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a></strong> &raquo; Mon Apr 29, 2013 7:55 pm </p>

			

			<div class="content"><blockquote class="uncited"><div>there are many public beaches where surfing and swimming are separated for similar reasons.</div></blockquote><br /><br />We're not talking about &quot;separated&quot;.  We're talking about &quot;no PG's allowed&quot;.  HG's claim THE ENTIRE ridge.  And they claim PG's are free to fly A PORTION of the ridge.  That is the math.  But this is just plain thuggery.  No different than the localism in surfing.<br /><br /><blockquote class="uncited"><div>I'm sorry Rick, but it's not an unreasonable request.</div></blockquote><br /><br />It's not a request.  It's a threat - and one they back up with violence in the air.</div>

			

		</div>

		
			<dl class="postprofile" id="profile3550">
			<dt>
				<a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 93</dd><dd><strong>Joined:</strong> Wed Apr 20, 2011 11:40 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3553" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postingf13c.html?mode=quote&amp;f=5&amp;p=3553" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3553">Re: Last night's meeting</a></h3>
			<p class="author"><a href="viewtopica272.php?p=3553#p3553"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944">bobk</a></strong> &raquo; Thu May 02, 2013 8:03 pm </p>

			

			<div class="content"><blockquote><div><cite>spork wrote:</cite>It's not a request.  It's a threat - and one they back up with violence in the air.</div></blockquote><br /><br />It's a request ... from me ... to you.<br /><br />I can't speak to what others have or have not done. But I can say that I have loved flying at Funston, and I am personally asking you to back down from trying to force paragliding into that site. I suspect that my personal request means little to you, but I would be remiss for not at least asking.<br /><br />Best wishes and fly safely,<br />Bob Kuczewski</div>

			<div id="sig3553" class="signature"><span style="font-size: 130%; line-height: 116%;"><span style="color: #000080"><span style="font-style: italic">Join a National Hang Gliding Organization:</span></span> <span style="font-weight: bold"><span style="color: #000080"><a href="http://ushawks.org/" class="postlink">US Hawks at ushawks.org</a></span></span></span></div>

		</div>

		
			<dl class="postprofile" id="profile3553">
			<dt>
				<a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944"><img src="download/file3928.html?avatar=1944_1390380842.jpeg" width="200" height="150" alt="User avatar" /></a><br />
				<a href="memberlist1a1a.html?mode=viewprofile&amp;u=1944">bobk</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 138</dd><dd><strong>Joined:</strong> Tue Mar 22, 2011 1:53 pm</dd>
			<dd>
				<ul class="profile-icons">
					<li class="web-icon"><a href="http://ushawks.org/" title="WWW: http://ushawks.org"><span>Website</span></a></li>
				</ul>
			</dd>
		

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3554" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting64b1.html?mode=quote&amp;f=5&amp;p=3554" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3554">Re: Last night's meeting</a></h3>
			<p class="author"><a href="viewtopic87f2.html?p=3554#p3554"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a></strong> &raquo; Fri May 03, 2013 12:07 am </p>

			

			<div class="content"><blockquote><div><cite>bobk wrote:</cite>I am personally asking you to back down from trying to force paragliding into that site.</div></blockquote><br /><br />I have never suggested we open that site to paragliding.  But I could say that 1000 more times, and we'll still be right where we are.  Right now (and for many years), the airspace in front of that ridge is claimed by HG pilots and defended through in-air violence.  I have made several proposals - NONE have involved PG's flying that airspace.  The reason there's talk of PG's in that airspace is that all proposals have been flatly refused - no matter how reasonable.<br /><br />For fuck's sake, can you honestly not see that it's reasonable to agree to allow the PG's some ridge where they too can be unhindered by strafing HG's!?  But even that proposal is not considered.  I've said MANY times I will settle for any reasonable arrangement.  But simply living with the &quot;stay the fuck out - or else&quot; policy has come to an end.<br /><br /><blockquote class="uncited"><div>I suspect that my personal request means little to you, but I would be remiss for not at least asking.</div></blockquote><br /><br />It means as much to me as my requests mean to the HG pilots.<br /><br />But frankly Bob - you should be thanking me.  You're no longer the most hated man at the badlands you call Funston.</div>

			

		</div>

		
			<dl class="postprofile" id="profile3554">
			<dt>
				<a href="memberlist6d8a.html?mode=viewprofile&amp;u=1954">spork</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 93</dd><dd><strong>Joined:</strong> Wed Apr 20, 2011 11:40 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<form id="viewtopic" method="post" action="http://flyfunston.org/bbs/viewtopic.php?f=5&amp;t=1443">

	<fieldset class="display-options" style="margin-top: 0; ">
		<a href="viewtopicf35b.html?f=5&amp;t=1443&amp;start=25" class="right-box right">Next</a>
		<label>Display posts from previous: <select name="st" id="st"><option value="0" selected="selected">All posts</option><option value="1">1 day</option><option value="7">7 days</option><option value="14">2 weeks</option><option value="30">1 month</option><option value="90">3 months</option><option value="180">6 months</option><option value="365">1 year</option></select></label>
		<label>Sort by <select name="sk" id="sk"><option value="a">Author</option><option value="t" selected="selected">Post time</option><option value="s">Subject</option></select></label> <label><select name="sd" id="sd"><option value="a" selected="selected">Ascending</option><option value="d">Descending</option></select> <input type="submit" name="sort" value="Go" class="button2" /></label>
		
	</fieldset>

	</form>
	<hr />


<div class="topic-actions">
	<div class="buttons">
	
		<div class="reply-icon"><a href="posting28ea.html?mode=reply&amp;f=5&amp;t=1443" title="Post a reply"><span></span>Post a reply</a></div>
	
	</div>

	
		<div class="pagination">
			31 posts
			 &bull; <a href="#" onclick="jumpto(); return false;" title="Click to jump to page…">Page <strong>1</strong> of <strong>2</strong></a> &bull; <span><strong>1</strong><span class="page-sep">, </span><a href="viewtopicf35b.html?f=5&amp;t=1443&amp;start=25">2</a></span>
		</div>
	
</div>


	<p></p><p><a href="viewforume774.html?f=5" class="left-box left" accesskey="r">Return to General Discussion</a></p>

	<form method="post" id="jumpbox" action="http://flyfunston.org/bbs/viewforum.php" onsubmit="if(this.f.value == -1){return false;}">

	
		<fieldset class="jumpbox">
	
			<label for="f" accesskey="j">Jump to:</label>
			<select name="f" id="f" onchange="if(this.options[this.selectedIndex].value != -1){ document.forms['jumpbox'].submit() }">
			
				<option value="-1">Select a forum</option>
			<option value="-1">------------------</option>
				<option value="9">Discussion Groups</option>
			
				<option value="5" selected="selected">&nbsp; &nbsp;General Discussion</option>
			
				<option value="8">&nbsp; &nbsp;Announcements</option>
			
				<option value="7">&nbsp; &nbsp;For Sale/Wanted</option>
			
				<option value="6">&nbsp; &nbsp;Road Trips</option>
			
				<option value="2">&nbsp; &nbsp;Meeting Minutes and Treasurer Reports</option>
			
				<option value="11">&nbsp; &nbsp;Off Topic</option>
			
			</select>
			<input type="submit" value="Go" class="button2" />
		</fieldset>
	</form>


	<h3>Who is online</h3>
	<p>Users browsing this forum: No registered users and 7 guests</p>
</div>

<div id="page-footer">

	<div class="navbar">
		<div class="inner"><span class="corners-top"><span></span></span>

		<ul class="linklist">
			<li class="icon-home"><a href="index.html">Board index</a></li>
				
			<li class="rightside"><a href="memberlista2f5.html?mode=leaders">The team</a> &bull; <a href="ucp033a.html?mode=delete_cookies">Delete all board cookies</a> &bull; All times are UTC - 8 hours [ <abbr title="Daylight Saving Time">DST</abbr> ]</li>
		</ul>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<div class="copyright">Powered by <a href="https://www.phpbb.com/">phpBB</a>&reg; Forum Software &copy; phpBB Group
		
	</div>
</div>

</div>

<div>
	<a id="bottom" name="bottom" accesskey="z"></a>
	<img src="cronb999.gif?cron_type=tidy_search" width="1" height="1" alt="cron" />
</div>

</body>

<!-- Mirrored from flyfunston.org/bbs/viewtopic.php?p=3509 by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 08 Aug 2021 20:16:49 GMT -->
</html>