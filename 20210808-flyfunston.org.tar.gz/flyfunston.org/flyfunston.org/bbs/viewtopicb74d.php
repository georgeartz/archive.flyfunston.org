<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en-us" xml:lang="en-us">

<!-- Mirrored from flyfunston.org/bbs/viewtopic.php?f=5&t=726&view=print by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 08 Aug 2021 20:19:21 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>

<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<meta http-equiv="content-style-type" content="text/css" />
<meta http-equiv="content-language" content="en-us" />
<meta http-equiv="imagetoolbar" content="no" />
<meta name="resource-type" content="document" />
<meta name="distribution" content="global" />
<meta name="robots" content="noindex" />

<title>Flyfunston &bull; View topic - Sponsor subject to suspension rule</title>

<link href="styles/prosilver/theme/print.css" rel="stylesheet" type="text/css" />
</head>

<body id="phpbb">
<div id="wrap">
	<a id="top" name="top" accesskey="t"></a>

	<div id="page-header">
		<h1>Flyfunston</h1>
		<p>Hang Gliding at Fort Funston<br /><a href="index-2.html">http://flyfunston.org/bbs/</a></p>

		<h2>Sponsor subject to suspension rule</h2>
		<p><a href="viewtopicd9f2.php?f=5&amp;t=726">http://flyfunston.org/bbs/viewtopic.php?f=5&amp;t=726</a></p>
	</div>

	<div id="page-body">
		<div class="page-number">Page <strong>1</strong> of <strong>1</strong></div>
		
			<div class="post">
				<h3>Sponsor subject to suspension rule</h3>
				<div class="date"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" />Posted: <strong>Sat Feb 28, 2009 9:54 am</strong></div>
				<div class="author">by <strong>Steve Rodrigues</strong></div>
				<div class="content">DB wrote:
<br />The new H-2 Rules need refinement.
<br />1. The only grounds for suspending the sponsor for the H-2’s violation should be for sponsoring a flight by a pilot that the sponsor knew or should have known was unqualified.
<br />
<br />&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;&gt;
<br />In regard to the rule
<br />
<br />F) If an H-2 violates any Fellow Feathers rule during their sponsored flight, their sponsor shall be subject to the same suspension.
<br />
<br />The problem we are trying to solve: H-2 pilots not knowing all the rules and their sponsors not taking responsibility for the H-2 they are sponsoring.
<br />
<br />This rule insures that the sponsor will take extra care to be sure the H-2 knows and agrees to follow the rules.
<br />
<br />A suspension means little to an H-2 who doesn't' fly the Fort anyway so there is not much effective repercussion for an H-2 who breaks a rule. But how many H-2's would want to suffer the consequences if they got a respected Funston regular suspended along with them? They could essentially be shunned from the site, so this is one case where peer pressure would be very useful.
<br />
<br />My opinion is that if someone is not confident the H-2 both knows and will follow the rules they shouldn't sponsor them!
<br />
<br />Please note, the rule says the sponsor shall be &quot;subject to&quot; suspension, not &quot;shall be&quot; suspended. This allows discretion by the Board to consider extenuating circumstances.</div>
			</div>
			<hr />
		
			<div class="post">
				<h3></h3>
				<div class="date"><img src="styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" />Posted: <strong>Sun Mar 01, 2009 2:29 pm</strong></div>
				<div class="author">by <strong>Dan Brown</strong></div>
				<div class="content">Making the sponsor subject to the same suspension as the H-2 insures that the sponsor will not report a violation by the H-2 because it will mean his suspension. If the H-2 disregards the sponsor’s instructions and violates the rules, the sponsor should not be suspended. In ancient Babylon when the patient died, the doctor was killed. It reduced malpractice but greatly limited medical care.
<br />
<br />An H-2 will not be concerned about getting a “respected regular suspended.” But for one &quot;extraordinary&quot; pilot with “incredible aplomb, intelligence and tolerance”, the rest of us are “crusty” and “immature”.</div>
			</div>
			<hr />
		
	</div>

	<div id="page-footer">
		<div class="page-number">All times are UTC - 8 hours [ <abbr title="Daylight Saving Time">DST</abbr> ]<br />Page <strong>1</strong> of <strong>1</strong></div>
		<div class="copyright">Powered by phpBB&reg; Forum Software &copy; phpBB Group<br />https://www.phpbb.com/</div>
	</div>
</div>

</body>

<!-- Mirrored from flyfunston.org/bbs/viewtopic.php?f=5&t=726&view=print by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 08 Aug 2021 20:19:21 GMT -->
</html>