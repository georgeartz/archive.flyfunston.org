<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

<!-- Mirrored from flyfunston.org/tandem.php by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 08 Aug 2021 16:25:10 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
<title>Fellow Feathers Fort Funston
</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link rel="stylesheet" type="text/css" href="style.css" />
</head>
<body>
	<br />
<div class="maindiv">
<div class="navbar">
	<h1>Tandem Flights at Fort Funston</h1>
	<div align="center"> 
<p>
        <br />
   <a href="newwebcam/index.html">Webcam and Wind</a>
        <br />
        <br />
<a href="index.html">Home</a> | <a href="bbs">BBS Discussions</a> | <a href="site.html">Site Guide</a> | <a href="rulesbylaws.html">Rules, Bylaws, and Forms</a><br />
   <a href="primer.html">Funston Primer</a> |  <a href="sticker.html">Helmet Stickers</a> | <a href="tandem.php">Tandem Flights</a> | <a href="bbs/viewforumd42b.html?f=7">For Sale/Wanted</a>
	<br />
   <a href="calendar.php">Club Calendar</a> | <a href="bbs/viewforum12a3.html?f=2">Meeting Minutes and Reports</a> | <a href="officers.php">Contact Us/Club Officers </a>| <a href="histarchtoc.php">Photo History Archive</a> | <a href="gallery.html">Photo Gallery</a>
	<br />
   <a href="mentors.html">Fellow Feathers Mentors</a> | <a href="chasingfunston.html">Chasing Funston Video</a>
	<br />
</p>
</div>
</div>
<div class="contenttandem">
	<p align="center">
  	<object width="425" height="350">
	<param name="movie" value="http://www.youtube.com/v/Up6Z6rC8lyI" />
	<param name="wmode" value="transparent" />
	<embed src="http://www.youtube.com/v/Up6Z6rC8lyI" type="application/x-shockwave-flash" width="425" height="370" />
	</object>
	</p>
	<br />
	<p>We are pleased to announce that as of March, 2006, tandem flying at Fort Funston is allowed for pilots with the proper qualifications and equipment.	</p>
	<p>The summary is this: Our GGNRA Special Use Permit has been modified to allow tandem flights by USHPA Tandem pilots (T-1 and Tandem Instructor) with Fort Funston flying experience and safe equipment in good condition. We've created a Fort Funston Tandem Director position to ensure that everyone and their gear meet the  specified requirements. <em>All tandem pilots must be checked out by the Funston Tandem Director at the beginning of each year before being allowed to fly tandem.</em>
</p>
	<p>If you want to get approved to fly tandem at the Fort, have a look at the below rules and get in touch with the Fellow Feathers Tandem Director <a href="officers.php">(click here.)</a></p>
	<p>Please note: The Fellow Feathers  Special Use Permit from the GGNRA specifically states &ldquo;<strong>Commercial tandem flights or instruction are  strictly prohibited.</strong>&rdquo;. Under our permit,<em> </em>remuneration or compensation of any kind may NOT be requested, offered, or accepted.	Violation of our SUP may result in loss of tandem and other flying privileges.</p>
	<p>The complete <a href="documents/TandemRegs.pdf">Fort Funston Tandem rules.</a>
    </p>
	<br />
	<p align="center">
	<img alt="" src="images/tandemlaunch.jpg" />
	</p>
</div>
</div>
</body>

<!-- Mirrored from flyfunston.org/tandem.php by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 08 Aug 2021 16:25:21 GMT -->
</html>
