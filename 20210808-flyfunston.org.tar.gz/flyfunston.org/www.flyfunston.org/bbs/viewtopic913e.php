<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en-us" xml:lang="en-us">

<!-- Mirrored from www.flyfunston.org/bbs/viewtopic.php?p=1926 by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 08 Aug 2021 20:16:46 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>

<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<meta http-equiv="content-style-type" content="text/css" />
<meta http-equiv="content-language" content="en-us" />
<meta http-equiv="imagetoolbar" content="no" />
<meta name="resource-type" content="document" />
<meta name="distribution" content="global" />
<meta name="keywords" content="" />
<meta name="description" content="" />

<title>Flyfunston &bull; View topic - 30 MPH Rule in place</title>



<!--
	phpBB style name: prosilver
	Based on style:   prosilver (this is the default phpBB3 style)
	Original author:  Tom Beddard ( http://www.subBlue.com/ )
	Modified by:
-->

<script type="text/javascript">
// <![CDATA[
	var jump_page = 'Enter the page number you wish to go to:';
	var on_page = '1';
	var per_page = '';
	var base_url = '';
	var style_cookie = 'phpBBstyle';
	var style_cookie_settings = '; path=/; domain=flyfunston.org; secure';
	var onload_functions = new Array();
	var onunload_functions = new Array();

	

	/**
	* Find a member
	*/
	function find_username(url)
	{
		popup(url, 760, 570, '_usersearch');
		return false;
	}

	/**
	* New function for handling multiple calls to window.onload and window.unload by pentapenguin
	*/
	window.onload = function()
	{
		for (var i = 0; i < onload_functions.length; i++)
		{
			eval(onload_functions[i]);
		}
	};

	window.onunload = function()
	{
		for (var i = 0; i < onunload_functions.length; i++)
		{
			eval(onunload_functions[i]);
		}
	};

// ]]>
</script>
<script type="text/javascript" src="../../flyfunston.org/bbs/styles/prosilver/template/styleswitcher.js"></script>
<script type="text/javascript" src="../../flyfunston.org/bbs/styles/prosilver/template/forum_fn.js"></script>

<link href="../../flyfunston.org/bbs/styles/prosilver/theme/print.css" rel="stylesheet" type="text/css" media="print" title="printonly" />
<link href="../../flyfunston.org/bbs/style7a95.css?id=1&amp;lang=en_us" rel="stylesheet" type="text/css" media="screen, projection" />

<link href="../../flyfunston.org/bbs/styles/prosilver/theme/normal.css" rel="stylesheet" type="text/css" title="A" />
<link href="../../flyfunston.org/bbs/styles/prosilver/theme/medium.css" rel="alternate stylesheet" type="text/css" title="A+" />
<link href="../../flyfunston.org/bbs/styles/prosilver/theme/large.css" rel="alternate stylesheet" type="text/css" title="A++" />



</head>

<body id="phpbb" class="section-viewtopic ltr">

<div id="wrap">
	<a id="top" name="top" accesskey="t"></a>
	<div id="page-header">
		<div class="headerbar">
			<div class="inner"><span class="corners-top"><span></span></span>

			<div id="site-description">
				<a href="../../flyfunston.org/bbs/index.html" title="Board index" id="logo"><img src="../../flyfunston.org/bbs/styles/prosilver/imageset/site_logo.gif" width="149" height="52" alt="" title="" /></a>
				<h1>Flyfunston</h1>
				<p>Hang Gliding at Fort Funston</p>
				<p class="skiplink"><a href="#start_here">Skip to content</a></p>
			</div>

		
			<div id="search-box">
				<form action="http://www.flyfunston.org/bbs/search.php" method="get" id="search">
				<fieldset>
					<input name="keywords" id="keywords" type="text" maxlength="128" title="Search for keywords" class="inputbox search" value="Search…" onclick="if(this.value=='Search…')this.value='';" onblur="if(this.value=='')this.value='Search…';" />
					<input class="button2" value="Search" type="submit" /><br />
					<a href="../../flyfunston.org/bbs/search.html" title="View the advanced search options">Advanced search</a> 
				</fieldset>
				</form>
			</div>
		

			<span class="corners-bottom"><span></span></span></div>
		</div>

		<div class="navbar">
			<div class="inner"><span class="corners-top"><span></span></span>

			<ul class="linklist navlinks">
				<li class="icon-home"><a href="../../flyfunston.org/bbs/index.html" accesskey="h">Board index</a>  <strong>&#8249;</strong> <a href="../../flyfunston.org/bbs/viewforumfdc5.html?f=9">Discussion Groups</a> <strong>&#8249;</strong> <a href="../../flyfunston.org/bbs/viewforume774.html?f=5">General Discussion</a></li>

				<li class="rightside"><a href="#" onclick="fontsizeup(); return false;" onkeypress="return fontsizeup(event);" class="fontsize" title="Change font size">Change font size</a></li>

				<li class="rightside"><a href="viewtopicc454.html?f=5&amp;t=900&amp;view=print" title="Print view" accesskey="p" class="print">Print view</a></li>
			</ul>

			

			<ul class="linklist rightside">
				<li class="icon-faq"><a href="../../flyfunston.org/bbs/faq.html" title="Frequently Asked Questions">FAQ</a></li>
				
					<li class="icon-logout"><a href="../../flyfunston.org/bbs/ucp26c3.php?mode=login" title="Login" accesskey="x">Login</a></li>
				
			</ul>

			<span class="corners-bottom"><span></span></span></div>
		</div>

	</div>

	<a name="start_here"></a>
	<div id="page-body">
		
<h2><a href="../../flyfunston.org/bbs/viewtopicc8cd.php?f=5&amp;t=900">30 MPH Rule in place</a></h2>
<!-- NOTE: remove the style="display: none" when you want to have the forum description on the topic body --><div style="display: none !important;">Talk about Hang Gliding at Ft Funston and the Fellow Feathers Club.<br /></div>

<div class="topic-actions">

	<div class="buttons">
	
		<div class="reply-icon"><a href="posting0e16.html?mode=reply&amp;f=5&amp;t=900" title="Post a reply"><span></span>Post a reply</a></div>
	
	</div>

	
		<div class="search-box">
			<form method="get" id="topic-search" action="http://www.flyfunston.org/bbs/search.php">
			<fieldset>
				<input class="inputbox search tiny"  type="text" name="keywords" id="search_keywords" size="20" value="Search this topic…" onclick="if(this.value=='Search this topic…')this.value='';" onblur="if(this.value=='')this.value='Search this topic…';" />
				<input class="button2" type="submit" value="Search" />
				<input type="hidden" name="t" value="900" />
<input type="hidden" name="sf" value="msgonly" />

			</fieldset>
			</form>
		</div>
	
		<div class="pagination">
			18 posts
			 &bull; Page <strong>1</strong> of <strong>1</strong>
		</div>
	

</div>
<div class="clear"></div>


	<div id="p1913" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postinge0df.html?mode=quote&amp;f=5&amp;p=1913" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 class="first"><a href="#p1913">30 MPH Rule in place</a></h3>
			<p class="author"><a href="viewtopic8cdc.html?p=1913#p1913"><img src="../../flyfunston.org/bbs/styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="../../flyfunston.org/bbs/memberliste69f.html?mode=viewprofile&amp;u=15" style="color: #AA0000;" class="username-coloured">Steve Rodrigues</a></strong> &raquo; Sat Dec 12, 2009 3:34 pm </p>

			

			<div class="content">Everyone at the December meeting agreed that launching should have priority in the launch window, and that other pilots should fly safely and at a moderate speed when passing through the area.
<br />
<br />FF rule #4 was amended to read: (added wording <span style="text-decoration: underline">underlined</span>)
<br />
<br />“4. Pilots must fly straight and level in the launch window, <span style="text-decoration: underline">speed not to exceed 30 MPH.</span> The launch window is from the sand trail just south of launch, to the north end of the observation deck, 100' up, 100' out, <span style="text-decoration: underline">and 25’ below launch.”</span>
<br />
<br />For future reference, please see FF rules <span style="text-decoration: underline">Rev. 12-8-2009</span></div>

			
				<div class="notice">Last edited by <a href="../../flyfunston.org/bbs/memberliste69f.html?mode=viewprofile&amp;u=15" style="color: #AA0000;" class="username-coloured">Steve Rodrigues</a> on Wed Jan 20, 2010 6:54 am, edited 1 time in total.
					
				</div>
			

		</div>

		
			<dl class="postprofile" id="profile1913">
			<dt>
				<a href="../../flyfunston.org/bbs/memberliste69f.html?mode=viewprofile&amp;u=15"><img src="../../flyfunston.org/bbs/download/file9b05.php?avatar=15_1575056796.jpg" width="200" height="149" alt="User avatar" /></a><br />
				<a href="../../flyfunston.org/bbs/memberliste69f.html?mode=viewprofile&amp;u=15" style="color: #AA0000;" class="username-coloured">Steve Rodrigues</a>
			</dt>

			<dd>Site Admin</dd>

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 723</dd><dd><strong>Joined:</strong> Mon May 24, 2004 10:57 pm</dd><dd><strong>Location:</strong> Brisbane, California</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p1915" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postingd46b.html?mode=quote&amp;f=5&amp;p=1915" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p1915"></a></h3>
			<p class="author"><a href="viewtopic7ac1.html?p=1915#p1915"><img src="../../flyfunston.org/bbs/styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="../../flyfunston.org/bbs/memberlistd3cc.html?mode=viewprofile&amp;u=1478">fakeDecoy</a></strong> &raquo; Sat Dec 12, 2009 5:01 pm </p>

			

			<div class="content">It sounds like this rule is intended purely for the safety of gliders on launch? I'm confused by a few things. From the description, I interpret the specified area as being a block of air in front of launch that gliders launch into, not including the air directly above most of the wood chips. 
<br />
<br />So if I were to buzz <span style="font-weight: bold">through </span>launch, ie: from the back of launch and heading West over the wood chips, at 40mph, as long as I stay 25' from ground people and no gliders are on launch, would it not be considered a violation? Would the trick be to slow to 30mph by the time I make it out to the lip of launch into that block of air?
<br />
<br />Is it 30mph air speed? On a strong very northy day, someone flying 30mph with 20mph worth of tailwind would blow by at 50mph ground speed. 
<br />
<br />As far as the straight and level part, does this mean turning in that area is not allowed? Often it's the best place to turn, and in light lift the turn location is critical to staying up.
<br />
<br />DD</div>

			

		</div>

		
			<dl class="postprofile" id="profile1915">
			<dt>
				<a href="../../flyfunston.org/bbs/memberlistd3cc.html?mode=viewprofile&amp;u=1478">fakeDecoy</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 140</dd><dd><strong>Joined:</strong> Thu Jul 24, 2008 8:22 am</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p1916" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postingba36.html?mode=quote&amp;f=5&amp;p=1916" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p1916"></a></h3>
			<p class="author"><a href="viewtopicf11e.html?p=1916#p1916"><img src="../../flyfunston.org/bbs/styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="../../flyfunston.org/bbs/memberlist2501.html?mode=viewprofile&amp;u=41">diev</a></strong> &raquo; Mon Dec 14, 2009 10:16 am </p>

			

			<div class="content">I think the wording....&quot;<span style="font-weight: bold">while gliders are launching or in position to launch</span>&quot;....needs to be added to that first sentence.
<br />
<br />This should clear up a few things.....as it does seem wrong to have to stay out of that area (or go slow) all the time.
<br />
<br />Diev</div>

			<div id="sig1916" class="signature">Diev Hart<br />KG6UST<br /><!-- m --><a class="postlink" href="http://www.dievhart.com/hangglide.html">http://www.dievhart.com/hangglide.html</a><!-- m --></div>

		</div>

		
			<dl class="postprofile" id="profile1916">
			<dt>
				<a href="../../flyfunston.org/bbs/memberlist2501.html?mode=viewprofile&amp;u=41">diev</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 253</dd><dd><strong>Joined:</strong> Tue Sep 28, 2004 1:40 pm</dd><dd><strong>Location:</strong> Santa Cruz, CA</dd>
			<dd>
				<ul class="profile-icons">
					<li class="web-icon"><a href="http://www.dievhart.com/hangglide.html" title="WWW: http://www.dievhart.com/hangglide.html"><span>Website</span></a></li><li class="yahoo-icon"><a href="http://edit.yahoo.com/config/send_webmesg?.target=dievhart&amp;.src=pg" onclick="popup(this.href, 780, 550); return false;" title="YIM"><span>YIM</span></a></li>
				</ul>
			</dd>
		

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p1917" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting8ec0.html?mode=quote&amp;f=5&amp;p=1917" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p1917"></a></h3>
			<p class="author"><a href="viewtopicaaf7.html?p=1917#p1917"><img src="../../flyfunston.org/bbs/styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="../../flyfunston.org/bbs/memberlistd3cc.html?mode=viewprofile&amp;u=1478">fakeDecoy</a></strong> &raquo; Mon Dec 14, 2009 2:36 pm </p>

			

			<div class="content">Adding that sounds good to me. The implication would be that if you can tell for sure that there's nobody on launch then it's fair game. I guess back in the golden days where the rule originated, it was assumed that there would pretty much always be gliders lined up in the launch queue.
<br />
<br />DD</div>

			

		</div>

		
			<dl class="postprofile" id="profile1917">
			<dt>
				<a href="../../flyfunston.org/bbs/memberlistd3cc.html?mode=viewprofile&amp;u=1478">fakeDecoy</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 140</dd><dd><strong>Joined:</strong> Thu Jul 24, 2008 8:22 am</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p1921" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting821d.php?mode=quote&amp;f=5&amp;p=1921" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p1921"></a></h3>
			<p class="author"><a href="viewtopic4dfd.php?p=1921#p1921"><img src="../../flyfunston.org/bbs/styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="../../flyfunston.org/bbs/memberliste69f.html?mode=viewprofile&amp;u=15" style="color: #AA0000;" class="username-coloured">Steve Rodrigues</a></strong> &raquo; Tue Dec 15, 2009 7:56 pm </p>

			

			<div class="content">There were quite a few others at the meeting who participated in the rules discussion, but I'll try and clarify the intent.
<br />
<br />It would help to think of the launch window as a blind intersection without stop signs. It would be crazy to drive your car through a blind intersection without slowing down, and flying requires at least as much caution. I don't believe any officer would be concerned if you were going fast up to the limits of the launch window, then slowed down, then sped up after leaving the window.
<br />
<br />I don't think it would work to make it &quot;only if there are gliders on launch&quot; because the point is that with the bush in the way, one can't always be positive there is not, a glider approaching from behind launch, or if someone will come through on a touch-n-go.
<br />
<br />30 MPH has to be the gliders airspeed and not ground speed.
<br />
<br />The &quot;straight and level&quot; language has been in the rules for many years now. It was not intended to keep people from turning over the launch area, just not doing anything aerobatic.</div>

			

		</div>

		
			<dl class="postprofile" id="profile1921">
			<dt>
				<a href="../../flyfunston.org/bbs/memberliste69f.html?mode=viewprofile&amp;u=15"><img src="../../flyfunston.org/bbs/download/file9b05.php?avatar=15_1575056796.jpg" width="200" height="149" alt="User avatar" /></a><br />
				<a href="../../flyfunston.org/bbs/memberliste69f.html?mode=viewprofile&amp;u=15" style="color: #AA0000;" class="username-coloured">Steve Rodrigues</a>
			</dt>

			<dd>Site Admin</dd>

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 723</dd><dd><strong>Joined:</strong> Mon May 24, 2004 10:57 pm</dd><dd><strong>Location:</strong> Brisbane, California</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p1923" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting2b87.html?mode=quote&amp;f=5&amp;p=1923" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p1923"></a></h3>
			<p class="author"><a href="viewtopicbfe5.html?p=1923#p1923"><img src="../../flyfunston.org/bbs/styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="../../flyfunston.org/bbs/memberlistd3cc.html?mode=viewprofile&amp;u=1478">fakeDecoy</a></strong> &raquo; Fri Dec 18, 2009 11:20 pm </p>

			

			<div class="content">Think about the 30mph airspeed rule in the context of crossing winds. Look at these examples.
<br />
<br />1. 35mph airspeed in 25mph headwind = 10mph ground speed
<br />2. 25mph airspeed in 25mph tailwind = 50mph ground speed
<br />
<br />According to the new rule, flying 10mph ground speed can be a violation, and flying 50mph ground speed can be not a violation. That's illogical if the idea is to stop gliders from speeding in front of launch relative to the ground.
<br />
<br />But we can't change the rule to ground speed either. Here's what would happen: 
<br />
<br />3. 15mph airspeed in 25mph tailwind = 40mph ground speed
<br />4. 50mph airspeed in 25mph headwind = 25mph ground speed
<br />
<br />40mph ground speed can be a violation even though you're flying stalled, and yet at 50mph airspeed it can be not a violation.
<br />
<br />
<br />Do you see? Neither one works. This is why sites don't have speed limits - people have already figured out that the combination of airspeed and ground speed we deal with makes speed limits illogical. This new rule is going to be constantly violated and pilots are going to be constantly accused of violating it when they didn't, because it isn't always obvious how much headwind or tailwind a pilot is dealing with. I realize that 25mph worth of headwind or tailwind is an extreme, but it's quite possible, and even if you tone down the wind speed a bit the examples still hold. 
<br />
<br />The uncontrolled intersection analogy for cars doesn't apply well to us. We can't slam on our brakes. We have to keep moving, and unlike cars, the faster we go, the better control we have (up to a point, but far beyond 30mph on high performance gliders with rope pulled). 
<br />
<br />Now I can understand the issue trying to be addressed - pilots in the air aren't giving enough respect to pilots on launch, and pilots on launch don't always know if they're clear to launch. This sounds to me like a simple right-of-way issue. Pilots on launch should have the right of way. That would imply that the flying pilot has certain considerations towards the launching pilot, such as not approaching quickly if the wind vector allows it, watching more closely for the possibility of pilots walking gliders to launch, and having enough airspeed for evasive maneuvers to avoid a suddenly launching pilot with plenty of room so as not to cause any concern. These types of right-of-way considerations are already present, so it isn't a big deal to add it, it would fill the intended purpose, and I can hardly imagine anyone would object. Let's just make it explicit. All other right of way rules that we use for air traffic do not require any set numbers as far as speed or distance, and it works out great, because every situation is different, and ultimately we all have to demonstrate good judgment and depend on the good judgment of other pilots. 
<br />
<br />Dave</div>

			

		</div>

		
			<dl class="postprofile" id="profile1923">
			<dt>
				<a href="../../flyfunston.org/bbs/memberlistd3cc.html?mode=viewprofile&amp;u=1478">fakeDecoy</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 140</dd><dd><strong>Joined:</strong> Thu Jul 24, 2008 8:22 am</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p1926" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postingb323.html?mode=quote&amp;f=5&amp;p=1926" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p1926"></a></h3>
			<p class="author"><a href="viewtopic913e.php?p=1926#p1926"><img src="../../flyfunston.org/bbs/styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="../../flyfunston.org/bbs/memberliste69f.html?mode=viewprofile&amp;u=15" style="color: #AA0000;" class="username-coloured">Steve Rodrigues</a></strong> &raquo; Sun Dec 20, 2009 12:17 pm </p>

			

			<div class="content">Hi Dave,
<br />
<br />I appreciate the points you have raised, let’s kick some more ideas around.
<br />
<br />We can probably agree on a few things:
<br />
<br />1: More and more pilots are practicing touch-and-go’s, and, many pilots start their launch run a fair distance back from launch.
<br />
<br />2: The bush blocks the line of sight between a glider flying at cliff level in front of, or just north of the observation deck and anyone else who is behind launch, from ground level and up to about 20' AGL. This creates a blind spot between gliders flying perpendicular to each other. (ridge running and launching)
<br />
<br /> 3: A mid-air collision between a ridge racer and a pilot launching or doing a touch-n-go could easily be fatal.
<br />
<br />I agree with you that we all need to keep an eye on other traffic, clear our approaches, and maintain situational awareness. But the fact is that anyone can make a mistake or just not see another glider. It’s happened to me, ever happen to you? And no matter how diligent we are, none of us can see through the bush.
<br /> 
<br />As a result, many people, including myself, are concerned that sooner or later there will be a serious incident that could cost us a dear friend (or two) and put the site in jeopardy. The question is what measures would best protect our friends and the site?
<br />
<br />The first idea was simply to have pilots slow down when flying through the launch window. Getting pilots to fly around trim or best glide would help, but I agree that due to the tail wind component, it’s not a perfect solution.
<br />
<br />So yes, gliders are being hidden by the bush, but really, the only real danger is from a glider entering the launch window from the north, and more specifically, a glider heading south and flying between the cliff top and the top of the bush.
<br />
<br />If the ridge running glider was above the bush they would be visible to others, and if they were well below cliff level they could not physically interfere with other gliders flying off launch.
<br />
<br />So how about a rule stating that gliders flying south through the launch window must be either above the top of the bush or at least 25’ below the cliff?</div>

			

		</div>

		
			<dl class="postprofile" id="profile1926">
			<dt>
				<a href="../../flyfunston.org/bbs/memberliste69f.html?mode=viewprofile&amp;u=15"><img src="../../flyfunston.org/bbs/download/file9b05.php?avatar=15_1575056796.jpg" width="200" height="149" alt="User avatar" /></a><br />
				<a href="../../flyfunston.org/bbs/memberliste69f.html?mode=viewprofile&amp;u=15" style="color: #AA0000;" class="username-coloured">Steve Rodrigues</a>
			</dt>

			<dd>Site Admin</dd>

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 723</dd><dd><strong>Joined:</strong> Mon May 24, 2004 10:57 pm</dd><dd><strong>Location:</strong> Brisbane, California</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p1927" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postingb48e.html?mode=quote&amp;f=5&amp;p=1927" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p1927"></a></h3>
			<p class="author"><a href="viewtopic8e9f.html?p=1927#p1927"><img src="../../flyfunston.org/bbs/styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="../../flyfunston.org/bbs/memberlistd3cc.html?mode=viewprofile&amp;u=1478">fakeDecoy</a></strong> &raquo; Sun Dec 20, 2009 2:24 pm </p>

			

			<div class="content">Ok, I think we're getting somewhere. I agree that flying south close to the ridge, at ridge level, past launch is the only flight path segment that should be cause for concern as far as ridge racing near launch. 
<br />
<br />I haven't personally had a near-collision because of the bush blind spot when I'm the one ridge racing, and I attribute that to being hyper-aware of the possibility of a glider launching or doing a touch-and-go so that I don't put myself in a vulnerable position. When I plan a touch-and-go, I watch traffic first, and I won't do it if another pilot is ridge racing and might meet me at launch, and I'm even hesitant about doing it when I expect gliders to pass above launch, just because I don't know what their plan is. When I was a new H3 I was told to watch for ridge racers coming south before I do a touch-and-go, so I assumed it was solely my responsibility as the touch-and-go pilot to check, but maybe it isn't?
<br />
<br />I think the rule that you propose makes a lot more sense than the 30mph rule. It's a very smart move for the flying pilot to stay above the bush level until he can see that it's clear, before buzzing past launch. There is a point at which a pilot has a complete view, say at a certain height above the north end of the bush, at which point he can dive down and buzz launch having confirmed that it's clear. I agree that when passing the entire area at ridge level without having had the altitude to check he doesn't have a chance to check for other gliders, and it isn't the safest thing. I'm not sure what the specifics should be on that, or how precisely they need to be defined. But I would like to see a distinction allowed between a pilot safely checking for traffic versus a pilot ridge racing blindly through. Or if there's a lot of traffic, maybe it isn't a good idea at all. So maybe the rule also could be modified somehow with that in mind. I just have a hard time with it being too restrictive, because the situation can change dramatically depending on the conditions or amount of traffic. Or maybe the rule doesn't need to include the loophole of checking for traffic, but a certain amount of tolerance could be exercised when enforcing it at the officer's discretion (unlike the 25' rule, which is zero tolerance and makes sense in virtually all conditions).
<br />
<br />Dave</div>

			

		</div>

		
			<dl class="postprofile" id="profile1927">
			<dt>
				<a href="../../flyfunston.org/bbs/memberlistd3cc.html?mode=viewprofile&amp;u=1478">fakeDecoy</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 140</dd><dd><strong>Joined:</strong> Thu Jul 24, 2008 8:22 am</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p1929" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postingcee5.html?mode=quote&amp;f=5&amp;p=1929" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p1929"></a></h3>
			<p class="author"><a href="viewtopicffcc.php?p=1929#p1929"><img src="../../flyfunston.org/bbs/styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="../../flyfunston.org/bbs/memberlist9acc.html?mode=viewprofile&amp;u=126">Dan Brown</a></strong> &raquo; Wed Dec 23, 2009 1:42 pm </p>

			

			<div class="content">This is a simplied modification w/o the difficult to enforce speed limitation
<br />that I beleive will prevent mid-air collisons w/ launching gliders.
<br />
<br />&quot;A glider may not enter the launch window from the north when there is a glider preparing to launch. Visual clearance is required.&quot;
<br />
<br />Dan Brown</div>

			

		</div>

		
			<dl class="postprofile" id="profile1929">
			<dt>
				<a href="../../flyfunston.org/bbs/memberlist9acc.html?mode=viewprofile&amp;u=126">Dan Brown</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 88</dd><dd><strong>Joined:</strong> Fri Apr 01, 2005 2:01 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p1930" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting19dc.html?mode=quote&amp;f=5&amp;p=1930" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p1930"></a></h3>
			<p class="author"><a href="viewtopic3d3f.html?p=1930#p1930"><img src="../../flyfunston.org/bbs/styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="../../flyfunston.org/bbs/memberlistd3cc.html?mode=viewprofile&amp;u=1478">fakeDecoy</a></strong> &raquo; Wed Dec 23, 2009 4:05 pm </p>

			

			<div class="content">I'd vote for that one!
<br />
<br />Dave</div>

			

		</div>

		
			<dl class="postprofile" id="profile1930">
			<dt>
				<a href="../../flyfunston.org/bbs/memberlistd3cc.html?mode=viewprofile&amp;u=1478">fakeDecoy</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 140</dd><dd><strong>Joined:</strong> Thu Jul 24, 2008 8:22 am</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p1933" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting0c06.php?mode=quote&amp;f=5&amp;p=1933" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p1933"></a></h3>
			<p class="author"><a href="viewtopic1350.html?p=1933#p1933"><img src="../../flyfunston.org/bbs/styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="../../flyfunston.org/bbs/memberliste69f.html?mode=viewprofile&amp;u=15" style="color: #AA0000;" class="username-coloured">Steve Rodrigues</a></strong> &raquo; Mon Jan 04, 2010 7:52 pm </p>

			

			<div class="content">The first half of the paragraph is all we need: &quot;A glider may not enter the launch window from the north&quot; It is right to the point, with no loopholes.
<br />
<br />I'd argue that the last half of this language does not work because one can't reliably tell when there is a glider on launch. (which is the precise point of the rule)
<br />
<br />Let's discuss this in person at the next meeting!
<br />
<br />
<br /><blockquote><div><cite>Dan Brown wrote:</cite>This is a simplied modification w/o the difficult to enforce speed limitation<br />that I beleive will prevent mid-air collisons w/ launching gliders.<br /><br />&quot;A glider may not enter the launch window from the north when there is a glider preparing to launch. Visual clearance is required.&quot;<br /><br />Dan Brown</div></blockquote></div>

			

		</div>

		
			<dl class="postprofile" id="profile1933">
			<dt>
				<a href="../../flyfunston.org/bbs/memberliste69f.html?mode=viewprofile&amp;u=15"><img src="../../flyfunston.org/bbs/download/file9b05.php?avatar=15_1575056796.jpg" width="200" height="149" alt="User avatar" /></a><br />
				<a href="../../flyfunston.org/bbs/memberliste69f.html?mode=viewprofile&amp;u=15" style="color: #AA0000;" class="username-coloured">Steve Rodrigues</a>
			</dt>

			<dd>Site Admin</dd>

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 723</dd><dd><strong>Joined:</strong> Mon May 24, 2004 10:57 pm</dd><dd><strong>Location:</strong> Brisbane, California</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p1937" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting4def.html?mode=quote&amp;f=5&amp;p=1937" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p1937">Modification</a></h3>
			<p class="author"><a href="viewtopice600.html?p=1937#p1937"><img src="../../flyfunston.org/bbs/styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="../../flyfunston.org/bbs/memberlist9acc.html?mode=viewprofile&amp;u=126">Dan Brown</a></strong> &raquo; Thu Jan 07, 2010 11:12 am </p>

			

			<div class="content">A rule prohibiting without exceptions gliders from entering the launch window from the North would close Funston in light air.
<br />
<br />When a pilot is uncertain if a glider is about to launch, he should not enter the launch window.
<br />
<br />
<br />Dan Brown</div>

			

		</div>

		
			<dl class="postprofile" id="profile1937">
			<dt>
				<a href="../../flyfunston.org/bbs/memberlist9acc.html?mode=viewprofile&amp;u=126">Dan Brown</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 88</dd><dd><strong>Joined:</strong> Fri Apr 01, 2005 2:01 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p1947" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting9f4b.html?mode=quote&amp;f=5&amp;p=1947" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p1947"></a></h3>
			<p class="author"><a href="viewtopicd18b.php?p=1947#p1947"><img src="../../flyfunston.org/bbs/styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="../../flyfunston.org/bbs/memberlistd3cc.html?mode=viewprofile&amp;u=1478">fakeDecoy</a></strong> &raquo; Sun Jan 10, 2010 10:18 pm </p>

			

			<div class="content">From discussions with others today, I believe there's clearly support for at the very least modifying the rule because of the tailwind component making the 30mph wording illogical. It sounds like the last meeting ran very long last month in discussing this, and I wonder if some members' weariness at the hours of debate influenced the revision vote. So let's be prepared with specific suggested revisions to minimize the debate. 
<br />
<br />Here's a suggested revision I came up with this evening:
<br />
<br /><span style="font-weight: bold">&quot;Gliders on launch or doing touch-n-gos have the right of way. If conditions allow, pilots flying south along the ridge must not fly into the launch window in front of (re-)launching gliders.&quot;</span>
<br />
<br />This accomplishes many things:
<br />
<br />- Helps prevent possible mid-airs and waking gliders on launch by identifying a specific reduced-visibility circumstance due to the bush.
<br />
<br />- There's no restriction of ridge racing if pilots can do so safely.
<br />
<br />- It eliminates the question of how well a pilot is able to visually clear the launch window when flying south along the ridge and gives a clear guideline by which officers can issue suspensions if necessary. 
<br />
<br />- It clarifies who has the right of way and warns pilots to be wary of the launch area.
<br />
<br />- The &quot;if conditions allow&quot; wording allows for voiding the rule in light conditions, during which I think everyone is naturally extra-cautious anyway.
<br />
<br />Diver Dave</div>

			

		</div>

		
			<dl class="postprofile" id="profile1947">
			<dt>
				<a href="../../flyfunston.org/bbs/memberlistd3cc.html?mode=viewprofile&amp;u=1478">fakeDecoy</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 140</dd><dd><strong>Joined:</strong> Thu Jul 24, 2008 8:22 am</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p1948" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting8775.html?mode=quote&amp;f=5&amp;p=1948" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p1948"></a></h3>
			<p class="author"><a href="viewtopic0c06.php?p=1948#p1948"><img src="../../flyfunston.org/bbs/styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="../../flyfunston.org/bbs/memberlist433e.html?mode=viewprofile&amp;u=1468">AllenJ</a></strong> &raquo; Mon Jan 11, 2010 9:54 am </p>

			

			<div class="content"><span style="font-weight: bold">Current Language of the rule:</span>
<br />
<br />4. Pilots must fly straight and level in the launch window, speed not to exceed 30 MPH. The launch window is from the sand trail just south of launch, to the north end of the observation deck, 100' up, 100' out, and 25’ below launch.
<br />
<br /><span style="font-weight: bold">Dave's recommendation:</span>
<br />&quot;Gliders on launch or doing touch-n-gos have the right of way. If conditions allow, pilots flying south along the ridge must not fly into the launch window in front of (re-)launching gliders.&quot;
<br />
<br /><span style="font-weight: bold">My recommendation:</span>
<br />
<br />Pilots may not perform aerobatic maneuvers in or otherwise obstruct the launch window.  Gliders on launch or conducting touch and go landing approaches have the right of way in the launch window.
<br />The launch window is from the sand trail just south of launch, to the north end of the observation deck, 100' up, 100' out, and 25’ below launch.
<br />Aerobatic maneuvers will be defined as any turn with a bank angle in excess of 30 degrees, or where the attitude of the glider exceeds 30 degrees above or below horizontal.</div>

			<div id="sig1948" class="signature">Allen J  - a llen. j usth at gmail</div>

		</div>

		
			<dl class="postprofile" id="profile1948">
			<dt>
				<a href="../../flyfunston.org/bbs/memberlist433e.html?mode=viewprofile&amp;u=1468">AllenJ</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 32</dd><dd><strong>Joined:</strong> Tue Jul 08, 2008 2:53 pm</dd><dd><strong>Location:</strong> San Mateo</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p1949" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting5187.html?mode=quote&amp;f=5&amp;p=1949" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p1949"></a></h3>
			<p class="author"><a href="viewtopicc429.php?p=1949#p1949"><img src="../../flyfunston.org/bbs/styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="../../flyfunston.org/bbs/memberlistd3cc.html?mode=viewprofile&amp;u=1478">fakeDecoy</a></strong> &raquo; Mon Jan 11, 2010 2:37 pm </p>

			

			<div class="content">That would work too. I think clarifying the right of way, by itself, will create a much safer launch window.
<br />
<br />Diver Dave</div>

			

		</div>

		
			<dl class="postprofile" id="profile1949">
			<dt>
				<a href="../../flyfunston.org/bbs/memberlistd3cc.html?mode=viewprofile&amp;u=1478">fakeDecoy</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 140</dd><dd><strong>Joined:</strong> Thu Jul 24, 2008 8:22 am</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p1951" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting6184.html?mode=quote&amp;f=5&amp;p=1951" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p1951"></a></h3>
			<p class="author"><a href="viewtopic24f2.html?p=1951#p1951"><img src="../../flyfunston.org/bbs/styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="../../flyfunston.org/bbs/memberlist9acc.html?mode=viewprofile&amp;u=126">Dan Brown</a></strong> &raquo; Mon Jan 11, 2010 5:27 pm </p>

			

			<div class="content">Proposed touch and go rule:
<br />
<br />“A glider may not enter the launch window when there is a glider doing a touch and go and a touch and go may not be done when there is a glider in the launch window.”
<br />
<br />Placing responsibility on both pilots decreases the likelihood of a mid-air and prevents pilots from dying defending their rights of way.</div>

			

		</div>

		
			<dl class="postprofile" id="profile1951">
			<dt>
				<a href="../../flyfunston.org/bbs/memberlist9acc.html?mode=viewprofile&amp;u=126">Dan Brown</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 88</dd><dd><strong>Joined:</strong> Fri Apr 01, 2005 2:01 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p1953" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting4830.html?mode=quote&amp;f=5&amp;p=1953" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p1953">Jan Meeting Rules Change</a></h3>
			<p class="author"><a href="viewtopic66cc.html?p=1953#p1953"><img src="../../flyfunston.org/bbs/styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="../../flyfunston.org/bbs/memberlist433e.html?mode=viewprofile&amp;u=1468">AllenJ</a></strong> &raquo; Wed Jan 13, 2010 2:45 pm </p>

			

			<div class="content">After another lively conversation the general agreement was as follows:
<br />
<br />1.  All pilots are responsible for their own actions and safety.  
<br />2.  Existing ridge rules adequately describe right of way.
<br />3.  Rules and Regulations should not be used to prohibit a specific style of flying, but instead lay out consistent expectations of conduct.
<br />4.  The &quot;Pilots must fly safely and courteously&quot; section of Rule #5 could be applied in lieu of specific speed requirements.
<br />5.  Modifications to the current orientation documents and site guide can be used to describe and address site specific safety concerns.
<br />
<br />The new Rule #4 reads as follows:
<br />
<br />&quot;4. Pilots may not perform aerobatic maneuvers in or otherwise obstruct the launch window. The launch window is from the sand trail just south of launch, to the north end of the observation deck, 100' up, 100' out, and 25’ below launch. Aerobatic maneuvers will be defined as any turn with a bank angle in excess of 60 degrees, or where the attitude of the glider exceeds 30 degrees above or below horizontal.&quot;</div>

			<div id="sig1953" class="signature">Allen J  - a llen. j usth at gmail</div>

		</div>

		
			<dl class="postprofile" id="profile1953">
			<dt>
				<a href="../../flyfunston.org/bbs/memberlist433e.html?mode=viewprofile&amp;u=1468">AllenJ</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 32</dd><dd><strong>Joined:</strong> Tue Jul 08, 2008 2:53 pm</dd><dd><strong>Location:</strong> San Mateo</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p1954" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postingca6a.html?mode=quote&amp;f=5&amp;p=1954" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p1954"></a></h3>
			<p class="author"><a href="viewtopic80d7.php?p=1954#p1954"><img src="../../flyfunston.org/bbs/styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="../../flyfunston.org/bbs/memberlistd3cc.html?mode=viewprofile&amp;u=1478">fakeDecoy</a></strong> &raquo; Wed Jan 13, 2010 2:52 pm </p>

			

			<div class="content">Fantastic! Good job Allen and everyone involved.
<br />
<br />Sorry I wasn't able to make it (hey, it was raining!) after raising a stink, but I figured you guys would determine a good change, and I'm sure there was plenty of discussion without me.
<br />
<br />Diver Dave</div>

			

		</div>

		
			<dl class="postprofile" id="profile1954">
			<dt>
				<a href="../../flyfunston.org/bbs/memberlistd3cc.html?mode=viewprofile&amp;u=1478">fakeDecoy</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 140</dd><dd><strong>Joined:</strong> Thu Jul 24, 2008 8:22 am</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<form id="viewtopic" method="post" action="http://www.flyfunston.org/bbs/viewtopic.php?f=5&amp;t=900">

	<fieldset class="display-options" style="margin-top: 0; ">
		
		<label>Display posts from previous: <select name="st" id="st"><option value="0" selected="selected">All posts</option><option value="1">1 day</option><option value="7">7 days</option><option value="14">2 weeks</option><option value="30">1 month</option><option value="90">3 months</option><option value="180">6 months</option><option value="365">1 year</option></select></label>
		<label>Sort by <select name="sk" id="sk"><option value="a">Author</option><option value="t" selected="selected">Post time</option><option value="s">Subject</option></select></label> <label><select name="sd" id="sd"><option value="a" selected="selected">Ascending</option><option value="d">Descending</option></select> <input type="submit" name="sort" value="Go" class="button2" /></label>
		
	</fieldset>

	</form>
	<hr />


<div class="topic-actions">
	<div class="buttons">
	
		<div class="reply-icon"><a href="posting0e16.html?mode=reply&amp;f=5&amp;t=900" title="Post a reply"><span></span>Post a reply</a></div>
	
	</div>

	
		<div class="pagination">
			18 posts
			 &bull; Page <strong>1</strong> of <strong>1</strong>
		</div>
	
</div>


	<p></p><p><a href="../../flyfunston.org/bbs/viewforume774.html?f=5" class="left-box left" accesskey="r">Return to General Discussion</a></p>

	<form method="post" id="jumpbox" action="http://www.flyfunston.org/bbs/viewforum.php" onsubmit="if(this.f.value == -1){return false;}">

	
		<fieldset class="jumpbox">
	
			<label for="f" accesskey="j">Jump to:</label>
			<select name="f" id="f" onchange="if(this.options[this.selectedIndex].value != -1){ document.forms['jumpbox'].submit() }">
			
				<option value="-1">Select a forum</option>
			<option value="-1">------------------</option>
				<option value="9">Discussion Groups</option>
			
				<option value="5" selected="selected">&nbsp; &nbsp;General Discussion</option>
			
				<option value="8">&nbsp; &nbsp;Announcements</option>
			
				<option value="7">&nbsp; &nbsp;For Sale/Wanted</option>
			
				<option value="6">&nbsp; &nbsp;Road Trips</option>
			
				<option value="2">&nbsp; &nbsp;Meeting Minutes and Treasurer Reports</option>
			
				<option value="11">&nbsp; &nbsp;Off Topic</option>
			
			</select>
			<input type="submit" value="Go" class="button2" />
		</fieldset>
	</form>


	<h3>Who is online</h3>
	<p>Users browsing this forum: No registered users and 8 guests</p>
</div>

<div id="page-footer">

	<div class="navbar">
		<div class="inner"><span class="corners-top"><span></span></span>

		<ul class="linklist">
			<li class="icon-home"><a href="../../flyfunston.org/bbs/index.html">Board index</a></li>
				
			<li class="rightside"><a href="../../flyfunston.org/bbs/memberlista2f5.html?mode=leaders">The team</a> &bull; <a href="../../flyfunston.org/bbs/ucp033a.html?mode=delete_cookies">Delete all board cookies</a> &bull; All times are UTC - 8 hours [ <abbr title="Daylight Saving Time">DST</abbr> ]</li>
		</ul>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<div class="copyright">Powered by <a href="https://www.phpbb.com/">phpBB</a>&reg; Forum Software &copy; phpBB Group
		
	</div>
</div>

</div>

<div>
	<a id="bottom" name="bottom" accesskey="z"></a>
	<img src="../../flyfunston.org/bbs/cronb999.gif?cron_type=tidy_search" width="1" height="1" alt="cron" />
</div>

</body>

<!-- Mirrored from www.flyfunston.org/bbs/viewtopic.php?p=1926 by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 08 Aug 2021 20:16:46 GMT -->
</html>