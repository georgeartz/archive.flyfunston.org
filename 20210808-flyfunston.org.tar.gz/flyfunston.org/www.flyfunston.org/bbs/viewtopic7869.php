<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en-us" xml:lang="en-us">

<!-- Mirrored from www.flyfunston.org/bbs/viewtopic.php?t=415 by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 08 Aug 2021 20:18:38 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>

<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<meta http-equiv="content-style-type" content="text/css" />
<meta http-equiv="content-language" content="en-us" />
<meta http-equiv="imagetoolbar" content="no" />
<meta name="resource-type" content="document" />
<meta name="distribution" content="global" />
<meta name="keywords" content="" />
<meta name="description" content="" />

<title>Flyfunston &bull; View topic - Minutes 12/12/06</title>



<!--
	phpBB style name: prosilver
	Based on style:   prosilver (this is the default phpBB3 style)
	Original author:  Tom Beddard ( http://www.subBlue.com/ )
	Modified by:
-->

<script type="text/javascript">
// <![CDATA[
	var jump_page = 'Enter the page number you wish to go to:';
	var on_page = '1';
	var per_page = '';
	var base_url = '';
	var style_cookie = 'phpBBstyle';
	var style_cookie_settings = '; path=/; domain=flyfunston.org; secure';
	var onload_functions = new Array();
	var onunload_functions = new Array();

	

	/**
	* Find a member
	*/
	function find_username(url)
	{
		popup(url, 760, 570, '_usersearch');
		return false;
	}

	/**
	* New function for handling multiple calls to window.onload and window.unload by pentapenguin
	*/
	window.onload = function()
	{
		for (var i = 0; i < onload_functions.length; i++)
		{
			eval(onload_functions[i]);
		}
	};

	window.onunload = function()
	{
		for (var i = 0; i < onunload_functions.length; i++)
		{
			eval(onunload_functions[i]);
		}
	};

// ]]>
</script>
<script type="text/javascript" src="../../flyfunston.org/bbs/styles/prosilver/template/styleswitcher.js"></script>
<script type="text/javascript" src="../../flyfunston.org/bbs/styles/prosilver/template/forum_fn.js"></script>

<link href="../../flyfunston.org/bbs/styles/prosilver/theme/print.css" rel="stylesheet" type="text/css" media="print" title="printonly" />
<link href="../../flyfunston.org/bbs/style7a95.css?id=1&amp;lang=en_us" rel="stylesheet" type="text/css" media="screen, projection" />

<link href="../../flyfunston.org/bbs/styles/prosilver/theme/normal.css" rel="stylesheet" type="text/css" title="A" />
<link href="../../flyfunston.org/bbs/styles/prosilver/theme/medium.css" rel="alternate stylesheet" type="text/css" title="A+" />
<link href="../../flyfunston.org/bbs/styles/prosilver/theme/large.css" rel="alternate stylesheet" type="text/css" title="A++" />



</head>

<body id="phpbb" class="section-viewtopic ltr">

<div id="wrap">
	<a id="top" name="top" accesskey="t"></a>
	<div id="page-header">
		<div class="headerbar">
			<div class="inner"><span class="corners-top"><span></span></span>

			<div id="site-description">
				<a href="../../flyfunston.org/bbs/index.html" title="Board index" id="logo"><img src="../../flyfunston.org/bbs/styles/prosilver/imageset/site_logo.gif" width="149" height="52" alt="" title="" /></a>
				<h1>Flyfunston</h1>
				<p>Hang Gliding at Fort Funston</p>
				<p class="skiplink"><a href="#start_here">Skip to content</a></p>
			</div>

		
			<div id="search-box">
				<form action="http://www.flyfunston.org/bbs/search.php" method="get" id="search">
				<fieldset>
					<input name="keywords" id="keywords" type="text" maxlength="128" title="Search for keywords" class="inputbox search" value="Search…" onclick="if(this.value=='Search…')this.value='';" onblur="if(this.value=='')this.value='Search…';" />
					<input class="button2" value="Search" type="submit" /><br />
					<a href="../../flyfunston.org/bbs/search.html" title="View the advanced search options">Advanced search</a> 
				</fieldset>
				</form>
			</div>
		

			<span class="corners-bottom"><span></span></span></div>
		</div>

		<div class="navbar">
			<div class="inner"><span class="corners-top"><span></span></span>

			<ul class="linklist navlinks">
				<li class="icon-home"><a href="../../flyfunston.org/bbs/index.html" accesskey="h">Board index</a>  <strong>&#8249;</strong> <a href="../../flyfunston.org/bbs/viewforumfdc5.html?f=9">Discussion Groups</a> <strong>&#8249;</strong> <a href="../../flyfunston.org/bbs/viewforum12a3.html?f=2">Meeting Minutes and Treasurer Reports</a></li>

				<li class="rightside"><a href="#" onclick="fontsizeup(); return false;" onkeypress="return fontsizeup(event);" class="fontsize" title="Change font size">Change font size</a></li>

				<li class="rightside"><a href="../../flyfunston.org/bbs/viewtopice8b0.html?f=2&amp;t=415&amp;view=print" title="Print view" accesskey="p" class="print">Print view</a></li>
			</ul>

			

			<ul class="linklist rightside">
				<li class="icon-faq"><a href="../../flyfunston.org/bbs/faq.html" title="Frequently Asked Questions">FAQ</a></li>
				
					<li class="icon-logout"><a href="../../flyfunston.org/bbs/ucp26c3.php?mode=login" title="Login" accesskey="x">Login</a></li>
				
			</ul>

			<span class="corners-bottom"><span></span></span></div>
		</div>

	</div>

	<a name="start_here"></a>
	<div id="page-body">
		
<h2><a href="../../flyfunston.org/bbs/viewtopic57b3.html?f=2&amp;t=415">Minutes 12/12/06</a></h2>
<!-- NOTE: remove the style="display: none" when you want to have the forum description on the topic body --><div style="display: none !important;">Minutes and Treasurer Reports from the Fellow Feathers monthly meetings.<br /></div>

<div class="topic-actions">

	<div class="buttons">
	
		<div class="reply-icon"><a href="../../flyfunston.org/bbs/postinge376.html?mode=reply&amp;f=2&amp;t=415" title="Post a reply"><span></span>Post a reply</a></div>
	
	</div>

	
		<div class="search-box">
			<form method="get" id="topic-search" action="http://www.flyfunston.org/bbs/search.php">
			<fieldset>
				<input class="inputbox search tiny"  type="text" name="keywords" id="search_keywords" size="20" value="Search this topic…" onclick="if(this.value=='Search this topic…')this.value='';" onblur="if(this.value=='')this.value='Search this topic…';" />
				<input class="button2" type="submit" value="Search" />
				<input type="hidden" name="t" value="415" />
<input type="hidden" name="sf" value="msgonly" />

			</fieldset>
			</form>
		</div>
	
		<div class="pagination">
			1 post
			 &bull; Page <strong>1</strong> of <strong>1</strong>
		</div>
	

</div>
<div class="clear"></div>


	<div id="p761" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="../../flyfunston.org/bbs/posting0581.html?mode=quote&amp;f=2&amp;p=761" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 class="first"><a href="#p761">Minutes 12/12/06</a></h3>
			<p class="author"><a href="../../flyfunston.org/bbs/viewtopic5e02.html?p=761#p761"><img src="../../flyfunston.org/bbs/styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="../../flyfunston.org/bbs/memberlistfe9c.html?mode=viewprofile&amp;u=3">Daniel Pifko</a></strong> &raquo; Sat Jan 06, 2007 11:38 am </p>

			

			<div class="content">Fellow Feathers
<br />December 12, 2006
<br />
<br />Attendance:
<br />
<br />Gwenhaël
<br />Attila
<br />Jonas
<br />Tim
<br />Brent
<br />Chris 
<br />Gene
<br />Gordon
<br />Steve
<br />Raffy
<br />Larry
<br />Daniel M.
<br />Daniel P.
<br />
<br />Treas Report
<br />
<br />Year end summaries. Attila will hand out the 2004 and 2005 to Brian for use in filing the incorporation.
<br />•	About $400 down from last year
<br />•	Need to get $300 from Urs
<br />•	We are behind on collecting 2006 waiver money
<br />
<br />Old Business:
<br />
<br />Incorporation:
<br />•	Brian is away sick, so no update
<br />
<br />Webcam:
<br />•	next step – replace the ropes cam building
<br />•	Tim can donate a computer or two for the ropes building
<br />
<br />Clubhouse
<br />•	Tim donated new lockers.  
<br />•	Old new lockers have almost all been given away already.  
<br />•	Perhaps Steve B can take part of Dan to Minden
<br />•	Chris called Chuck K to find out about moving Dan’s glider to open a spot 
<br />•	Move Dan’s gliders up to purgatory
<br />•	Chester needs to get the Stealth and move it to somewhere else.
<br />•	Glider slots:
<br />o	Getting money back for the clubhouse
<br />o	A couple of guys indicated that they don’t fly any more.  Chris talking to them about giving up their spots to guys who fly here.  
<br />•	Brad to be added to the waiting list for the clubhouse
<br />•	Chris Valley is completely on top of and on schedule with clubhouse renewals for 2007.  He’ll finish the task before handing over to the new clubhouse manager
<br />
<br />
<br />New Business:
<br />
<br />
<br />Meeting Minutes on public discussion board
<br />•	One of our members asked about keeping the minutes in a hidden area.  It later became apparent that the individual was completely named in an early meeting report along with something that may not have been looked upon favorably by someone from outside the club.  
<br />•	The club decided that:
<br />o	It’s better to have the meeting minutes out in the open
<br />o	We have generally followed the practice of not naming names in the published minutes even if the people in question were discussed by name during the meeting.  We should continue this practice.  The individual’s full name was removed from the previous minutes.  
<br />
<br />E-mail and anti-spam for directors
<br />•	Board members all have email aliases @flyfunston.org so that members can contact them directly.  In the past few months the spammers have gotten hold of those addresses and bombarded them.  As of a few weeks ago, Daniel changed the aliases to new email addresses AND added a contact page to the Funston site (<!-- m --><a class="postlink" href="../../flyfunston.org/officers.php">http://www.flyfunston.org/officers.php</a><!-- m -->  ). Anyone who wants to contact a board member can do so through this page.  The old email addresses don’t work anymore.
<br />
<br />
<br />
<br />ELECTIONS:
<br />
<br />Nominations for 2007 Board. 
<br />•	President: Steve Rodrigues 
<br />•	Vice-President: Chris Valley 
<br />•	Treasurer – Daniel Mizyrycki (South American Daniel)
<br />•	Secretary – Gwenhaël Jacq
<br />•	Safety – Tom White 
<br />•	Clubhouse – Brian Foster 
<br />o	Raffy Lavin
<br />•	Westlake
<br />o	Jonas Barbour nominated and accepted
<br />
<br />•	Appointments
<br />o	Training Bowl Director - Henry
<br />o	Tandem Director – Steve
<br />
<br />ELECTION RESULTS:
<br />•	In an unpredicted turn of events, Raffy chose to be nominated for Clubhouse Manager instead of Westlake Director.  He beat the ill and absent Brian by a vote of 6 to 5.  
<br />•	All others were acclaimed
<br />•	Daniel to change the email aliases to point to the new board members as appropriate
<br />
<br />Stickers
<br />
<br />•	Steve distributed 2007 stickers.  There is a Keep Fort Funston Flying Free note on top of each package describing some new safety issues around landing on launch.</div>

			

		</div>

		
			<dl class="postprofile" id="profile761">
			<dt>
				<a href="../../flyfunston.org/bbs/memberlistfe9c.html?mode=viewprofile&amp;u=3"><img src="http://www.pifko.com/fly/images/avatar.jpg" width="60" height="80" alt="User avatar" /></a><br />
				<a href="../../flyfunston.org/bbs/memberlistfe9c.html?mode=viewprofile&amp;u=3">Daniel Pifko</a>
			</dt>

			<dd>Site Admin</dd>

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 249</dd><dd><strong>Joined:</strong> Tue Jan 13, 2004 5:23 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />


<div class="topic-actions">
	<div class="buttons">
	
		<div class="reply-icon"><a href="../../flyfunston.org/bbs/postinge376.html?mode=reply&amp;f=2&amp;t=415" title="Post a reply"><span></span>Post a reply</a></div>
	
	</div>

	
		<div class="pagination">
			1 post
			 &bull; Page <strong>1</strong> of <strong>1</strong>
		</div>
	
</div>


	<p></p><p><a href="../../flyfunston.org/bbs/viewforum12a3.html?f=2" class="left-box left" accesskey="r">Return to Meeting Minutes and Treasurer Reports</a></p>

	<form method="post" id="jumpbox" action="http://www.flyfunston.org/bbs/viewforum.php" onsubmit="if(this.f.value == -1){return false;}">

	
		<fieldset class="jumpbox">
	
			<label for="f" accesskey="j">Jump to:</label>
			<select name="f" id="f" onchange="if(this.options[this.selectedIndex].value != -1){ document.forms['jumpbox'].submit() }">
			
				<option value="-1">Select a forum</option>
			<option value="-1">------------------</option>
				<option value="9">Discussion Groups</option>
			
				<option value="5">&nbsp; &nbsp;General Discussion</option>
			
				<option value="8">&nbsp; &nbsp;Announcements</option>
			
				<option value="7">&nbsp; &nbsp;For Sale/Wanted</option>
			
				<option value="6">&nbsp; &nbsp;Road Trips</option>
			
				<option value="2" selected="selected">&nbsp; &nbsp;Meeting Minutes and Treasurer Reports</option>
			
				<option value="11">&nbsp; &nbsp;Off Topic</option>
			
			</select>
			<input type="submit" value="Go" class="button2" />
		</fieldset>
	</form>


	<h3>Who is online</h3>
	<p>Users browsing this forum: No registered users and 4 guests</p>
</div>

<div id="page-footer">

	<div class="navbar">
		<div class="inner"><span class="corners-top"><span></span></span>

		<ul class="linklist">
			<li class="icon-home"><a href="../../flyfunston.org/bbs/index.html">Board index</a></li>
				
			<li class="rightside"><a href="../../flyfunston.org/bbs/memberlista2f5.html?mode=leaders">The team</a> &bull; <a href="../../flyfunston.org/bbs/ucp033a.html?mode=delete_cookies">Delete all board cookies</a> &bull; All times are UTC - 8 hours [ <abbr title="Daylight Saving Time">DST</abbr> ]</li>
		</ul>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<div class="copyright">Powered by <a href="https://www.phpbb.com/">phpBB</a>&reg; Forum Software &copy; phpBB Group
		
	</div>
</div>

</div>

<div>
	<a id="bottom" name="bottom" accesskey="z"></a>
	<img src="../../flyfunston.org/bbs/cronb999.gif?cron_type=tidy_search" width="1" height="1" alt="cron" />
</div>

</body>

<!-- Mirrored from www.flyfunston.org/bbs/viewtopic.php?t=415 by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 08 Aug 2021 20:18:38 GMT -->
</html>