<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en-us" xml:lang="en-us">

<!-- Mirrored from www.flyfunston.org/bbs/viewtopic.php?f=5&t=450&view=print by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 08 Aug 2021 20:04:23 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>

<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<meta http-equiv="content-style-type" content="text/css" />
<meta http-equiv="content-language" content="en-us" />
<meta http-equiv="imagetoolbar" content="no" />
<meta name="resource-type" content="document" />
<meta name="distribution" content="global" />
<meta name="robots" content="noindex" />

<title>Flyfunston &bull; View topic - April Fellow Feathers Meeting</title>

<link href="../../flyfunston.org/bbs/styles/prosilver/theme/print.css" rel="stylesheet" type="text/css" />
</head>

<body id="phpbb">
<div id="wrap">
	<a id="top" name="top" accesskey="t"></a>

	<div id="page-header">
		<h1>Flyfunston</h1>
		<p>Hang Gliding at Fort Funston<br /><a href="../../flyfunston.org/bbs/index-2.html">http://www.flyfunston.org/bbs/</a></p>

		<h2>April Fellow Feathers Meeting</h2>
		<p><a href="viewtopica10f.php?f=5&amp;t=450">http://www.flyfunston.org/bbs/viewtopic.php?f=5&amp;t=450</a></p>
	</div>

	<div id="page-body">
		<div class="page-number">Page <strong>1</strong> of <strong>1</strong></div>
		
			<div class="post">
				<h3>April Fellow Feathers Meeting</h3>
				<div class="date"><img src="../../flyfunston.org/bbs/styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" />Posted: <strong>Mon Apr 09, 2007 5:56 am</strong></div>
				<div class="author">by <strong>Steve Rodrigues</strong></div>
				<div class="content">The April 10 Fellow Feathers meeting will start at 7:30 PM with free pizza and lively conversation about all things flying!
<br />
<br />See ya there!</div>
			</div>
			<hr />
		
			<div class="post">
				<h3>FREE BEER!! clubhouse slot proposal FREE BEER!!</h3>
				<div class="date"><img src="../../flyfunston.org/bbs/styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" />Posted: <strong>Tue Apr 10, 2007 11:30 am</strong></div>
				<div class="author">by <strong>davidroyer</strong></div>
				<div class="content">FREE BEER FREE BEER FREE BEER FREE BEER FREE BEER
<br />
<br />now that i've got everyone's attention=)
<br />
<br />The following proposal will be presented to the Club this evening, please come and support this effort, a large cooler full of FREE BEER will be provided to loosen tongues.
<br />
<br />A well managed the clubhouse can be a great tool for club members, and has the potential to grow the number of active pilots at Funston, as glider logistics are a huge barrier to new pilots. 
<br />
<br />In order to accomplish the goal of providing clubhouse glider spaces to pilots that actually Fly Funston, as opposed to being cheap storage for non-flying members, I propose that we vote to move forward on the following items:
<br />
<br />- The Club decides on a concrete standard on how often a pilot needs to fly Funston to have a slot, and enforce it: If a pilot does not fly at Fort Funston at least x times a month during the flying season, for x consecutive months, they forfeit their slot, and their glider will be moved to the graveyard.
<br />
<br />- The Clubhouse Manager notifies current slot holders by email/letter to, as well as posting a notice in the Clubhouse, stating the standard and that it will be enforced rigorously.
<br />
<br />- The Clubhouse Manager sends an email/letter to existing slot holders, asking them if they have flown at Funston within the last 6 months. If they have not, or if no response is received after 2 emails/letters, they forfeit their slot and their glider is moved to the graveyard. In this letter we offer to provide free-of-charge glider transportation from the clubhouse to a location of choice in the Bay Area. This service will be provided by Clubhouse Waiting List members. 
<br />
<br />- The Clubhouse Manager provides a publicly posted waiting list.
<br />
<br />Thanks for considering, 
<br />
<br />Waiting List Members, who will be providing FREE BEER.
<br />
<br />
<br /></div>
			</div>
			<hr />
		
	</div>

	<div id="page-footer">
		<div class="page-number">All times are UTC - 8 hours [ <abbr title="Daylight Saving Time">DST</abbr> ]<br />Page <strong>1</strong> of <strong>1</strong></div>
		<div class="copyright">Powered by phpBB&reg; Forum Software &copy; phpBB Group<br />https://www.phpbb.com/</div>
	</div>
</div>

</body>

<!-- Mirrored from www.flyfunston.org/bbs/viewtopic.php?f=5&t=450&view=print by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 08 Aug 2021 20:04:23 GMT -->
</html>