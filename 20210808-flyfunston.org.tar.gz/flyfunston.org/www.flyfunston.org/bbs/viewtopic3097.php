<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en-us" xml:lang="en-us">

<!-- Mirrored from www.flyfunston.org/bbs/viewtopic.php?p=3610 by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 08 Aug 2021 20:04:55 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>

<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<meta http-equiv="content-style-type" content="text/css" />
<meta http-equiv="content-language" content="en-us" />
<meta http-equiv="imagetoolbar" content="no" />
<meta name="resource-type" content="document" />
<meta name="distribution" content="global" />
<meta name="keywords" content="" />
<meta name="description" content="" />

<title>Flyfunston &bull; View topic - Important Club Meeting This Tuesday!</title>



<!--
	phpBB style name: prosilver
	Based on style:   prosilver (this is the default phpBB3 style)
	Original author:  Tom Beddard ( http://www.subBlue.com/ )
	Modified by:
-->

<script type="text/javascript">
// <![CDATA[
	var jump_page = 'Enter the page number you wish to go to:';
	var on_page = '1';
	var per_page = '';
	var base_url = '';
	var style_cookie = 'phpBBstyle';
	var style_cookie_settings = '; path=/; domain=flyfunston.org; secure';
	var onload_functions = new Array();
	var onunload_functions = new Array();

	

	/**
	* Find a member
	*/
	function find_username(url)
	{
		popup(url, 760, 570, '_usersearch');
		return false;
	}

	/**
	* New function for handling multiple calls to window.onload and window.unload by pentapenguin
	*/
	window.onload = function()
	{
		for (var i = 0; i < onload_functions.length; i++)
		{
			eval(onload_functions[i]);
		}
	};

	window.onunload = function()
	{
		for (var i = 0; i < onunload_functions.length; i++)
		{
			eval(onunload_functions[i]);
		}
	};

// ]]>
</script>
<script type="text/javascript" src="../../flyfunston.org/bbs/styles/prosilver/template/styleswitcher.js"></script>
<script type="text/javascript" src="../../flyfunston.org/bbs/styles/prosilver/template/forum_fn.js"></script>

<link href="../../flyfunston.org/bbs/styles/prosilver/theme/print.css" rel="stylesheet" type="text/css" media="print" title="printonly" />
<link href="../../flyfunston.org/bbs/style7a95.css?id=1&amp;lang=en_us" rel="stylesheet" type="text/css" media="screen, projection" />

<link href="../../flyfunston.org/bbs/styles/prosilver/theme/normal.css" rel="stylesheet" type="text/css" title="A" />
<link href="../../flyfunston.org/bbs/styles/prosilver/theme/medium.css" rel="alternate stylesheet" type="text/css" title="A+" />
<link href="../../flyfunston.org/bbs/styles/prosilver/theme/large.css" rel="alternate stylesheet" type="text/css" title="A++" />



</head>

<body id="phpbb" class="section-viewtopic ltr">

<div id="wrap">
	<a id="top" name="top" accesskey="t"></a>
	<div id="page-header">
		<div class="headerbar">
			<div class="inner"><span class="corners-top"><span></span></span>

			<div id="site-description">
				<a href="../../flyfunston.org/bbs/index.html" title="Board index" id="logo"><img src="../../flyfunston.org/bbs/styles/prosilver/imageset/site_logo.gif" width="149" height="52" alt="" title="" /></a>
				<h1>Flyfunston</h1>
				<p>Hang Gliding at Fort Funston</p>
				<p class="skiplink"><a href="#start_here">Skip to content</a></p>
			</div>

		
			<div id="search-box">
				<form action="http://www.flyfunston.org/bbs/search.php" method="get" id="search">
				<fieldset>
					<input name="keywords" id="keywords" type="text" maxlength="128" title="Search for keywords" class="inputbox search" value="Search…" onclick="if(this.value=='Search…')this.value='';" onblur="if(this.value=='')this.value='Search…';" />
					<input class="button2" value="Search" type="submit" /><br />
					<a href="../../flyfunston.org/bbs/search.html" title="View the advanced search options">Advanced search</a> 
				</fieldset>
				</form>
			</div>
		

			<span class="corners-bottom"><span></span></span></div>
		</div>

		<div class="navbar">
			<div class="inner"><span class="corners-top"><span></span></span>

			<ul class="linklist navlinks">
				<li class="icon-home"><a href="../../flyfunston.org/bbs/index.html" accesskey="h">Board index</a>  <strong>&#8249;</strong> <a href="../../flyfunston.org/bbs/viewforumfdc5.html?f=9">Discussion Groups</a> <strong>&#8249;</strong> <a href="../../flyfunston.org/bbs/viewforume774.html?f=5">General Discussion</a></li>

				<li class="rightside"><a href="#" onclick="fontsizeup(); return false;" onkeypress="return fontsizeup(event);" class="fontsize" title="Change font size">Change font size</a></li>

				<li class="rightside"><a href="viewtopicc4eb.html?f=5&amp;t=1470&amp;view=print" title="Print view" accesskey="p" class="print">Print view</a></li>
			</ul>

			

			<ul class="linklist rightside">
				<li class="icon-faq"><a href="../../flyfunston.org/bbs/faq.html" title="Frequently Asked Questions">FAQ</a></li>
				
					<li class="icon-logout"><a href="../../flyfunston.org/bbs/ucp26c3.php?mode=login" title="Login" accesskey="x">Login</a></li>
				
			</ul>

			<span class="corners-bottom"><span></span></span></div>
		</div>

	</div>

	<a name="start_here"></a>
	<div id="page-body">
		
<h2><a href="../../flyfunston.org/bbs/viewtopice084.html?f=5&amp;t=1470">Important Club Meeting This Tuesday!</a></h2>
<!-- NOTE: remove the style="display: none" when you want to have the forum description on the topic body --><div style="display: none !important;">Talk about Hang Gliding at Ft Funston and the Fellow Feathers Club.<br /></div>

<div class="topic-actions">

	<div class="buttons">
	
		<div class="reply-icon"><a href="posting7278.html?mode=reply&amp;f=5&amp;t=1470" title="Post a reply"><span></span>Post a reply</a></div>
	
	</div>

	
		<div class="search-box">
			<form method="get" id="topic-search" action="http://www.flyfunston.org/bbs/search.php">
			<fieldset>
				<input class="inputbox search tiny"  type="text" name="keywords" id="search_keywords" size="20" value="Search this topic…" onclick="if(this.value=='Search this topic…')this.value='';" onblur="if(this.value=='')this.value='Search this topic…';" />
				<input class="button2" type="submit" value="Search" />
				<input type="hidden" name="t" value="1470" />
<input type="hidden" name="sf" value="msgonly" />

			</fieldset>
			</form>
		</div>
	
		<div class="pagination">
			8 posts
			 &bull; Page <strong>1</strong> of <strong>1</strong>
		</div>
	

</div>
<div class="clear"></div>


	<div id="p3600" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting91f2.html?mode=quote&amp;f=5&amp;p=3600" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 class="first"><a href="#p3600">Important Club Meeting This Tuesday!</a></h3>
			<p class="author"><a href="viewtopic7999.html?p=3600#p3600"><img src="../../flyfunston.org/bbs/styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="../../flyfunston.org/bbs/memberlist6cb2.html?mode=viewprofile&amp;u=2073">LadyHawk</a></strong> &raquo; Fri Oct 04, 2013 5:46 pm </p>

			

			<div class="content">This coming Tuesday's club meeting (10/8) is vitally important. Our special use permit and site insurance are seriously at risk and we will be discussing those concerns. <br /><br />USHPA's President, Rich Hass, will be attending our meeting to address concerns that have put our site insurance at risk. Mitch Shipley, USHPA's appointed Investigative Officer for the upcoming hearings will attend our meeting as well. <br /><br />We will also vote in a new VP. Patrick has served our club well this year, but due to extensive travel requirements that have been implemented in his job, he no longer has the time necessary to serve as VP and has stepped down. Thank you for having been there for our club, Patrick! You'll be missed. <br /><br />The location of Tuesday's meeting is to be determined. We are in the process of arranging an alternative place to meet should the government shutdown still be in effect at that time. We'll announce the location once we've firmed it up. The meeting, as usual, will be from 7:30pm to 9pm.</div>

			

		</div>

		
			<dl class="postprofile" id="profile3600">
			<dt>
				<a href="../../flyfunston.org/bbs/memberlist6cb2.html?mode=viewprofile&amp;u=2073">LadyHawk</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 30</dd><dd><strong>Joined:</strong> Fri Aug 24, 2012 12:48 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3601" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postingcd6c.html?mode=quote&amp;f=5&amp;p=3601" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3601">Re: Important Club Meeting This Tuesday!</a></h3>
			<p class="author"><a href="viewtopic73e1.html?p=3601#p3601"><img src="../../flyfunston.org/bbs/styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="../../flyfunston.org/bbs/memberlist6cb2.html?mode=viewprofile&amp;u=2073">LadyHawk</a></strong> &raquo; Sat Oct 05, 2013 11:47 am </p>

			

			<div class="content">This morning my car had 3 flat tires. I filed a police report about it. <br /><br />Self centered and abusive behavior is what has put our site at great risk of closing.</div>

			

		</div>

		
			<dl class="postprofile" id="profile3601">
			<dt>
				<a href="../../flyfunston.org/bbs/memberlist6cb2.html?mode=viewprofile&amp;u=2073">LadyHawk</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 30</dd><dd><strong>Joined:</strong> Fri Aug 24, 2012 12:48 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3602" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting2a45.html?mode=quote&amp;f=5&amp;p=3602" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3602">Re: Important Club Meeting This Tuesday!</a></h3>
			<p class="author"><a href="viewtopic5b49.html?p=3602#p3602"><img src="../../flyfunston.org/bbs/styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="../../flyfunston.org/bbs/memberliste69f.html?mode=viewprofile&amp;u=15" style="color: #AA0000;" class="username-coloured">Steve Rodrigues</a></strong> &raquo; Sun Oct 06, 2013 10:08 am </p>

			

			<div class="content">Due to the Government shut down, the October 8 club meeting will be held at the Sharp Park Golf Course in Pacifica, on the ocean side of Hwy 1 at Sharp Park Rd., from 7:30 to 9:30 PM. Pizza will be served!<br /><br />This is a critical meeting and your vote is very important. Please come and help save Fort Funston!<br /><br />Note: GPS navigation does not work well for the street address, it will put you in the ocean.<br /><br />Directions from Fort Funston, 12 minutes:<br />Head South on Skyline Blvd., Take the Hwy 1 exit South towards Pacifica, go 3.4 miles and take the Sharp Park Exit. At the end of the off ramp turn Right on Bradford, go 300’ and the golf course driveway entrance will be on your left.<br /><br />From San Francisco/north bay:<br />Take 280 South, exit Hwy 1 south towards Pacifica, go 4.5 miles and take the Sharp Park Exit. At the end of the off ramp turn Right onto Bradford, go 300’ and the golf course driveway entrance will be on your left.<br /><br />From the south bay:<br />Take 280 North, exit Hwy 1 south towards Pacifica, go 4.5 miles and take the Sharp Park Exit. At the end of the off ramp turn Right onto Bradford, go 300’ and the golf course driveway entrance will be on your left.<br /> <br />From Half Moon Bay: <br />Take Hwy 1 North, Take the Sharp Park Exit. At the end of the off ramp turn left on Lundy, at the stop sign turn left on Sharp Park Rd. and cross over Hwy 1. Turn Left on Bradford, go 700‘ and the driveway entrance will be on your right.<br /><br />Map here: <!-- m --><a class="postlink" href="http://s124.photobucket.com/user/srskypuppy/media/SharpParkGolfCourse.jpg.html">http://s124.photobucket.com/user/srskyp ... e.jpg.html</a><!-- m --></div>

			<div id="sig3602" class="signature">USHPA # 30605<br />H-5, Mentor and Observer</div>

		</div>

		
			<dl class="postprofile" id="profile3602">
			<dt>
				<a href="../../flyfunston.org/bbs/memberliste69f.html?mode=viewprofile&amp;u=15"><img src="../../flyfunston.org/bbs/download/file9b05.php?avatar=15_1575056796.jpg" width="200" height="149" alt="User avatar" /></a><br />
				<a href="../../flyfunston.org/bbs/memberliste69f.html?mode=viewprofile&amp;u=15" style="color: #AA0000;" class="username-coloured">Steve Rodrigues</a>
			</dt>

			<dd>Site Admin</dd>

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 723</dd><dd><strong>Joined:</strong> Mon May 24, 2004 10:57 pm</dd><dd><strong>Location:</strong> Brisbane, California</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3608" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postingc28f.html?mode=quote&amp;f=5&amp;p=3608" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3608">Re: Important Club Meeting This Tuesday!</a></h3>
			<p class="author"><a href="viewtopic330d.php?p=3608#p3608"><img src="../../flyfunston.org/bbs/styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="../../flyfunston.org/bbs/memberliste69f.html?mode=viewprofile&amp;u=15" style="color: #AA0000;" class="username-coloured">Steve Rodrigues</a></strong> &raquo; Wed Oct 09, 2013 4:58 pm </p>

			

			<div class="content">I want to thank the many folks who made the trek to Pacifica last night. The meeting was a great success and the overwhelming majority sent out a clear message.<br /><br />The club put some stronger rules in place and the FF EC is committed to a zero-tolerance policy. I believe that the clubs actions will put to rest USHPA's insurance concerns and the concerns of the NPS/GGNRA.<br /><br />In addition, two long-time Funston pilots will be the focus of a USHPA disciplinary hearing at the BOD meeting this week.<br /><br />Things are changing at the Fort and I feel it is safe to say that the quality of life at Funston will be very much better next year!<br /><br />Again, Thank you all for helping save the site!</div>

			<div id="sig3608" class="signature">USHPA # 30605<br />H-5, Mentor and Observer</div>

		</div>

		
			<dl class="postprofile" id="profile3608">
			<dt>
				<a href="../../flyfunston.org/bbs/memberliste69f.html?mode=viewprofile&amp;u=15"><img src="../../flyfunston.org/bbs/download/file9b05.php?avatar=15_1575056796.jpg" width="200" height="149" alt="User avatar" /></a><br />
				<a href="../../flyfunston.org/bbs/memberliste69f.html?mode=viewprofile&amp;u=15" style="color: #AA0000;" class="username-coloured">Steve Rodrigues</a>
			</dt>

			<dd>Site Admin</dd>

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 723</dd><dd><strong>Joined:</strong> Mon May 24, 2004 10:57 pm</dd><dd><strong>Location:</strong> Brisbane, California</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3610" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting79d9.html?mode=quote&amp;f=5&amp;p=3610" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3610">Re: Important Club Meeting This Tuesday!</a></h3>
			<p class="author"><a href="viewtopic3097.php?p=3610#p3610"><img src="../../flyfunston.org/bbs/styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="../../flyfunston.org/bbs/memberlistc6bf.html?mode=viewprofile&amp;u=13">charlie nelson</a></strong> &raquo; Wed Oct 09, 2013 7:36 pm </p>

			

			<div class="content">that meeting was something to remember. I'm glad i went . We are an interesting group. then  we fly sometimes  .<br />Steve Morris made a statement that resonated with the meeting. ' something like <br />'what are you willing to give up to continue flying at funston'<br />it's a unique site that needs more attention than the other sites. <br />would the BLM ask us to do dirt road repair to fly Hull Mtn?  or ,would the Nevada DOT ask us to pick up roadside trash to fly at Slide ?<br />sure.  they wouldn't mind if we did help out.<br />same with GGNRA, sometimes they 'd like some help to keep the place shiny and clean, and they need more hep than the country sites because it 's the big city and gets a lot of use . except for now of course</div>

			<div id="sig3610" class="signature">email me at 'chahlieandkathy at  yahoo dotto  com'</div>

		</div>

		
			<dl class="postprofile" id="profile3610">
			<dt>
				<a href="../../flyfunston.org/bbs/memberlistc6bf.html?mode=viewprofile&amp;u=13"><img src="http://images.yuku.com/image/gif/b4836b1510a1318049a0a9e68005ce3b7f128ab1_t.gif" width="80" height="80" alt="User avatar" /></a><br />
				<a href="../../flyfunston.org/bbs/memberlistc6bf.html?mode=viewprofile&amp;u=13">charlie nelson</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 116</dd><dd><strong>Joined:</strong> Tue May 18, 2004 5:18 pm</dd><dd><strong>Location:</strong> redwood city</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3611" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting64d0.html?mode=quote&amp;f=5&amp;p=3611" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3611">Re: Important Club Meeting This Tuesday!</a></h3>
			<p class="author"><a href="viewtopic04e7.html?p=3611#p3611"><img src="../../flyfunston.org/bbs/styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="../../flyfunston.org/bbs/memberlist6cb2.html?mode=viewprofile&amp;u=2073">LadyHawk</a></strong> &raquo; Wed Oct 09, 2013 8:17 pm </p>

			

			<div class="content">Our club's board is also scheduling hearings for 2 additional pilots. <br /><br />Any actions that put our site at risk will be addressed. <br /><br />Thank you for the outpouring of support!!!!!</div>

			

		</div>

		
			<dl class="postprofile" id="profile3611">
			<dt>
				<a href="../../flyfunston.org/bbs/memberlist6cb2.html?mode=viewprofile&amp;u=2073">LadyHawk</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 30</dd><dd><strong>Joined:</strong> Fri Aug 24, 2012 12:48 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3612" class="post bg2">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="postingc71c.html?mode=quote&amp;f=5&amp;p=3612" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3612">Re: Important Club Meeting This Tuesday!</a></h3>
			<p class="author"><a href="viewtopic383a.html?p=3612#p3612"><img src="../../flyfunston.org/bbs/styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="../../flyfunston.org/bbs/memberlist6cb2.html?mode=viewprofile&amp;u=2073">LadyHawk</a></strong> &raquo; Wed Oct 09, 2013 10:15 pm </p>

			

			<div class="content">Make that 3 club hearings.</div>

			

		</div>

		
			<dl class="postprofile" id="profile3612">
			<dt>
				<a href="../../flyfunston.org/bbs/memberlist6cb2.html?mode=viewprofile&amp;u=2073">LadyHawk</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 30</dd><dd><strong>Joined:</strong> Fri Aug 24, 2012 12:48 pm</dd>

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<div id="p3618" class="post bg1">
		<div class="inner"><span class="corners-top"><span></span></span>

		<div class="postbody">
			
				<ul class="profile-icons">
					<li class="quote-icon"><a href="posting3b5e.html?mode=quote&amp;f=5&amp;p=3618" title="Reply with quote"><span>Reply with quote</span></a></li>
				</ul>
			

			<h3 ><a href="#p3618">Re: Important Club Meeting This Tuesday!</a></h3>
			<p class="author"><a href="viewtopic634e.html?p=3618#p3618"><img src="../../flyfunston.org/bbs/styles/prosilver/imageset/icon_post_target.gif" width="11" height="9" alt="Post" title="Post" /></a>by <strong><a href="../../flyfunston.org/bbs/memberlist2501.html?mode=viewprofile&amp;u=41">diev</a></strong> &raquo; Mon Oct 14, 2013 10:14 am </p>

			

			<div class="content">Do the members know they are being charged and what the charges are?<br />Diev</div>

			<div id="sig3618" class="signature">Diev Hart<br />KG6UST<br /><!-- m --><a class="postlink" href="http://www.dievhart.com/hangglide.html">http://www.dievhart.com/hangglide.html</a><!-- m --></div>

		</div>

		
			<dl class="postprofile" id="profile3618">
			<dt>
				<a href="../../flyfunston.org/bbs/memberlist2501.html?mode=viewprofile&amp;u=41">diev</a>
			</dt>

			

		<dd>&nbsp;</dd>

		<dd><strong>Posts:</strong> 253</dd><dd><strong>Joined:</strong> Tue Sep 28, 2004 1:40 pm</dd><dd><strong>Location:</strong> Santa Cruz, CA</dd>
			<dd>
				<ul class="profile-icons">
					<li class="web-icon"><a href="http://www.dievhart.com/hangglide.html" title="WWW: http://www.dievhart.com/hangglide.html"><span>Website</span></a></li><li class="yahoo-icon"><a href="http://edit.yahoo.com/config/send_webmesg?.target=dievhart&amp;.src=pg" onclick="popup(this.href, 780, 550); return false;" title="YIM"><span>YIM</span></a></li>
				</ul>
			</dd>
		

		</dl>
	

		<div class="back2top"><a href="#wrap" class="top" title="Top">Top</a></div>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<hr class="divider" />

	<form id="viewtopic" method="post" action="http://www.flyfunston.org/bbs/viewtopic.php?f=5&amp;t=1470">

	<fieldset class="display-options" style="margin-top: 0; ">
		
		<label>Display posts from previous: <select name="st" id="st"><option value="0" selected="selected">All posts</option><option value="1">1 day</option><option value="7">7 days</option><option value="14">2 weeks</option><option value="30">1 month</option><option value="90">3 months</option><option value="180">6 months</option><option value="365">1 year</option></select></label>
		<label>Sort by <select name="sk" id="sk"><option value="a">Author</option><option value="t" selected="selected">Post time</option><option value="s">Subject</option></select></label> <label><select name="sd" id="sd"><option value="a" selected="selected">Ascending</option><option value="d">Descending</option></select> <input type="submit" name="sort" value="Go" class="button2" /></label>
		
	</fieldset>

	</form>
	<hr />


<div class="topic-actions">
	<div class="buttons">
	
		<div class="reply-icon"><a href="posting7278.html?mode=reply&amp;f=5&amp;t=1470" title="Post a reply"><span></span>Post a reply</a></div>
	
	</div>

	
		<div class="pagination">
			8 posts
			 &bull; Page <strong>1</strong> of <strong>1</strong>
		</div>
	
</div>


	<p></p><p><a href="../../flyfunston.org/bbs/viewforume774.html?f=5" class="left-box left" accesskey="r">Return to General Discussion</a></p>

	<form method="post" id="jumpbox" action="http://www.flyfunston.org/bbs/viewforum.php" onsubmit="if(this.f.value == -1){return false;}">

	
		<fieldset class="jumpbox">
	
			<label for="f" accesskey="j">Jump to:</label>
			<select name="f" id="f" onchange="if(this.options[this.selectedIndex].value != -1){ document.forms['jumpbox'].submit() }">
			
				<option value="-1">Select a forum</option>
			<option value="-1">------------------</option>
				<option value="9">Discussion Groups</option>
			
				<option value="5" selected="selected">&nbsp; &nbsp;General Discussion</option>
			
				<option value="8">&nbsp; &nbsp;Announcements</option>
			
				<option value="7">&nbsp; &nbsp;For Sale/Wanted</option>
			
				<option value="6">&nbsp; &nbsp;Road Trips</option>
			
				<option value="2">&nbsp; &nbsp;Meeting Minutes and Treasurer Reports</option>
			
				<option value="11">&nbsp; &nbsp;Off Topic</option>
			
			</select>
			<input type="submit" value="Go" class="button2" />
		</fieldset>
	</form>


	<h3>Who is online</h3>
	<p>Users browsing this forum: No registered users and 7 guests</p>
</div>

<div id="page-footer">

	<div class="navbar">
		<div class="inner"><span class="corners-top"><span></span></span>

		<ul class="linklist">
			<li class="icon-home"><a href="../../flyfunston.org/bbs/index.html">Board index</a></li>
				
			<li class="rightside"><a href="../../flyfunston.org/bbs/memberlista2f5.html?mode=leaders">The team</a> &bull; <a href="../../flyfunston.org/bbs/ucp033a.html?mode=delete_cookies">Delete all board cookies</a> &bull; All times are UTC - 8 hours [ <abbr title="Daylight Saving Time">DST</abbr> ]</li>
		</ul>

		<span class="corners-bottom"><span></span></span></div>
	</div>

	<div class="copyright">Powered by <a href="https://www.phpbb.com/">phpBB</a>&reg; Forum Software &copy; phpBB Group
		
	</div>
</div>

</div>

<div>
	<a id="bottom" name="bottom" accesskey="z"></a>
	
</div>

</body>

<!-- Mirrored from www.flyfunston.org/bbs/viewtopic.php?p=3610 by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 08 Aug 2021 20:04:55 GMT -->
</html>